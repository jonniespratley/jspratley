<?php/**                    My Test Application
                *//**  * I am a object representing the @TABLE table. *  * @version CodeGen - 1.8 * @author CodeGen - Jonnie Spratley (http://jonniespratley.com/code) * * @package com.domain.project.VO * @name CommentsVO.php */class CommentsVO{	/* Official boycott on amphp, because its trash */	//public $_explicitType = 'com.domain.project.vo.CommentsVO';		
			public $comment_body;
			public $comment_created;
			public $comment_name;
			public $id;		public function __construct(){}		public function mapObject( $vo )	{		
			$this->comment_body = $vo["comment_body"];
			$this->comment_created = $vo["comment_created"];
			$this->comment_name = $vo["comment_name"];
			$this->id = $vo["id"];	}		public function setNamespace( $namespace )	{		$this->explicitType = $namespace;	}		public function __get( $name )	{		return $this->$name;	}		public function __set( $name, $value )	{		$this->$name = $value;	}	}?>                                          