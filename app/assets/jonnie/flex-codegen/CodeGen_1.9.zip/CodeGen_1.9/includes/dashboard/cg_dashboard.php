<?php


require_once 'library/AtomParser.php';
$cgDownloadFeed = 'http://code.google.com/feeds/p/flex-codegen/downloads/basic';
$cgUpdatesFeed = 'http://code.google.com/feeds/p/flex-codegen/updates/basic';
$cgSourceFeed = 'http://code.google.com/feeds/p/flex-codegen/svnchanges/basic';

$parse = new AtomParser();
$cgDownloadOuput = $parse->parseAtom( $cgDownloadFeed );
$cgUpdateOutput = $parse->parseAtom( $cgUpdatesFeed );
$cgSourceOutput = $parse->parseAtom( $cgSourceFeed );

?>
<div class="title">
	<h2>Dashboard</h2>
</div>

<div class="box round lg">
	<h3>Recent Updates</h3>
	
</div>

<div class="box round lg">
	<h3>Recent Changes</h3>
	
</div> 

<div class="box round lg">
	<h3>Recent Downloads</h3>
	
</div>