<div class="box round">
	<h3>Database Information </h3>
	<form id="form_config" name="form_config" method="" action="">
<?php

$step1Options = array ( 
	array ( 
	'label' => 'Database Host', 'name' => 'txt_host', 'type' => 'text', 'value' => 'localhost', 'class' => 'medium' 
), array ( 
	'label' => 'Database Username', 'name' => 'txt_user', 'type' => 'text', 'value' => 'root', 'class' => 'medium' 
), array ( 
	'label' => 'Database Password', 'name' => 'txt_pass', 'type' => 'password', 'value' => 'fred', 'class' => 'medium' 
), array ( 
	'label' => 'Database', 'name' => 'txt_database', 'type' => 'select', 'value' => '', 'class' => 'medium' 
) 
);

$html->doOptions ( $step1Options );

?>
</form>
</div>