<div class="grid_12">
	<div id="cg_inspector"></div>
</div>
<div class="clear"></div>