<?php/**                    My Test Application
                *//**  * I am a object representing the @TABLE table. *  * @version CodeGen - 1.8 * @author CodeGen - Jonnie Spratley (http://jonniespratley.com/code) * * @package com.domain.project.VO * @name States_stateVO.php */class States_stateVO{	/* Official boycott on amphp, because its trash */	//public $_explicitType = 'com.domain.project.vo.States_stateVO';		
			public $id_state;
			public $name_state;		public function __construct(){}		public function mapObject( $vo )	{		
			$this->id_state = $vo["id_state"];
			$this->name_state = $vo["name_state"];	}		public function setNamespace( $namespace )	{		$this->explicitType = $namespace;	}		public function __get( $name )	{		return $this->$name;	}		public function __set( $name, $value )	{		$this->$name = $value;	}	}?>                                          