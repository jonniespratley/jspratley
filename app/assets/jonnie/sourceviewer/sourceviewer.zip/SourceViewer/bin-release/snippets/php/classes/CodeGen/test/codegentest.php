<?php
/**
 * <?xml version="1.0" encoding="UTF-8"?>
<schema name="database">
	<table name="users">
		<field name="id" type="int" length="11" key="true" options="auto_increment"/>
		<field name="username" type="varchar" length="225"/>
		<field name="password" type="varchar" length="225"/>
		<field name="email" type="varchar" length="225"/>
		<field name="created" type="timestamp"/>
	</table>
</schema>

$doc = new DOMDocument();
$doc->load( 'books.xml' );
  
$books = $doc->getElementsByTagName( "book" );

foreach( $books as $book )
{
	$authors = $book->getElementsByTagName( "author" );
	$author = $authors->item(0)->nodeValue;
  
	$publishers = $book->getElementsByTagName( "publisher" );
	$publisher = $publishers->item(0)->nodeValue;
  
	echo "$title - $author - $publisher\n";
}
 */

$dom = new DOMDocument( '1.0' );

/************************************
 * Builds the root 
 ************************************/
//create a element
$schema = $dom->createElement( 'schema' );
//set the element on itself
$schema = $dom->appendChild( $schema );
//set a attribute for the schema node 
$schema->setAttribute( 'name', 'traveljournal' ); 


/***********************************
 * Builds the table inside the root
 **********************************/
//create a element
$table = $dom->createElement( 'table' );
//set the element on itself
$table = $dom->appendChild( $table );
//set a attribute
$table->setAttribute( 'name', 'users' );


/***********************************
 * Builds the attributes inside the table
 **********************************/
//create a element
$field = $dom->createElement( 'field' );
//set the element on itself
$field = $dom->appendChild( $field );
//set the name attribute
$field->setAttribute( 'name', 'fieldname' );
//set the type attribute
$field->setAttribute( 'type', 'fieldtype' );
//set the value/length attribute
$field->setAttribute( 'values', 'fieldlength' );
//set the null attribute
$field->setAttribute( 'null', 'false' );
//set the default
$field->setAttribute( 'default', 'username here' );
//set the key
$field->setAttribute( 'key', 'PRIMARY | INDEX | UNIQUE | FULLTEXT | NULL' );





//put the field inside of the table
$table->appendChild( $field );
//put the table inside of the schema
$schema->appendChild( $table );



$xml = $dom->saveXML();
header ( "Content-type: text/xml" );
echo $xml;
?>