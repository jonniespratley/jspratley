<?php 
require_once '../LocationsService.php';
require_once '../vo/LocationsVO.php';


			$id = "";
			$loc_address = "";
			$loc_city = "";
			$loc_country = "";
			$loc_created = "";
			$loc_date = "";
			$loc_guests = "";
			$loc_state = "";
			$loc_title = "";
			$loc_zip = "";
			$map_id = "";
			$type_id = "";
			$user_id = "";
$id = '';

if ( $_GET['id'] )
{
	$id = $_GET['id'];
	$service = new LocationsService();
	$recordVO = new LocationsVO();
	$record = $service->getOneLocations( $id ); 
	$recordVO = $record[0];//First object in array
	
	
			$id = $recordVO->id;
			$loc_address = $recordVO->loc_address;
			$loc_city = $recordVO->loc_city;
			$loc_country = $recordVO->loc_country;
			$loc_created = $recordVO->loc_created;
			$loc_date = $recordVO->loc_date;
			$loc_guests = $recordVO->loc_guests;
			$loc_state = $recordVO->loc_state;
			$loc_title = $recordVO->loc_title;
			$loc_zip = $recordVO->loc_zip;
			$map_id = $recordVO->map_id;
			$type_id = $recordVO->type_id;
			$user_id = $recordVO->user_id;
	
	
}
?>
<?php include '_header.php'; ?>
<form id="formLocations" name="formLocations" method="post" action="LocationsList.php">
	 
	
	
			<div>
		 		<label for="id">Id</label>
		 		<input type="text" name="id" value="<?php echo $id; ?>"/>
		 	</div>
			<div>
		 		<label for="loc_address">Loc_address</label>
		 		<input type="text" name="loc_address" value="<?php echo $loc_address; ?>"/>
		 	</div>
			<div>
		 		<label for="loc_city">Loc_city</label>
		 		<input type="text" name="loc_city" value="<?php echo $loc_city; ?>"/>
		 	</div>
			<div>
		 		<label for="loc_country">Loc_country</label>
		 		<input type="text" name="loc_country" value="<?php echo $loc_country; ?>"/>
		 	</div>
			<div>
		 		<label for="loc_created">Loc_created</label>
		 		<input type="text" name="loc_created" value="<?php echo $loc_created; ?>"/>
		 	</div>
			<div>
		 		<label for="loc_date">Loc_date</label>
		 		<input type="text" name="loc_date" value="<?php echo $loc_date; ?>"/>
		 	</div>
			<div>
		 		<label for="loc_guests">Loc_guests</label>
		 		<input type="text" name="loc_guests" value="<?php echo $loc_guests; ?>"/>
		 	</div>
			<div>
		 		<label for="loc_state">Loc_state</label>
		 		<input type="text" name="loc_state" value="<?php echo $loc_state; ?>"/>
		 	</div>
			<div>
		 		<label for="loc_title">Loc_title</label>
		 		<input type="text" name="loc_title" value="<?php echo $loc_title; ?>"/>
		 	</div>
			<div>
		 		<label for="loc_zip">Loc_zip</label>
		 		<input type="text" name="loc_zip" value="<?php echo $loc_zip; ?>"/>
		 	</div>
			<div>
		 		<label for="map_id">Map_id</label>
		 		<input type="text" name="map_id" value="<?php echo $map_id; ?>"/>
		 	</div>
			<div>
		 		<label for="type_id">Type_id</label>
		 		<input type="text" name="type_id" value="<?php echo $type_id; ?>"/>
		 	</div>
			<div>
		 		<label for="user_id">User_id</label>
		 		<input type="text" name="user_id" value="<?php echo $user_id; ?>"/>
		 	</div>
    
    <div>
    	<input type="hidden" name="id" value="<?php echo $id; ?>"/>
	   <input name="save" type="submit" value="Save" />
		<button onclick="window.location='LocationsList.php'">Back</button>
    </div>
</form>
 <?php include '_footer.php'; ?>