</div><!-- ends #content -->
<div id="footer">
	<p>Copywrite 2009 | @APPLICATION</p>
</div><!-- ends #footer -->
</div><!-- ends #container -->
</body>
</html>