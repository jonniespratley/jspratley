<?php

include 'Required.php';

class FlexRESTServiceGen implements IGenerate
{

	/**
	 * Enter description here...
	 *
	 * @param unknown_type $namespace
	 * @param unknown_type $database
	 * @param unknown_type $table
	 * @param unknown_type $fields
	 */
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		$filename = ucfirst( $database ).'RESTService.as';
		
		//make the folder namespace
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		$namespace = Utilities::namespaceApplication ( $namespace );

		$serviceGetCall = '';
		$serviceSaveCall = '';
		$serviceRemoveCall = '';
		$serviceTableSelected = '';
		$serviceTableCollection = '';
		$serviceGetResult = '';
		$serviceSaveResult = '';
		$serviceRemoveResult = '';
		$serviceComments = '';
		
		//loop all tables in array
		foreach ( $table as $tbl )
		{
			$tableOrgName = $tbl [ 'table' ];
			$tableUFirstName = ucfirst( $tbl [ 'table' ] );
			$tableUCName = strtoupper( $tbl [ 'table' ] );
			$tableLCName = strtolower( $tbl [ 'table' ] );
			
			$serviceComments .= '
			/* ****************************************************************
 			* TABLE: '.$tableOrgName.'
 			* CALLS: get'.$tableUFirstName.', save'.$tableUFirstName.', remove'.$tableUFirstName.'
 			* ****************************************************************/';
			
			//Create the selected table
			$serviceTableSelected .= '
			[Bindable] static public var SELECTED_'.$tableUCName.':'.$tableUFirstName.'VO';
				
			//create the collection of table objects
			$serviceTableCollection .= '
			[Bindable] static public var '.$tableUCName.'_COLLECTION:ArrayCollection;';

			$serviceGetCall .= '
			public function get'.$tableUFirstName.'():void
			{
				this.sendQuery( "'.$tableOrgName.'", "get", "", null, onResult_get'.$tableUFirstName.' );
			}
			';
					
			$serviceSaveCall .= '
			public function save'.$tableUFirstName.'( '.$tableLCName.':'.$tableUFirstName.'VO ):void
			{
				this.sendQuery( "'.$tableOrgName.'", "save", '.$tableLCName.'.toQueryString(), '.$tableLCName.', onResult_save'.$tableUFirstName.' );
			}
			';
			
			$serviceRemoveCall .= '
			public function remove'.$tableUFirstName.'( '.$tableLCName.':'.$tableUFirstName.'VO, index:int ):void
			{
				this.sendQuery( "'.$tableOrgName.', "remove", '.$tableLCName.'.toQueryString(), index, onResult_remove'.$tableUFirstName.' );
			}
			';
			
	
		/* Create the onResult_get */
		$serviceGetResult .= '
		private function onResult_get'.$tableUFirstName.'( event:ResultEvent ):void
		{
			if ( event.result is String )
			{
				var rawData:String = String( event.result );
				var jsonArray:Array = ( JSON.decode( rawData ) as Array );
				var tempAC:ArrayCollection = new ArrayCollection();

				for ( var s:String in jsonArray )
				{
					tempAC.addItem( new '.$tableUFirstName.'VO( jsonArray[ s ] ) );
				}
				'.ucfirst( $database ).'RESTService.'.$tableUCName.'_COLLECTION = tempAC;
			}
		}
		';
		
		/* Create the onResult_save */			
		$serviceSaveResult .= '
		private function onResult_save'.$tableUFirstName.'( event:ResultEvent ):void
		{
			'.ucfirst( $database ).'RESTService.'.'SERVICE_DUMP += "Service Result Token: " + event.result.toString();
		}
		';
		
		//Create the onResult_remove
		$serviceRemoveResult .= '
		private function onResult_remove'.$tableUFirstName.'( event:ResultEvent ):void
		{
			var index:int = event.token.resultToken;

			'.ucfirst( $database ).'RESTService.'.$tableUCName.'_COLLECTION.removeItemAt( index );
			'.ucfirst( $database ).'RESTService.SERVICE_DUMP += "\nService Result Token: " + index;
			
		}
		';
				
		}//ends table for loop
		
		$databaseService = FileSystemService::readFile ( TemplateManager::$FLEX_TEMPLATE_LOCATION.'FlexRESTService.txt' );

		$template = preg_replace ( TemplateManager::$DATABASE_PATTERN, ucfirst( $database ), $databaseService );
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $template );
		//$template = preg_replace ( TemplateManager::$SERVICE_COMMENTS_PATTERN, $serviceComments, $template );
		
		$template = preg_replace ( TemplateManager::$TABLE_SELECTED_PATTERN, $serviceTableSelected, $template );
		$template = preg_replace ( TemplateManager::$TABLE_COLLECTION_PATTERN, $serviceTableCollection, $template );
		
		$template = preg_replace ( TemplateManager::$SERVICE_GET_CALL_PATTERN, $serviceGetCall, $template );
		$template = preg_replace ( TemplateManager::$SERVICE_SAVE_CALL_PATTERN, $serviceSaveCall, $template );
		$template = preg_replace ( TemplateManager::$SERVICE_REMOVE_CALL_PATTERN, $serviceRemoveCall, $template );
		
		$template = preg_replace ( TemplateManager::$SERVICE_REMOVE_RESULT_PATTERN, $serviceRemoveResult, $template );
		$template = preg_replace ( TemplateManager::$SERVICE_SAVE_RESULT_PATTERN, $serviceSaveResult, $template );
		$template = preg_replace ( TemplateManager::$SERVICE_GET_RESULT_PATTERN, $serviceGetResult, $template );
		
		Utilities::checkOrMakeFolders ( TemplateManager::$CLIENT_OUTPUT, $folderNamespace, 'services' );
		FileSystemService::writeFile ( TemplateManager::$CLIENT_OUTPUT . $folderNamespace . '/services/' . $filename, $template );
		
		return 'Generated Flex REST Service for ' . $database;
	}
}

?>