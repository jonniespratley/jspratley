<?php/**  * I am a object representing the Locations table. *  * @version 1.6 * @author Jonnie Spratley (http://jonniespratley.com/code) * * @package com.jonniespratley.test.VO * @name LocationsVO.php */class LocationsVO{	var $_explicitType = 'com.jonniespratley.test.VO.LocationsVO';		
			public $id;
			public $loc_title;
			public $loc_address;
			public $loc_city;
			public $loc_state;
			public $loc_country;
			public $loc_zip;
			public $loc_date;
			public $loc_guests;
			public $type_id;
			public $map_id;
			public $user_id;
			public $loc_created;		public function __construct( $vo )	{		
			$this->id = $vo["id"];
			$this->loc_title = $vo["loc_title"];
			$this->loc_address = $vo["loc_address"];
			$this->loc_city = $vo["loc_city"];
			$this->loc_state = $vo["loc_state"];
			$this->loc_country = $vo["loc_country"];
			$this->loc_zip = $vo["loc_zip"];
			$this->loc_date = $vo["loc_date"];
			$this->loc_guests = $vo["loc_guests"];
			$this->type_id = $vo["type_id"];
			$this->map_id = $vo["map_id"];
			$this->user_id = $vo["user_id"];
			$this->loc_created = $vo["loc_created"];	}	}?>                                          