<?php
/**
 * @name  	PHPGen.php
 * @author  Jonnie Spratley
 * @version 1.8
 * @description 
 * 
 * This class holds all of the static methods 
 * for creating all the neccessary files for the PHP on the server side.
 * 
 * 
 */
//require_once 'ConfigReader.php';
require_once 'SchemaManager.php';
require_once 'FileSystemService.php';
require_once 'ConfigManager.php';

class CodeGen
{
	private $mysqli;
	private $log;
	private $config;
	
	public function __construct()
	{
	}
	
	/**
	 * I am the constructore for the CodeGen
	 *
	 * 
	 * @param [string] $configFile The config.xml file
	 */
	public function start( $filepath, $database )
	{
		ConfigManager::readConfig ( $filepath, $database );
		$this->mysqli = new mysqli ( ConfigManager::getHost (), ConfigManager::getUser (), ConfigManager::getPass () );
	}
	
	/**
	 * I write the schema.xml file that is a copy of the structure from the database.
	 *
	 * @return [none]
	 */
	public function writeSchema( $filepath )
	{
		return SchemaManager::writeSchema ( $this->mysqli, $filepath, ConfigManager::getDatabase () );
	}
	
	/**
	 * I generate the code from what the schema.xml file defines.
	 *
	 * @param [string] $schema The location of the DatabaseSchema.xml file
	 * @return [none] Generated Code in output folder
	 */
	public function generateCode( $filepath )
	{
		return SchemaManager::readSchema ( $filepath, ConfigManager::getDatabase () );
	}
	
	/**
	 * I browse the directory and return a array of folders, and files
	 *
	 * @param [string] $path the path, defaults to '.';
	 * @param [int] $level how deep
	 * @return [array]
	 */
	public function browseDirectory( $path, $level )
	{
		return FileSystemService::browseDirectory ( $path, $level );
	}
	
	/**
	 * I read the contents of a file.
	 *
	 * @param [string] $file the file path
	 * @return [string] the contents
	 */
	static public function readFile( $file )
	{
		return FileSystemService::readFile ( $file );
	}
	
	/**
	 * I write data to a file
	 *
	 * @param [string] $file the file path
	 * @param [string] $contents the file contents
	 * @return [string] true or false
	 */
	public function writeFile( $file, $contents )
	{
		return FileSystemService::writeFile ( $file, $contents );
	}
	
	private function execute( $sql )
	{
		return $this->mysqli->query ( $sql );
	}
	
	/**
	 * I write the config.xml file from the users information
	 *
	 * @param [string] $host - database host
	 * @param [string] $user - database user
	 * @param [string] $pass - database password
	 * @param [string] $app - application name
	 * @param [string] $schema - name of database
	 * @param [string] $endpoint - url of service file
	 * @param [string] $namespace - namespace of developer
	 * @return [string] location of config.xml
	 */
	static public function writeConfig( $filepath, $host, $user, $pass, $schema, $app, $endpoint, $namespace, $framework, $copywrite )
	{
		return ConfigManager::writeConfig ( $filepath, $host, $user, $pass, $schema, $app, $endpoint, $namespace, $framework, $copywrite );
	}
}
?>