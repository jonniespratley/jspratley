<div class="title">
	<h2>Settings</h2>	
</div>

<?php

include 'includes/settings/_settings_database.php';
include 'includes/settings/_settings_sdk.php';

?>