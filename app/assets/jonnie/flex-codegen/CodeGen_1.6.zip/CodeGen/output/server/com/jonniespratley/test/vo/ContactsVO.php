<?php/**  * I am a object representing the Contacts table. *  * @version 1.6 * @author Jonnie Spratley (http://jonniespratley.com/code) * * @package com.jonniespratley.test.VO * @name ContactsVO.php */class ContactsVO{	var $_explicitType = 'com.jonniespratley.test.VO.ContactsVO';		
			public $id;
			public $name;
			public $address;
			public $city;
			public $state;
			public $country;
			public $email;
			public $phone;
			public $zip;
			public $date;		public function __construct( $vo )	{		
			$this->id = $vo["id"];
			$this->name = $vo["name"];
			$this->address = $vo["address"];
			$this->city = $vo["city"];
			$this->state = $vo["state"];
			$this->country = $vo["country"];
			$this->email = $vo["email"];
			$this->phone = $vo["phone"];
			$this->zip = $vo["zip"];
			$this->date = $vo["date"];	}	}?>                                          