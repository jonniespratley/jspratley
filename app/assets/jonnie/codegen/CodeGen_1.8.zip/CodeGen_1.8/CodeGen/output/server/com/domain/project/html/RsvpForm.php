<?php 
require_once '../RsvpService.php';
require_once '../vo/RsvpVO.php';


			$email = "";
			$first = "";
			$id = "";
			$last = "";
			$phone = "";
			$state = "";
$id = '';

if ( $_GET['id'] )
{
	$id = $_GET['id'];
	$service = new RsvpService();
	$recordVO = new RsvpVO();
	$record = $service->getOneRsvp( $id ); 
	$recordVO = $record[0];//First object in array
	
	
			$email = $recordVO->email;
			$first = $recordVO->first;
			$id = $recordVO->id;
			$last = $recordVO->last;
			$phone = $recordVO->phone;
			$state = $recordVO->state;
	
	
}
?>
<?php include '_header.php'; ?>
<form id="formRsvp" name="formRsvp" method="post" action="RsvpList.php">
	 
	
	
			<div>
		 		<label for="email">Email</label>
		 		<input type="text" name="email" value="<?php echo $email; ?>"/>
		 	</div>
			<div>
		 		<label for="first">First</label>
		 		<input type="text" name="first" value="<?php echo $first; ?>"/>
		 	</div>
			<div>
		 		<label for="id">Id</label>
		 		<input type="text" name="id" value="<?php echo $id; ?>"/>
		 	</div>
			<div>
		 		<label for="last">Last</label>
		 		<input type="text" name="last" value="<?php echo $last; ?>"/>
		 	</div>
			<div>
		 		<label for="phone">Phone</label>
		 		<input type="text" name="phone" value="<?php echo $phone; ?>"/>
		 	</div>
			<div>
		 		<label for="state">State</label>
		 		<input type="text" name="state" value="<?php echo $state; ?>"/>
		 	</div>
    
    <div>
    	<input type="hidden" name="id" value="<?php echo $id; ?>"/>
	   <input name="save" type="submit" value="Save" />
		<button onclick="window.location='RsvpList.php'">Back</button>
    </div>
</form>
 <?php include '_footer.php'; ?>