<?php 
require_once '../PostsService.php';
require_once '../vo/PostsVO.php';


			$body = "";
			$excerpt = "";
			$id = "";
			$title = "";
$id = '';

if ( $_GET['id'] )
{
	$id = $_GET['id'];
	$service = new PostsService();
	$recordVO = new PostsVO();
	$record = $service->getOnePosts( $id ); 
	$recordVO = $record[0];//First object in array
	
	
			$body = $recordVO->body;
			$excerpt = $recordVO->excerpt;
			$id = $recordVO->id;
			$title = $recordVO->title;
	
	
}
?>
<?php include '_header.php'; ?>
<form id="formPosts" name="formPosts" method="post" action="PostsList.php">
	 
	
	
			<div>
		 		<label for="body">Body</label>
		 		<input type="text" name="body" value="<?php echo $body; ?>"/>
		 	</div>
			<div>
		 		<label for="excerpt">Excerpt</label>
		 		<input type="text" name="excerpt" value="<?php echo $excerpt; ?>"/>
		 	</div>
			<div>
		 		<label for="id">Id</label>
		 		<input type="text" name="id" value="<?php echo $id; ?>"/>
		 	</div>
			<div>
		 		<label for="title">Title</label>
		 		<input type="text" name="title" value="<?php echo $title; ?>"/>
		 	</div>
    
    <div>
    	<input type="hidden" name="id" value="<?php echo $id; ?>"/>
	   <input name="save" type="submit" value="Save" />
		<button onclick="window.location='PostsList.php'">Back</button>
    </div>
</form>
 <?php include '_footer.php'; ?>