<?php 
require_once 'CodeGen.php';
require_once 'library/CGManager.php';
$host = '';
$user = '';
$pass = '';
$application = '';
$schema = '';
$namespace = '';
$endpoint = '';

$configMessage = '';
$schemaMessage = '';
$appMessage = '';
$configLocation = '';
$schemaLocation = '';
$appOutputLog = '';

if ( isset( $_POST['btn_generateConfig'] ) )
{
	if ( isset ( $_POST[ 'txt_host' ] ) )
	{
		$host = $_POST[ 'txt_host' ]; //Host
	}
	
	if ( isset ( $_POST[ 'txt_user' ] ) )
	{
		$user = $_POST[ 'txt_user' ]; //User
	}
	
	if ( isset ( $_POST[ 'txt_pass' ] ) )
	{
		$pass = $_POST[ 'txt_pass' ]; //Pass
	}
	
	if ( isset ( $_POST[ 'txt_application' ] ) )
	{
		$application = $_POST[ 'txt_application' ]; //Application
	}
	
	if ( isset ( $_POST[ 'txt_schema' ] ) )
	{
		$schema = $_POST[ 'txt_schema' ]; //Database
	}
	
	if ( isset ( $_POST[ 'txt_namespace' ] ) )
	{
		$namespace = $_POST[ 'txt_namespace' ]; //Namespace
	}
	
	if ( isset ( $_POST[ 'txt_endpoint' ] ) )
	{
		$endpoint = $_POST[ 'txt_endpoint' ]; //Endpoint
	}
	
	 $configLocation = CodeGen::writeConfig( $host, $user, $pass, $application, $schema, $endpoint, $namespace );
	 $configMessage = 'Config file written.';
}

//Generate Schema.xml
if ( isset( $_POST['btn_generateSchema'] ) )
{
	$codegen = new CodeGen( $_POST['txt_configlocation'] );
	$schemaLocation = $codegen->writeSchema();
	if ( $schemaLocation )
	{
		$schemaMessage = 'Schema file written.';
	}
}

//Generate Application
if ( isset( $_POST['btn_generateApp'] ) )
{
	$codegen = new CodeGen( $_POST['txt_configlocation'] );
	$appOutputLog = $codegen->generateCode( $_POST['txt_schemaLocation'] );
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>CodeGen<?php echo CGManager::$CG_VERSION ?></title>


<script src="assets/jquery/jquery-1.2.6.js" type="text/javascript"></script>
<script src="assets/jquery/jquery-1.3.2.js" type="text/javascript"></script>
<script src="assets/jquery/ui/ui.core.js" type="text/javascript"></script>
<script src="assets/jquery/ui/ui.tabs.js" type="text/javascript"></script>
<link href="assets/jquery/themes/flora/flora.tabs.css" rel="stylesheet" type="text/css" />
<link href="assets/CodeGen.css" rel="stylesheet" type="text/css" />

</head>
<body>
<div id="head">
  <h1>CodeGen <?php echo CGManager::$CG_VERSION; ?></h1>
</div>
<div id="wrapper">
  <div id="container">
    <div class="console"> <?php echo "<p>$configMessage</p>"; ?> <?php echo "<p>$schemaMessage</p>"; ?> <?php echo "<p>$appMessage</p>"; ?> </div>
    <div id="jQueryUITabs1">
      <ul>
        <li><a href="#jQueryUITabs1-1"><span>Step 1</span></a></li>
        <li><a href="#jQueryUITabs1-2"><span>Step 2</span></a></li>
        <li><a href="#jQueryUITabs1-3"><span>Step 3</span></a></li>
        <li><a href="#jQueryUITabs1-4"><span>Step 4</span></a></li>
		
      </ul>
      
	  <form id="form_config" name="form_config" method="post" action="">
        <div id="jQueryUITabs1-1"> <strong>Step 1</strong>
          <p>
            <label for="txt_host">Database Host:</label>
            <input name="txt_host" type="text" class="text"  id="txt_host" value="<?php echo ( isset ( $_POST[ 'txt_host' ] ) ) ? htmlspecialchars( $_POST['txt_host'] ) : $host; ?>" />
          </p>
          <p>
            <label for="txt_user">Database Username:</label>
            <input name="txt_user" type="text" class="text" id="txt_user" value="<?php echo ( isset ( $_POST[ 'txt_user' ] ) ) ? htmlspecialchars( $_POST['txt_user'] ) : $user; ?>" />
          </p>
          <p>
            <label for="txt_pass">Database Password:</label>
            <input name="txt_pass" type="text" class="text" id="txt_pass" value="<?php echo ( isset ( $_POST[ 'txt_pass' ] ) ) ? htmlspecialchars( $_POST['txt_pass'] ) : $pass; ?>" />
          </p>
          <p>
            <label for="txt_schema">Database:</label>
            <input name="txt_schema" type="text" class="text" id="txt_schema" value="<?php echo ( isset ( $_POST[ 'txt_schema' ] ) ) ? htmlspecialchars( $_POST['txt_schema'] ) : $schema; ?>" />
          </p>
         
        </div>
        <div id="jQueryUITabs1-2"> <b>Step 2</b>
          <p>
            <label for="txt_application">Application Name:</label>
            <input name="txt_application" type="text" class="text" id="txt_application" value="<?php echo ( isset ( $_POST[ 'txt_application' ] ) ) ? htmlspecialchars( $_POST['txt_application'] ) : $application; ?>" />
          </p>
          <p>
            <label for="txt_namespace">Application Namespace:</label>
            <input name="txt_namespace" type="text" class="text" id="txt_namespace" value="<?php echo ( isset ( $_POST[ 'txt_namespace' ] ) ) ? htmlspecialchars( $_POST['txt_namespace'] ) : $namespace; ?>" />
          </p>
          <p>
            <label for="txt_endpoint">Service Endpoint URL:</label>
            <input name="txt_endpoint" type="text" class="text" id="txt_endpoint" value="<?php echo ( isset ( $_POST[ 'txt_endpoint' ] ) ) ? htmlspecialchars( $_POST['txt_endpoint'] ) : $endpoint; ?>" />
          </p>
          <p>
            <label>Server Side Type:</label>
            <label>
              <input type="radio" name="rbg_serverSideType" value="rest" id="rbg_serverSideType_0" />
              REST (JSON)</label>
            <br />
            <label>
              <input type="radio" name="rbg_serverSideType" value="amfphp" id="rbg_serverSideType_1" />
              AMFPHP (Remote Object)</label>
            <br />
          </p>
		  
          <p>
            <label>Client Side Framework:</label>
            <label>
              <input type="radio" name="rbg_clientSideType" value="cairngorm" id="rbg_clientSideType_0" />
              Cairngorm </label>
            <br />
            <label>
              <input type="radio" name="rbg_clientSideType" value="flex" id="rbg_clientSideType_1" />
              Flex Remoting/AS3</label>
            <br />
          </p>
		  
          <p>
            <input type="submit" name="btn_generateConfig" id="btn_generateConfig" value=">Generate Config"/>
          </p>
		  
        </div>
      </form>
	  
	  
      <div id="jQueryUITabs1-3">
      <h2>Generate Schema</h2>
        <form id="form_schema" name="form_schema" method="post" action="">
          <p>
            <label for="txt_configlocation">Config File:</label>
            <input name="txt_configlocation" type="text" class="text" id="txt_configlocation" value="<?php echo ( isset ( $_POST[ 'txt_configlocation' ] ) ) ? htmlspecialchars( $_POST['txt_configlocation'] ) : $configLocation; ?>" />
          </p>
          <?php 
            if ( $host && $user && $pass && $application && $schema && $namespace && $endpoint )
            {
	            echo "<ul>";
	            echo "<li>Host: $host</li>";
	            echo "<li>User: $user</li>";
	            echo "<li>Password: $pass</li>";
	            echo "<li>Schema: $schema</li>";
	            echo "<li>Application: $application</li>";
	            echo "<li>Namespace: $namespace</li>";
	            echo "<li>Endpoint $endpoint</li>";
	            echo "</ul>";
            	echo "Does your information look correct?";
            }
          ?>
          <p>
            <input type="submit" name="btn_generateSchema" id="btn_generateSchema" value="Generate Schema" />
          </p>
        </form>
      </div>
	  
	  
      <div id="jQueryUITabs1-4">
        <h2>Generate Application</h2>
        <form id="form_app" name="form_app" method="post" action="">
          <p>
            <label for="txt_configlocation">Config File:</label>
            <input name="txt_configlocation" type="text" class="text" id="txt_configlocation" value="<?php echo ( isset ( $_POST[ 'txt_configlocation' ] ) ) ? htmlspecialchars( $_POST['txt_configlocation'] ) : $configLocation; ?>" />
          </p>
          <p>
            <label for="txt_schemaLocation">Schema File:</label>
            <input name="txt_schemaLocation" type="text" class="text" id="txt_schemaLocation" value="<?php echo ( isset ( $_POST[ 'txt_schemaLocation' ] ) ) ? htmlspecialchars( $_POST['txt_schemaLocation'] ) : $schemaLocation; ?>" />
          </p>
          <p>
            <input type="submit" name="btn_generateApp" id="btn_generateApp" value="Generate Application" />
          </p>
        </form>
      </div>
	  
	  
    </div>
    
    <div id="dump">
    <?php 
    echo '<pre>';
    print_r( CGManager::GET_CG_LOG() );
    echo '</pre>';
    ?>
    </div>
    
    <script type="text/javascript">
// BeginWebWidget jQuery_UI_Tabs: jQueryUITabs1
jQuery("#jQueryUITabs1 > ul").tabs({ event: "click" });

// EndWebWidget jQuery_UI_Tabs: jQueryUITabs1
     </script>
  </div>
</div>
</body>
</html>