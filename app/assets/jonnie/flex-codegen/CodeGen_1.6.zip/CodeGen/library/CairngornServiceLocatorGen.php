<?php

include 'Required.php';

class CairngormServiceLocatorGen implements IGenerate
{
	
	public static function generate( $namespace, $database, $table, $fields = null )
	{		
		$config = new ConfigReader ( );
		$config->readConfig ( TemplateManager::$CONFIG_OUTPUT.'/'.ucfirst($database ).'Config.xml' );
		$endpoint = $config->getEndpoint ();
		
		//Create the fileame
		$filename = 'Services.mxml';
		
		//make the folder namespace
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		$namespace = Utilities::namespaceApplication ( $namespace );
		
		$serviceLocator = '';
		
		foreach ( $table as $tbl )
		{
			$serviceLocator .= '
			<mx:RemoteObject
		    	id="' . $tbl [ 'table' ] . 'Service"
		    	destination="amfphp"
		    	endpoint="' . $endpoint . '"
		    	source="' . $namespace . '.' . $tbl [ 'table' ] . 'Service"
		    	showBusyCursor="true"
		    	makeObjectsBindable="true">
		    </mx:RemoteObject>';
		}
		
		$tableService = FileSystemService::readFile ( TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'Services.txt' );
		
		//replace the table name inside of the template
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $tableService );
		$template = preg_replace ( TemplateManager::$ENDPOINT_PATTERN, $endpoint, $template );
		$template = preg_replace ( TemplateManager::$TABLE_PATTERN, $serviceLocator, $template );
		
		Utilities::checkOrMakeFolders ( TemplateManager::$CLIENT_OUTPUT, $folderNamespace, 'business' );
		FileSystemService::writeFile ( TemplateManager::$CLIENT_OUTPUT . $folderNamespace . '/business/' . $filename, $template );
		
		return 'Generated Cairngorm Service Locator';
	}
}

?>