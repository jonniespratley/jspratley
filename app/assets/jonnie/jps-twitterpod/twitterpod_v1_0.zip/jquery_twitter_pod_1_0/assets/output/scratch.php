<?php 
$rawJson = file_get_contents('output-getFriendsTimeline.json', 'r');
$arrayJson = json_decode($rawJson, true);
$length = count($arrayJson);
//INSERT INTO twitterpod.tweets (id,text,created_at,source,truncated,favorited,in_reply_to_screen_name,in_reply_to_status_id,in_reply_to_user_id,user_id)
//VALUES ('$id','$text','$created','$source','$trunicated','$favorited','$reply_screen_name','$reply_status_id','$reply_user_id','$user_id');

foreach ($arrayJson as $array) 
{
    $sql = '';
    $sql .= "INSERT INTO twitterpod.tweets (id,text,created_at,source,truncated,favorited,in_reply_to_screen_name,in_reply_to_status_id,in_reply_to_user_id,user_id)";
    $sql .= 'VALUES ('. $array["id"].',"'.addslashes($array["text"]).'","'.$array["created_at"].'","'.addslashes($array["source"]).'","'.$array["truncated"].'","'.$array["favorited"].'","'.$array["in_reply_to_screen_name"].'","'.$array["in_reply_to_status_id"].'","'.$array["in_reply_to_user_id"].'","'.$array["user_id"].'");';					
    $sql .= "\n";
    echo $sql;
}			


?>