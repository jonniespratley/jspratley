<?php include '_header.php'; ?>
<h2>Select a Table</h2>    
<ul>
	
			<li><a href="CategoriesList.php">Categories</a></li>
			
			<li><a href="CommentsList.php">Comments</a></li>
			
			<li><a href="ContactsList.php">Contacts</a></li>
			
			<li><a href="EntriesList.php">Entries</a></li>
			
			<li><a href="LocationsList.php">Locations</a></li>
			
			<li><a href="Locations_tagsList.php">Locations_tags</a></li>
			
			<li><a href="MapsList.php">Maps</a></li>
			
			<li><a href="PostsList.php">Posts</a></li>
			
			<li><a href="RsvpList.php">Rsvp</a></li>
			
			<li><a href="States_stateList.php">States_state</a></li>
			
			<li><a href="TagsList.php">Tags</a></li>
			
			<li><a href="Test_entries_viewList.php">Test_entries_view</a></li>
			
			<li><a href="TypesList.php">Types</a></li>
			
			<li><a href="UploadsList.php">Uploads</a></li>
			
			<li><a href="UsersList.php">Users</a></li>
			
</ul>
<?php include '_footer.php'; ?>