<?php

include 'Required.php';

class FlexApplicationGen implements IGenerate
{
	
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		$config = new ConfigReader();
		$config->readConfig( TemplateManager::$CONFIG_OUTPUT.'/'.ucfirst($database ).'Config.xml' );		
		
		//make the folder namespace com/jonnie/test/
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		
		//make the actual namespace com.jonnie.test
		$namespace = Utilities::namespaceApplication ( $namespace );
		
		$tableComponents = '';
		$tableNamespaces = '';
		
		//Build the form inputs
		foreach ( $table as $tbl )
		{
			$tableName = ucfirst ( $tbl [ 'table' ] );
			
			$tableComponents .= '
			<'.$tableName.':'.$tableName.'Main  
				label="'.$tableName.'"/>';
			
			$tableNamespaces .='
			xmlns:'.$tableName.'="'.$namespace.'.view.'.$tableName.'.*" ';
		}
			
		$flexForm = FileSystemService::readFile ( TemplateManager::$FLEX_TEMPLATE_LOCATION.'FlexApplicationMain.txt' );

		$template = preg_replace ( TemplateManager::$COMPONENT_NAMESPACE_PATTERN, $tableNamespaces, $flexForm );
		$template = preg_replace ( TemplateManager::$TABLE_PATTERN, $tableComponents, $template );
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $template );
		$template = preg_replace ( TemplateManager::$APPLICATION_PATTERN, $config->getApplication(), $template );
		
		Utilities::checkOrMakeFolders ( TemplateManager::$CLIENT_OUTPUT, $folderNamespace, 'view' );
		FileSystemService::writeFile ( TemplateManager::$CLIENT_OUTPUT . $folderNamespace . '/view/' . ucfirst ( $database ) . 'Main.mxml', $template );
		
		return 'Generating Flex Main Applcation for ' . $database;
	}

}

?>