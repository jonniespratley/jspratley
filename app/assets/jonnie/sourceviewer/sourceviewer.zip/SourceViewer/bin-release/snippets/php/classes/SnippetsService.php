<?php

require_once 'Utilities.php';

class SnippetsService
{
	private $mysqli;
	private $util;
	
	public function __construct()
	{
		$this->mysqli = new mysqli( 'localhost', 'root', 'fred' );
		$this->util = new Utilities();
		
		return $this->mysqli;
	}
	
	
	public function getSnippets()
	{
		return $this->queryToArray( "SELECT * FROM jonniespratleys_code.snippets" );
	}
	
	public function getCategories()
	{
		return $this->queryToArray( "SELECT * FROM jonniespratleys_code.categories" );
	}
	
	public function getVariableByID( $id )
	{
		$variables = $this->realQuery( "SELECT * FROM jonniespratleys_code.variables WHERE id = $id" );
		$xml = '';
		
		while( $row = mysqli_fetch_assoc( $variables ) )
		{
			$xml .= '<variable default="'.$row["default"].'" id="'.$row["id"].'" name="'.$row["name"].'">
						<description>
							<![CDATA['.$row["description"].']]>
						</description>
					</variable>';
		}
		return $xml;
	}
	
	public function getSnippetByCategory( $category )
	{
		$snippets = $this->realQuery( "SELECT * FROM jonniespratleys_code.snippets WHERE category = ". $category );
		$xml = '';
		$idArray = array();
		while( $row = mysqli_fetch_assoc( $snippets ) )
		{
			$xml .= '<item 
						id="'.$row["id"].'" 
						class="'.$row["class"].'" 
						label="'.$row["label"].'" 
						editorclass="'.$row["editorclass"].'" 
						category="'.$row["category"].'" 
						largeicon="'.$row["largeicon"].'" 
						smallicon="'.$row["smallicon"].'">';
			$xml .= '<description>
						<![CDATA[
							'.$row["description"].'
							]]>
					</description>';
			$xml .= '<content>
						<![CDATA[ 
							'.$row["content"].'
						]]>
					</content>';

			//$xml .= $this->getVariableByID(  $row['variables'] );
					
			$xml .= '</item>';
		}
		return $xml;
		//return $idArray;
	}
	
	/**
	 * <category 
	 * filters="*" 
	 * id="category_1" 
	 * initial_state="0" 
	 * label="Loops"
	 * largeicon="" 
	 * smallicon="">
			<description>
				<![CDATA[ Using Loops ]]>
			</description>
	 */		
	public function getCategoriesXML()
	{
		$categories = $this->realQuery( 'SELECT * FROM jonniespratleys_code.categories' );
		$xml = '';
		while ( $row = mysqli_fetch_assoc( $categories ) )
		{
			$xml .= '<!-- '.$row["label"].' -->';
			$xml .= '<category 
						id="'.$row["id"].'"
						filters="'.$row["filters"].'"
						initial_state="'.$row["initial_state"].'"
						largeicon="'.$row["largeicon"].'"
						smallicon="'.$row["smallicon"].'"
						label="'.$row["label"].'">';
			$xml .= '<description>
						<![CDATA[ 
						'.$row["description"].' 
						]]>
					</description>';
			$xml .= $this->getSnippetByCategory( $row['id'] );
	
			$xml .= '</category>';
		}
		echo '<snippets>';
		echo $xml;
		echo '</snippets>';
	}
	
	private function realQuery( $sql )
	{
		return $this->mysqli->query( $sql );
	}
	
	public function queryToArray( $sql )
	{
		$query = $this->realQuery ( $sql );
		$array = array ();
		
		while ( $row = mysqli_fetch_assoc ( $query ) )
		{
			$array [] = $row;
		}
		
		return $array;
	}
	
	
	
}

header ( "Content-type: text/xml" );

$util = new Utilities();


?>