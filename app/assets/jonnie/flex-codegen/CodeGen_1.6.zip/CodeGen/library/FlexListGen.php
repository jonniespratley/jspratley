<?php

include 'Required.php';

class FlexListGen implements IGenerate
{
	//<mx:DataGridColumn headerText="Column 3" dataField="col3"/>
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		$table = ucfirst ( $table );
		
		//make the folder namespace com/jonnie/test/
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		
		//make the actual namespace com.jonnie.test
		$namespace = Utilities::namespaceApplication ( $namespace );
		
		$listFields = '';
		
		/*
		 * Build the datagrid list - <mx:DataGridColumn headerText="Category_id" dataField="category_id"/>
		 */
		foreach ( $fields as $field )
		{
			//prop the datagrid for insertion
			$listFields .= '
			<mx:DataGridColumn headerText="' . ucfirst ( $field [ 'name' ] ) . '" dataField="' . $field [ 'name' ] . '"/>';
		}
		
		//read the template
		$flexForm = FileSystemService::readFile ( TemplateManager::$FLEX_TEMPLATE_LOCATION.'FlexList.txt' );
		
		/* Set and replace the table name*/
		$template = preg_replace ( TemplateManager::$TABLE_PATTERN, $table, $flexForm );
		
		/* Set and replace the namespaces */
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $template );
		
		/* Set and replace the datagrid columns */
		$template = preg_replace ( TemplateManager::$LIST_FIELDS_PATTERN, $listFields, $template );
		
		Utilities::checkOrMakeFolders ( TemplateManager::$CLIENT_OUTPUT, $folderNamespace, 'view/'.$table.'/' );
		FileSystemService::writeFile ( TemplateManager::$CLIENT_OUTPUT . $folderNamespace . '/view/'.$table.'/' .  $table . 'List.mxml', $template );
	
		return 'Generated Flex List for ' . $table;
	}

}

?>