<?php
/**
 * @version 1.6
 * @author Jonnie Spratley (http://jonniespratley.com/code) 
 *
 * @package @NAMESPACE
 */



			require_once ( "CategoriesService.php" );
			require_once ( "vo/CategoriesVO.php" );
			
			require_once ( "CommentsService.php" );
			require_once ( "vo/CommentsVO.php" );
			
			require_once ( "ContactsService.php" );
			require_once ( "vo/ContactsVO.php" );
			
			require_once ( "EntriesService.php" );
			require_once ( "vo/EntriesVO.php" );
			
			require_once ( "LocationsService.php" );
			require_once ( "vo/LocationsVO.php" );
			
			require_once ( "Locations_tagsService.php" );
			require_once ( "vo/Locations_tagsVO.php" );
			
			require_once ( "MapsService.php" );
			require_once ( "vo/MapsVO.php" );
			
			require_once ( "PostsService.php" );
			require_once ( "vo/PostsVO.php" );
			
			require_once ( "RsvpService.php" );
			require_once ( "vo/RsvpVO.php" );
			
			require_once ( "States_stateService.php" );
			require_once ( "vo/States_stateVO.php" );
			
			require_once ( "TagsService.php" );
			require_once ( "vo/TagsVO.php" );
			
			require_once ( "Test_entries_viewService.php" );
			require_once ( "vo/Test_entries_viewVO.php" );
			
			require_once ( "TypesService.php" );
			require_once ( "vo/TypesVO.php" );
			
			require_once ( "UploadsService.php" );
			require_once ( "vo/UploadsVO.php" );
			
			require_once ( "UsersService.php" );
			require_once ( "vo/UsersVO.php" );
			

$mode = '';
$table = '';
$query = '';
$format = '';
$service = '';
$results = '';

if ( isset ( $_GET ) )
{
	$query = $_GET;
	
	if ( isset ( $_GET [ 'm' ] ) )
	{
		$mode = $_GET [ 'm' ]; //Mode
		unset ( $query [ 'm' ] );
	}
	
	if ( isset ( $_GET [ 't' ] ) )
	{
		$table = $_GET [ 't' ]; //Table
		unset ( $query [ 't' ] );
	}
	
	//TODO: Add xml format
	if ( isset ( $_GET [ 'f' ] ) )
	{
		$format = $_GET [ 'f' ]; //Format
	}

}

switch ( $mode )
{
/******************************************** GET FOR EACH TABLE********************************************/
	
	case 'get':	
		switch ( $table )
		{
			
				case "Categories":
					$service = new CategoriesService();
					$results = $service->getAllCategories();
					print_r( json_encode( $results ) );
				break;
				
				case "Comments":
					$service = new CommentsService();
					$results = $service->getAllComments();
					print_r( json_encode( $results ) );
				break;
				
				case "Contacts":
					$service = new ContactsService();
					$results = $service->getAllContacts();
					print_r( json_encode( $results ) );
				break;
				
				case "Entries":
					$service = new EntriesService();
					$results = $service->getAllEntries();
					print_r( json_encode( $results ) );
				break;
				
				case "Locations":
					$service = new LocationsService();
					$results = $service->getAllLocations();
					print_r( json_encode( $results ) );
				break;
				
				case "Locations_tags":
					$service = new Locations_tagsService();
					$results = $service->getAllLocations_tags();
					print_r( json_encode( $results ) );
				break;
				
				case "Maps":
					$service = new MapsService();
					$results = $service->getAllMaps();
					print_r( json_encode( $results ) );
				break;
				
				case "Posts":
					$service = new PostsService();
					$results = $service->getAllPosts();
					print_r( json_encode( $results ) );
				break;
				
				case "Rsvp":
					$service = new RsvpService();
					$results = $service->getAllRsvp();
					print_r( json_encode( $results ) );
				break;
				
				case "States_state":
					$service = new States_stateService();
					$results = $service->getAllStates_state();
					print_r( json_encode( $results ) );
				break;
				
				case "Tags":
					$service = new TagsService();
					$results = $service->getAllTags();
					print_r( json_encode( $results ) );
				break;
				
				case "Test_entries_view":
					$service = new Test_entries_viewService();
					$results = $service->getAllTest_entries_view();
					print_r( json_encode( $results ) );
				break;
				
				case "Types":
					$service = new TypesService();
					$results = $service->getAllTypes();
					print_r( json_encode( $results ) );
				break;
				
				case "Uploads":
					$service = new UploadsService();
					$results = $service->getAllUploads();
					print_r( json_encode( $results ) );
				break;
				
				case "Users":
					$service = new UsersService();
					$results = $service->getAllUsers();
					print_r( json_encode( $results ) );
				break;
					
			
		}//ends table switch
	break;//ends get switch

	
/******************************************** SAVE FOR EACH TABLE********************************************/
	
	case 'save':
		switch ( $table )
		{
			
				case "Categories":
					$service = new CategoriesService();
					$results = $service->saveCategories( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Comments":
					$service = new CommentsService();
					$results = $service->saveComments( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Contacts":
					$service = new ContactsService();
					$results = $service->saveContacts( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Entries":
					$service = new EntriesService();
					$results = $service->saveEntries( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Locations":
					$service = new LocationsService();
					$results = $service->saveLocations( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Locations_tags":
					$service = new Locations_tagsService();
					$results = $service->saveLocations_tags( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Maps":
					$service = new MapsService();
					$results = $service->saveMaps( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Posts":
					$service = new PostsService();
					$results = $service->savePosts( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Rsvp":
					$service = new RsvpService();
					$results = $service->saveRsvp( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "States_state":
					$service = new States_stateService();
					$results = $service->saveStates_state( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Tags":
					$service = new TagsService();
					$results = $service->saveTags( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Test_entries_view":
					$service = new Test_entries_viewService();
					$results = $service->saveTest_entries_view( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Types":
					$service = new TypesService();
					$results = $service->saveTypes( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Uploads":
					$service = new UploadsService();
					$results = $service->saveUploads( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Users":
					$service = new UsersService();
					$results = $service->saveUsers( $query );
					print_r( json_encode( $results ) );
				break;
				
				
		}//ends table switch
	break;//ends save switch
	
	
/******************************************** REMOVE FOR EACH TABLE********************************************/
	
	case 'remove':
		switch ( $table )
		{
			
				case "Categories":
					$service = new CategoriesService();
					$results = $service->removeCategories( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Comments":
					$service = new CommentsService();
					$results = $service->removeComments( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Contacts":
					$service = new ContactsService();
					$results = $service->removeContacts( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Entries":
					$service = new EntriesService();
					$results = $service->removeEntries( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Locations":
					$service = new LocationsService();
					$results = $service->removeLocations( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Locations_tags":
					$service = new Locations_tagsService();
					$results = $service->removeLocations_tags( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Maps":
					$service = new MapsService();
					$results = $service->removeMaps( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Posts":
					$service = new PostsService();
					$results = $service->removePosts( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Rsvp":
					$service = new RsvpService();
					$results = $service->removeRsvp( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "States_state":
					$service = new States_stateService();
					$results = $service->removeStates_state( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Tags":
					$service = new TagsService();
					$results = $service->removeTags( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Test_entries_view":
					$service = new Test_entries_viewService();
					$results = $service->removeTest_entries_view( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Types":
					$service = new TypesService();
					$results = $service->removeTypes( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Uploads":
					$service = new UploadsService();
					$results = $service->removeUploads( $query );
					print_r( json_encode( $results ) );
				break;
				
				case "Users":
					$service = new UsersService();
					$results = $service->removeUsers( $query );
					print_r( json_encode( $results ) );
				break;
				
			
		}//ends table switch
	break;//ends remove switch

}//ends mode switch

?>