<div id="step3" class="box round">
<h3>Application Review</h3>

<form id="form_app">
<?php 

$step3Options = array(
array( 'label' => 'Application Config Location', 'name' => 'txt_configLocation', 'type' => 'text', 'value' => '', 'class' => 'medium' ),
array( 'label' => '', 'name' => 'btn_generateSchema', 'type' => 'button', 'value' => 'Create Schema', 'class' => 'submit' ),
array( 'label' => 'Application Schema Location', 'name' => 'txt_schemaLocation', 'type' => 'text', 'value' => '', 'class' => 'medium' ),
array( 'label' => '', 'name' => 'btn_generateApp', 'type' => 'button', 'value' => 'Create Application', 'class' => 'submit' )
);

$html->doOptions( $step3Options );
?>
</form>
</div>