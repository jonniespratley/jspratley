<?php/**                    My Test Application
                *//**  * I am a object representing the @TABLE table. *  * @version CodeGen - 1.8 * @author CodeGen - Jonnie Spratley (http://jonniespratley.com/code) * * @package com.domain.project.VO * @name RsvpVO.php */class RsvpVO{	/* Official boycott on amphp, because its trash */	//public $_explicitType = 'com.domain.project.vo.RsvpVO';		
			public $email;
			public $first;
			public $id;
			public $last;
			public $phone;
			public $state;		public function __construct(){}		public function mapObject( $vo )	{		
			$this->email = $vo["email"];
			$this->first = $vo["first"];
			$this->id = $vo["id"];
			$this->last = $vo["last"];
			$this->phone = $vo["phone"];
			$this->state = $vo["state"];	}		public function setNamespace( $namespace )	{		$this->explicitType = $namespace;	}		public function __get( $name )	{		return $this->$name;	}		public function __set( $name, $value )	{		$this->$name = $value;	}	}?>                                          