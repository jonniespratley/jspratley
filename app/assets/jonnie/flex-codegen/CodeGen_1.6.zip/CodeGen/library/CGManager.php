<?php

class CGManager
{
	static public $CG_VERSION = 1.6;
	static public $CG_AUTHOR = 'Jonnie Spratley (http://jonniespratley.com/code)';
	static public $CG_LOG = array();	
	
	static public $PHP_VO_GEN;
	static public $PHP_DAO_GEN;
	static public $PHP_REST_GEN;
	static public $PHP_CONN_GEN;
	
	static public $CAIRNGORM_GET_EVENT_GEN;
	static public $CAIRNGORM_SAVE_EVENT_GEN;
	static public $CAIRNGORM_REMOVE_EVENT_GEN;
	static public $CAIRNGORM_GET_COMMAND_GEN;
	static public $CAIRNGORM_SAVE_COMMAND_GEN;
	static public $CAIRNGORM_REMOVE_COMMAND_GEN;
	static public $CAIRNGORM_SERVICE_DELEGATE_GEN;
	static public $CAIRNGORM_VO_GEN;
	static public $CAIRNGORM_MODEL_GEN;
	static public $CAIRNGORM_CONTROLLER_GEN;
	static public $CAIRNGORM_SERVICE_LOCATOR_GEN;
	
	static public $FLEX_APP_GEN;
	static public $FLEX_REST_SERVICE_GEN;
	static public $FLEX_LIST_GEN;
	static public $FLEX_FORM_GEN;
	static public $FLEX_MAIN_GEN;
	
	static public function GET_CG_LOG()
	{
		$log = array
		(
		'PHP_VO_GEN' => self::$PHP_VO_GEN,
		'PHP_DAO_GEN' => self::$PHP_DAO_GEN,
		'PHP_REST_GEN' => self::$PHP_REST_GEN,
		'PHP_CONN_GEN' => self::$PHP_CONN_GEN,
		'CAIRNGORM_GET_EVENT_GEN' => self::$CAIRNGORM_GET_EVENT_GEN,
		'CAIRNGORM_GET_COMMAND_GEN' => self::$CAIRNGORM_GET_COMMAND_GEN,
		'CAIRNGORM_REMOVE_COMMAND_GEN' => self::$CAIRNGORM_REMOVE_COMMAND_GEN,
		'CAIRNGORM_REMOVE_EVENT_GEN' => self::$CAIRNGORM_REMOVE_EVENT_GEN,
		'CAIRNGORM_SAVE_COMMAND_GEN' => self::$CAIRNGORM_SAVE_COMMAND_GEN,
		'CAIRNGORM_SAVE_EVENT_GEN' => self::$CAIRNGORM_SAVE_EVENT_GEN,
		'CAIRNGORM_SERVICE_DELEGATE_GEN' => self::$CAIRNGORM_SERVICE_DELEGATE_GEN,
		'CAIRNGORM_SERVICE_LOCATOR_GEN' => self::$CAIRNGORM_SERVICE_LOCATOR_GEN,
		'CAIRNGORM_VO_GEN' => self::$CAIRNGORM_VO_GEN,
		'CAIRNGORM_CONTROLLER_GEN' => self::$CAIRNGORM_CONTROLLER_GEN,
		'CAIRNGORM_MODEL_GEN' => self::$CAIRNGORM_MODEL_GEN,
		'FLEX_APP_GEN' => self::$FLEX_APP_GEN,
		'FLEX_FORM_GEN' => self::$FLEX_FORM_GEN,
		'FLEX_LIST_GEN' => self::$FLEX_LIST_GEN,
		'FLEX_MAIN_GEN' => self::$FLEX_MAIN_GEN,
		'FLEX_REST_SERVICE_GEN' => self::$FLEX_REST_SERVICE_GEN
		);
		
		
		return $log; 
	}
	
}

?>