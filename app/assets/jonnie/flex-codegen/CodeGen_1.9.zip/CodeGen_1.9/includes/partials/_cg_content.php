<div id="content">
<?php
/* 
 * 
 * @file _cg_content.php
 * @author Jonnie Spratley
 */

$page = '';
if ( isset( $_GET['page'] ) )
{
	$page = $_GET['page'];
	
	switch ( $page )
	{
		case 'create':
			include 'includes/cg_create.php';
		break;

		 case 'inspect':
			include 'includes/inspector/cg_inspector.php';
		break;
		
		case 'generate':
			include 'includes/generator/cg_generate.php';
		break; 
		
		case 'manage':
			include 'includes/manager/cg_manage.php'; 
		break;
		
		case 'settings':
			include 'includes/settings/cg_settings.php'; 
		break;
		
		default:
			include 'includes/dashboard/cg_dashboard.php';
		break;
	}
}


?>
</div><!--/content-->