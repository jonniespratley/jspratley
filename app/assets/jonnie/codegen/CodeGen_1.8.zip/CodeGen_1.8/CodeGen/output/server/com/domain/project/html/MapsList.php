<?php 
require_once '../MapsService.php';
require_once '../vo/MapsVO.php';

$service = new MapsService();
$result = '';
$recordList = '';

if ( isset($_POST['save']) )
{
	unset( $_POST['save'] );
	$recordValues = $_POST;
	$result = $service->saveMaps( $recordValues );	
}

$recordsArray = $service->getAllMaps();
$recordVO = new MapsVO();

for ( $i = 0; $i < count( $recordsArray ); $i++ ) 
{
	$recordVO = $recordsArray[ $i ];
	
	$recordList .= '<tr id="'.$recordVO->id.'">';

	
			$recordList .= "<td>$recordVO->id</td>";
			$recordList .= "<td>$recordVO->location_id</td>";
			$recordList .= "<td>$recordVO->map_lat</td>";
			$recordList .= "<td>$recordVO->map_lon</td>";
			$recordList .= "<td>$recordVO->map_type</td>";
			$recordList .= "<td>$recordVO->user_id</td>";

	$recordList .= '<td class="actions">';
	$recordList .= '<button class="edit" onclick="window.location=\'MapsForm.php?id='.$recordVO->id.'\'">Edit</button>';
	$recordList .= '<button class="delete" onclick=" remove('.$recordVO->id.')">Delete</button></td>';
	$recordList .= '</tr>';
}

?>
<?php include '_header.php'; ?> 

<script type="text/javascript">
var service = '../MapsService.php';

function remove( id ){
	$.get( service, { m: 'remove', id: id }, function(data){
		if ( data ) {
			$('#'+id).fadeOut('slow');
		} else {
			alert( 'There was a problem!' );
		}
	});
}
</script>

<h3>Maps</h3>

    <table width="100%" border="0">
	<tr>
		
			<th scope="col">id</th>
			<th scope="col">location_id</th>
			<th scope="col">map_lat</th>
			<th scope="col">map_lon</th>
			<th scope="col">map_type</th>
			<th scope="col">user_id</th><th scope="col">Actions</th>   
    </tr>
       <?php echo $recordList; ?>
    </table>
    
    <a href="MapsForm.php">New Maps</a>
  
 <?php include '_footer.php'; ?>