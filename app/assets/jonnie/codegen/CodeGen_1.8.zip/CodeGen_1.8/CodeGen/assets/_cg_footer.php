</div>
<!-- .panelContainer -->
</div>
<!--ends #-->
</div>
<!--ends #-->

<h2 id="dump">Debug</h2>

<pre>
<?php
print_r ( CGManager::GET_CG_LOG () );
?>
</pre>

</div>
<!--ends #-->

<div id="footer">
<p>Created by <a href="http://jonniespratley.com">Jonnie Spratley</a> | V. <?php
echo CGManager::$CG_VERSION?></p>
</div>
<!--ends #-->
</div>
<!--ends #-->
</body>
</html>