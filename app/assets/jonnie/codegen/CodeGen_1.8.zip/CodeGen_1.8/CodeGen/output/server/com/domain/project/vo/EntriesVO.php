<?php/**                    My Test Application
                *//**  * I am a object representing the @TABLE table. *  * @version CodeGen - 1.8 * @author CodeGen - Jonnie Spratley (http://jonniespratley.com/code) * * @package com.domain.project.VO * @name EntriesVO.php */class EntriesVO{	/* Official boycott on amphp, because its trash */	//public $_explicitType = 'com.domain.project.vo.EntriesVO';		
			public $entry_body;
			public $entry_created;
			public $entry_title;
			public $id;
			public $location_id;
			public $upload_id;
			public $user_id;		public function __construct(){}		public function mapObject( $vo )	{		
			$this->entry_body = $vo["entry_body"];
			$this->entry_created = $vo["entry_created"];
			$this->entry_title = $vo["entry_title"];
			$this->id = $vo["id"];
			$this->location_id = $vo["location_id"];
			$this->upload_id = $vo["upload_id"];
			$this->user_id = $vo["user_id"];	}		public function setNamespace( $namespace )	{		$this->explicitType = $namespace;	}		public function __get( $name )	{		return $this->$name;	}		public function __set( $name, $value )	{		$this->$name = $value;	}	}?>                                          