<div id="jtwitter" class="jtwitter ui-widget ui-state-default ui-corner-all ui-helper-clearfix">		 
		<div class="jtwitter-logo">
			Twitter Pod
		</div>
		
		<div id="div_jtwitter_content" class="ui-widget-content">
		  <ul id="div_jtwitter_carousel">
			
<!-- *****************************1. Recent Updates *********************************** -->
				<li>
					<div class="jtwitter-carousel-item">
						<h3 class="ui-helper-clearfix">Recent</h3>
					  <ol id="ol_jtwitter_timeline_friends_list" class="jtwitter-tweets"></ol>
					</div>
				</li>
				
<!-- *****************************2. @ Replies *********************************** -->
				<li>
					<div class="jtwitter-carousel-item">
						<h3 class="ui-helper-clearfix">Replies</h3>
					  <ol id="ol_jtwitter_timeline_replies_list" class="jtwitter-tweets"></ol>
					</div>
				</li>
				
<!-- *****************************3. Favorites *********************************** -->
				<li>
					<div class="jtwitter-carousel-item">
						<h3 class="ui-helper-clearfix">Favorites</h3>
				    	<ol id="ol_jtwitter_favorites_list" class="jtwitter-tweets"></ol>
					</div>
				</li>
				
<!-- *****************************4. Messages *********************************** -->
			<li>
				<div class="jtwitter-carousel-item">
					<h3 class="ui-helper-clearfix">Messages</h3>
					  <ol id="ol_jtwitter_messages_get_list" class="jtwitter-tweets"></ol>				
				</div>
			</li>
				
<!-- *****************************5. Followers *********************************** -->
			<li>
				<div class="jtwitter-carousel-item">
					<h3 class="ui-helper-clearfix">Followers</h3>
				  <ol id="ol_jtwitter_followers_list" class="jtwitter-tweets"></ol>					
				</div>
			</li>

<!-- *****************************6. Settings *********************************** -->
			<li>
				<div class="jtwitter-carousel-item">
				<h3 class="ui-helper-clearfix">Settings</h3>
					  <p>Please take a minute and setup your preferences.</p>
						<form action="none.html" method="get" class="jtwitter-form">								
							<p>
								<label for="txt_jtwitter_stylesheet">Theme</label>
								<div id="txt_jtwitter_stylesheet"></div>
							<!--
									You can uncomment this if you want to set a specific set of themes.
								<select id="txt_jtwitter_stylesheet" class="text ui-state-default ui-corner-all"> 
									<option value="1">UI Lightness</option>
									<option value="2">UI Darkness</option>
									<option value="3">Sunny</option>
									<option value="4">Flick</option>
									<option value="5">Overcast</option>
									<option value="6">Cupertino</option>
								</select>
							-->
							</p>

<!-- ***************************** Login Form *********************************** -->		
							<p>
								<label for="txt_jtwitter_refresh">Auto Refresh</label>
								<select id="txt_jtwitter_refresh" class="text ui-state-default ui-corner-all"> 
									<option value="1">1 Minute</option>
									<option value="3">3 Minutes</option>
									<option value="5">5 Minutes</option>
									<option value="7">7 Minutes</option>
									<option value="10">10 Minutes</option>
								</select>
							</p>
							<p>
								<label for="txt_jtwitter_username">Username </label>
								<input id="txt_jtwitter_username" class="text ui-state-default ui-corner-all" type="text" value=""/>
							</p>
							<p>
								<label for="txt_jtwitter_username">Password </label>
								<input id="txt_jtwitter_password" class="text ui-state-default ui-corner-all" type="password" value=""/>
							</p>
							<p>
								<a id="btn_jtwitter_login" class="ui-button ui-state-default ui-corner-all" href="#">Save</a>
							</p>
						</form>
					</div>
				</li>	
			</ul>
		</div>


		<div class="jtwitter-bottom">		
		
<!-- ***************************** Update Form *********************************** -->
			<div id="div_jtwitter_status" class="ui-widget-content" style="display:none;">
				<form method="get" action="none.html" class="jtwitter-form">
					<p>
						<label for="txt_jtwitter_status_update">What are you doing?</label>
						<textarea id="txt_jtwitter_status_update" class="text ui-state-default ui-corner-all">@follow jonniespratley</textarea>							
					</p>
					<p>
						<a id="btn_jtwitter_status_update" class="ui-button ui-state-default ui-corner-all">Post</a>
					</p>
				</form>
			</div>
			
<!-- ***************************** Trim URL Form *********************************** -->
			<div id="div_jtwitter_trimurl" class="ui-widget-content" style="display:none;">
				<form method="get" action="none.html" class="jtwitter-form">
					<p>
						<label for="txt_jtwitter_trimurl">Paste your url</label>
						<input id="txt_jtwitter_trimurl" class="text ui-state-default ui-corner-all" type="text" value=""/>							
					</p>
					<p>
						<a id="btn_jtwitter_trimurl" class="ui-button ui-state-default ui-corner-all">Trim</a>
					</p>
				</form>
			</div>
					
<!-- ***************************** ToolBar *********************************** -->						
			<ul id="ul_jtwitter_toolbar" class="jtwitter-toolbar" style="display:none;">
				<li id="nav_jtwitter_1" class="ui-state-default ui-corner-all"><a id="btn_jtwitter_timeline" href="#" title="Recent Updates"><span class="ui-icon ui-icon-home">Home</span></a></li>
				<li id="nav_jtwitter_2" class="ui-state-default ui-corner-all"><a id="btn_jtwitter_replies" href="#" title="Replies"><span class="ui-icon ui-icon-comment">Replies</span></a></li>
				<li id="nav_jtwitter_3" class="ui-state-default ui-corner-all"><a id="btn_jtwitter_favorites" href="#" title="Favorites"><span class="ui-icon ui-icon-heart">Favorites</span></a></li>
				<li id="nav_jtwitter_4" class="ui-state-default ui-corner-all"><a id="btn_jtwitter_messages" href="#" title="Direct Messages"><span class="ui-icon ui-icon-mail-closed">Direct Messages</span></a></li>
				<li id="nav_jtwitter_5" class="ui-state-default ui-corner-all"><a id="btn_jtwitter_followers" href="#" title="Followers"><span class="ui-icon ui-icon-person">Followers</span></a></li>
				<li id="nav_jtwitter_7" class="ui-state-default ui-corner-all"><a id="btn_jtwitter_settings" href="#" title="Settings"><span class="ui-icon ui-icon-wrench">Settings</span></a></li>
				<li id="nav_jtwitter_8" class="ui-state-default ui-corner-all"><a id="btn_jtwitter_toggle_trimurl" href="#" title="Trim URL"><span class="ui-icon ui-icon-link">Trim Url</span></a></li>
				<li id="nav_jtwitter_9" class="ui-state-default ui-corner-all"><a id="btn_jtwitter_toggle_status" href="#" title="Toggle Status Update"><span class="ui-icon ui-icon-pencil">Toggle Status Update</span></a></li>
			</ul>
			
<!-- ***************************** API Toolbar *********************************** -->
			<ul id="ul_jtwitter_toolbar_api_1" class="jtwitter-toolbar-api ui-helper-clearfix"  style="display:none;">
				<li class="jtwitter-api-rate"><strong>Requests Per Hour:</strong> <span>150</span> / </li>
				<li class="jtwitter-api-calls"><strong>Requests Remaining:</strong> <span>200</span></li>
				<!-- <li class="jtwitter-api-reset">Reset Time: <span>49 seconds</span></li>-->
				<li class="jtwitter-loader"><img id="jtwitter_loader" src="images/twitter_pod_loading.gif" alt="loading..." width="16" height="16" style="display:none;"/></li>
			</ul>
<!-- ***************************** Latest Status *********************************** -->
			<p id="p_jtwitter_toolbar_api_2" class="jtwitter-toolbar-api" style="display:none;">
				<strong>Latest: </strong>
				<span id="span_jtwitter_status_latest"></span>
				<!--<span id="span_jtwitter_status_update" class="jtwitter-count">140</span>-->
			</p>
		</div>
</div>