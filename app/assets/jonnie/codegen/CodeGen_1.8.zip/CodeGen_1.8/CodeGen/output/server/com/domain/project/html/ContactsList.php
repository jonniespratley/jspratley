<?php 
require_once '../ContactsService.php';
require_once '../vo/ContactsVO.php';

$service = new ContactsService();
$result = '';
$recordList = '';

if ( isset($_POST['save']) )
{
	unset( $_POST['save'] );
	$recordValues = $_POST;
	$result = $service->saveContacts( $recordValues );	
}

$recordsArray = $service->getAllContacts();
$recordVO = new ContactsVO();

for ( $i = 0; $i < count( $recordsArray ); $i++ ) 
{
	$recordVO = $recordsArray[ $i ];
	
	$recordList .= '<tr id="'.$recordVO->id.'">';

	
			$recordList .= "<td>$recordVO->address</td>";
			$recordList .= "<td>$recordVO->city</td>";
			$recordList .= "<td>$recordVO->country</td>";
			$recordList .= "<td>$recordVO->date</td>";
			$recordList .= "<td>$recordVO->email</td>";
			$recordList .= "<td>$recordVO->id</td>";
			$recordList .= "<td>$recordVO->name</td>";
			$recordList .= "<td>$recordVO->phone</td>";
			$recordList .= "<td>$recordVO->state</td>";
			$recordList .= "<td>$recordVO->zip</td>";

	$recordList .= '<td class="actions">';
	$recordList .= '<button class="edit" onclick="window.location=\'ContactsForm.php?id='.$recordVO->id.'\'">Edit</button>';
	$recordList .= '<button class="delete" onclick=" remove('.$recordVO->id.')">Delete</button></td>';
	$recordList .= '</tr>';
}

?>
<?php include '_header.php'; ?> 

<script type="text/javascript">
var service = '../ContactsService.php';

function remove( id ){
	$.get( service, { m: 'remove', id: id }, function(data){
		if ( data ) {
			$('#'+id).fadeOut('slow');
		} else {
			alert( 'There was a problem!' );
		}
	});
}
</script>

<h3>Contacts</h3>

    <table width="100%" border="0">
	<tr>
		
			<th scope="col">address</th>
			<th scope="col">city</th>
			<th scope="col">country</th>
			<th scope="col">date</th>
			<th scope="col">email</th>
			<th scope="col">id</th>
			<th scope="col">name</th>
			<th scope="col">phone</th>
			<th scope="col">state</th>
			<th scope="col">zip</th><th scope="col">Actions</th>   
    </tr>
       <?php echo $recordList; ?>
    </table>
    
    <a href="ContactsForm.php">New Contacts</a>
  
 <?php include '_footer.php'; ?>