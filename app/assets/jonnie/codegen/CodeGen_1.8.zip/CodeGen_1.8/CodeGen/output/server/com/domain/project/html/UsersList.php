<?php 
require_once '../UsersService.php';
require_once '../vo/UsersVO.php';

$service = new UsersService();
$result = '';
$recordList = '';

if ( isset($_POST['save']) )
{
	unset( $_POST['save'] );
	$recordValues = $_POST;
	$result = $service->saveUsers( $recordValues );	
}

$recordsArray = $service->getAllUsers();
$recordVO = new UsersVO();

for ( $i = 0; $i < count( $recordsArray ); $i++ ) 
{
	$recordVO = $recordsArray[ $i ];
	
	$recordList .= '<tr id="'.$recordVO->user_id.'">';

	
			$recordList .= "<td>$recordVO->branch_id</td>";
			$recordList .= "<td>$recordVO->comp_id</td>";
			$recordList .= "<td>$recordVO->user_address</td>";
			$recordList .= "<td>$recordVO->user_cell</td>";
			$recordList .= "<td>$recordVO->user_dob</td>";
			$recordList .= "<td>$recordVO->user_docid</td>";
			$recordList .= "<td>$recordVO->user_email</td>";
			$recordList .= "<td>$recordVO->user_empid</td>";
			$recordList .= "<td>$recordVO->user_fname</td>";
			$recordList .= "<td>$recordVO->user_id</td>";
			$recordList .= "<td>$recordVO->user_idtype</td>";
			$recordList .= "<td>$recordVO->user_lname</td>";
			$recordList .= "<td>$recordVO->user_logindate</td>";
			$recordList .= "<td>$recordVO->user_password</td>";
			$recordList .= "<td>$recordVO->user_securityrole</td>";
			$recordList .= "<td>$recordVO->user_telh</td>";
			$recordList .= "<td>$recordVO->user_telw</td>";

	$recordList .= '<td class="actions">';
	$recordList .= '<button class="edit" onclick="window.location=\'UsersForm.php?id='.$recordVO->user_id.'\'">Edit</button>';
	$recordList .= '<button class="delete" onclick=" remove('.$recordVO->user_id.')">Delete</button></td>';
	$recordList .= '</tr>';
}

?>
<?php include '_header.php'; ?> 

<script type="text/javascript">
var service = '../UsersService.php';

function remove( id ){
	$.get( service, { m: 'remove', id: id }, function(data){
		if ( data ) {
			$('#'+id).fadeOut('slow');
		} else {
			alert( 'There was a problem!' );
		}
	});
}
</script>

<h3>Users</h3>

    <table width="100%" border="0">
	<tr>
		
			<th scope="col">branch_id</th>
			<th scope="col">comp_id</th>
			<th scope="col">user_address</th>
			<th scope="col">user_cell</th>
			<th scope="col">user_dob</th>
			<th scope="col">user_docid</th>
			<th scope="col">user_email</th>
			<th scope="col">user_empid</th>
			<th scope="col">user_fname</th>
			<th scope="col">user_id</th>
			<th scope="col">user_idtype</th>
			<th scope="col">user_lname</th>
			<th scope="col">user_logindate</th>
			<th scope="col">user_password</th>
			<th scope="col">user_securityrole</th>
			<th scope="col">user_telh</th>
			<th scope="col">user_telw</th><th scope="col">Actions</th>   
    </tr>
       <?php echo $recordList; ?>
    </table>
    
    <a href="UsersForm.php">New Users</a>
  
 <?php include '_footer.php'; ?>