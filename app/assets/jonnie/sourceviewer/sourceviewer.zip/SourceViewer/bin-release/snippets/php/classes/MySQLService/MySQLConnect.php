<?php

class MySQLConnect
{
	
	private $mysqli;

	public function __construct( $host, $username, $password )
	{
		
		$this->mysqli = new mysqli ( $host, $username, $password );
		
		/* check connection */
		if ( mysqli_connect_errno () )
		{
			trigger_error ( 'Database connection failure: Username/Password was incorrect.', E_USER_ERROR );
			exit ();
		} else
		{
			return $this->mysqli;
		}
	}

	public function execute( $sql )
	{
		if ( $result = $this->mysqli->query ( $sql ) )
		{
			/* fetch associative array */
			while ( $row = $result->fetch_assoc () )
			{
				$array[] = $row;
			}
			
			/* free result set */
			$result->close ();
		}
		
		/* close connection */
		$this->mysqli->close ();
		
		return $array;
	}

	public function realQuery( $query )
	{
		return $this->mysqli->query ( $query );
	}
	
	/**
	 * I execute a query and return the results as json.
	 *
	 * @param [string] $sql the query to be executed
	 * @return [json] the result in json
	 */
	public function queryToJSON( $sql )
	{
		$result = mysqli_query ( $this->mysqli, $sql );
		
		while ( $row = mysqli_fetch_assoc ( $result ) )
		{
			$array [] = $row;
		}
		return json_encode ( $array );
	}
	
	/**
	 * I execute a query and return the result as an array.
	 *
	 * @param [string] $sql the query to be executed
	 * @return [array] the result array
	 */
	public function queryToArray( $sql )
	{
		$query = mysqli_query ( $this->mysqli, $sql );
		$array = array ();
		
		while ( $row = mysqli_fetch_assoc ( $query ) )
		{
			$array [] = $row;
		}
		
		return $array;
	}
	
	/**
	 * I get the query status
	 *
	 * @param [string] $sql
	 * @return [array] mysql status with the ('_') striped out
	 */
	public function queryStatusToArray( $sql )
	{
		$result = mysqli_query ( $this->mysqli, $sql );
		
		while ( $row = mysqli_fetch_assoc ( $result ) )
		{
			//replace some of the names
			$row = str_replace ( 'Com_', '', $row );
			//take out the _ of the rows
			$row = str_replace ( '_', ' ', $row );
			
			$array [] = $row;
		}
		sort ( $array );
		
		return $array;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	public function dump( $var, $title )
	{
		print "<h4>$title</h4>";
		print "<pre>";
		print_r ( $var );
		print "</pre>";
	}

	/**
	 * @return unknown
	 */
	public function getMysqli()
	{
		return $this->mysqli;
	}
 
	/**
	 * @param unknown_type $mysqli
	 */
	public function setMysqli( $mysqli )
	{
		$this->mysqli = $mysqli;
	}

}
?>