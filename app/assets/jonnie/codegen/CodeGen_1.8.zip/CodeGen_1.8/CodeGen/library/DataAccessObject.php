<?php

require_once ( 'Connection.php' );
require_once ( 'ValueObject.php' );

/**
 * I am the Database Access Layer, I can manipulate the database.
 *
 */
class DataAccessObject
{
	private $conn;
	private $database;
	private $table;
 
	/**
	 * I am the instance of a Database Access Object
	 *
	 * @return [link]
	 */
	public function __construct()
	{
		$conn = new Connection ();
		
		$this->conn = $conn;
	}
	
	/**
	 * I get all records from the specified database and table
	 *
	 * @param [string] $database the database name
	 * @param [string] $table the table name
	 * @return [array]
	 */
	public function get( $database, $table )
	{
		$this->setDatabase ( $database );
		$this->setTable ( $table );
		
		$sql = "SELECT * FROM $database.$table";
		
		return $this->_execute ( $sql, 'get' );
	}
	
	/**
	 * I get one record from the specified database and table.
	 *
	 * @param [string] $database - the database
	 * @param [string] $table - the table
	 * @param [array] $vo - an array from the url query string
	 * @return [array] the matching record
	 */
	public function getOne( $database, $table, $vo )
	{
		
		$primarykey = $this->_getKey ( $database, $table );
		$primarykeyValue = $vo [ $primarykey ];
		
		$this->setDatabase ( $database );
		$this->setTable ( $table );
			
		$sql = "SELECT * FROM $database.$table WHERE $primarykey = $primarykeyValue";
		
		return $this->_execute ( $sql, 'getOne' );
	}
	
	/**
	 * I save a record to the specified database and table
	 *
	 * @param [string] $database - the database
	 * @param [string] $table - the table
	 * @param [array] $vo - the array from the url query
	 * @return [array] the inserted record
	 */
	public function save( $database, $table, $vo )
	{
		//Get the name of the primary key		
		$primarykey = $this->_getKey ( $database, $table );
		//Get the value of the primary key
		$primarykeyValue = $vo [ $primarykey ];
		
		$choice = '';
		if ( $primarykeyValue == 0 || $primarykeyValue == '' )
		{
			$choice = $this->create ( $database, $table, $vo );
		}
		else
		{
			$choice = $this->update ( $database, $table, $vo );
		}
		return $choice;
	}
	
	/**
	 * I update a record in the database/table
	 *
	 * @param [string] $database - the database
	 * @param [string] $table - the table
	 * @param [array] $vo - the array from the url query
	 * @return [array] the inserted object
	 */
	private function update( $database, $table, $vo )
	{
		//get the primary key
		$key = $this->_getKey ( $database, $table );
		
		$keyvalue = '';
		
		//check if the object has a key with the same value as the primary key
		if ( array_key_exists ( $key, $vo ) )
		{
			//set the keyvalue variable to the array key inside the object, the key should be the same name as the key in the table
			$keyvalue = $vo [ $key ];
		}
		
		$updateSet = '';
		
		//get the columns, the columns should be the name of the keys Get the name=values for the update set
		foreach ( $vo as $name => $value )
		{
			$updateSet .= $name . ' = ' . Connection::escape ( $value ) . ', ';
		}
		
		$updateSet = Connection::trimSQL ( $updateSet );
		
		//build the query
		$sql = "UPDATE $database.$table SET $updateSet WHERE $key = " . Connection::escape ( $keyvalue );
		
		//return sql for debugging
		return $this->_execute ( $sql, 'update' );
	}
	
	/**
	 * I create a new record in the database/table
	 *
	 * @param [string] $database - the database
	 * @param [string] $table - the table
	 * @param [array] $vo - the array from the url query
	 * @return [array] the inserted object
	 */
	private function create( $database, $table, $vo )
	{
		//get the columns, the columns should be the name of the keys
		$voColumns = '';
		$voValues = '';
		
		foreach ( $vo as $column => $value )
		{
			$voColumns .= $column . ', ';
			$voValues .= Connection::escape ( $value ) . ', ';
		}
		$voColumns = Connection::trimSQL ( $voColumns );
		$voValues = Connection::trimSQL ( $voValues );
		
		//build the query
		$sql = "INSERT $database.$table ( $voColumns ) VALUES ( $voValues )";
		
		return $this->_execute ( $sql, 'create' );
	}
	
	/**
	 * I remove a record from the specified database/table
	 *
	 * @param [string] $database - the database
	 * @param [string] $table - the table
	 * @param [array] $vo - the array from the url query
	 * @return [string] the id removed
	 */
	public function remove( $database, $table, $vo )
	{
		$primarykey = $this->_getKey ( $database, $table );
		$primarykeyValue = $vo [ $primarykey ];
		
		$sql = "DELETE FROM $database.$table WHERE $primarykey = $primarykeyValue";
		
		return $this->_execute ( $sql, 'remove' );
	}
	
	/**
	 * I get the tables key field
	 *
	 * @param [string] $database - the database
	 * @param [string] $table - the table
	 * @return [string] the name of the key
	 */
	private function _getKey( $database, $table )
	{
		$keys = $this->conn->executeAndReturn ( "SHOW INDEX FROM $database.$table" );
		$primaryKey = '';
		
		foreach ( $keys as $key )
		{
			if ( $key [ 'Key_name' ] == 'PRIMARY' )
			{
				$primaryKey = $key [ 'Column_name' ];
			}
		}
		$this->_returnSQL ( $primaryKey );
		
		return $primaryKey;
	}
	
	/**
	 * I take the mysqli connection object and return a value object of the data
	 *
	 * @param [array] $obj - The mysqli object 
	 * @return [array]
	 */
	private function _mapObject( $obj )
	{
		$array = array ();
		
		while ( $row = mysqli_fetch_assoc ( $obj ) )
		{
			$vo = new ValueObject ( );
			foreach ( $row as $key => $value )
			{
				$vo->__set ( $key, $value );
			}
			$array [] = $vo;
		}
		
		return $array;
	}
	
	/**
	 * I execute a method and return the results based on the mode
	 *
	 * @param [string] $sql - the sql to execute
	 * @return results
	 */
	private function _execute( $sql, $mode )
	{
		$query = $this->conn->execute ( $sql );
		$result = array ();
		if ( $mode == 'get' || $mode == 'getOne' )
		{
			$result = $this->_mapObject ( $query );
		
		} else if ( $mode == 'remove' || $mode == 'update' )
		{
			$result = mysqli_affected_rows ( $this->conn->getLink () );
		} else if ( $mode == 'create' )
		{
			$id = mysqli_insert_id ( $this->conn->getLink () );
			$result = $this->getOne ( $this->getDatabase (), $this->getTable (), $id );
		}
		
		return $result;
	}
	
	/**
	 * I dump out the SQL created from the functions.
	 *
	 * @param [string] - $sql
	 * @return string
	 */
	private function _returnSQL( $sql )
	{
		//Uncomment this to print out the sql from the function
	    //echo '<b>SQL:</b> '. $sql. '<br/>';
	}
	
   /**
	 * @return [string] - database name
	 */
	public function getDatabase()
	{
		return $this->database;
	}
 
	/**
	 * @return [string] - table name
	 */
	public function getTable()
	{
		return $this->table;
	}
	
	/**
	 * @param [string] $database - database name
	 */
	public function setDatabase( $database )
	{
		$this->database = $database;
	}
	
	/**
	 * @param [string] $table - table name
	 */
	public function setTable( $table )
	{
		$this->table = $table;
	}

}



/** ==============================================================================================
 * REST SERVICE FOR CLASS
 * ============================================================================================== */

if ( isset ( $_GET ) )
{

	//header ( 'Content-type: application/json' );
	
	//Set up the variables for the calls
	$mode = '';
	$table = '';
	$database = '';
	$object = '';
	$format = '';
	$query = $_GET;
	
	if ( isset ( $_GET [ 'm' ] ) )
	{
		$mode = $_GET [ 'm' ]; //Mode
		unset ( $query [ 'm' ] );
	}
	
	if ( isset ( $_GET [ 'd' ] ) )
	{
		$database = $_GET [ 'd' ]; //Database
		unset ( $query [ 'd' ] );
	}
	
	if ( isset ( $_GET [ 't' ] ) )
	{
		$table = $_GET [ 't' ]; //Table
		unset ( $query [ 't' ] );
	}

/* ********************************************
 * Call Error/Result Codes/Messages
 * ********************************************/
	$jsonFault [] = array ( 
		'status' => 401, 'message' => 'Unknown method or incorrect parameters' 
	);
	
	$jsonData = array ();

/* ********************************************
 * Switch based on the mode
 * ********************************************/
	
	$service = new DataAccessObject ( );
	switch ( $mode )
	{
		case 'get':
			
			$result = $service->get ( $database, $table );
			
			if ( $result )
			{
				echo json_encode ( array ( 
					'status' => 200, 'mode' => 'get', 'result' => $result 
				) );
			}
			else
			{
				echo json_encode ( $jsonFault );
			}
			
			break;
		
		case 'getOne':
			$result = $service->getOne ( $database, $table, $query );
			
			if ( $result )
			{
				echo json_encode ( array ( 
					'status' => 200, 'mode' => 'get', 'result' => $result 
				) );
			}
			else
			{
				echo json_encode ( $jsonFault );
			}
			break;
		
		case 'save':
			$result = $service->saveData ( $database, $table, $query );
			
			if ( $result )
			{
				echo json_encode ( array ( 
					'status' => 200, 'mode' => 'get', 'result' => $result 
				) );
			}
			else
			{
				echo json_encode ( $jsonFault );
			}
			break;
		
		case 'remove':
			$result = $service->remove ( $database, $table, $query );
			
			if ( $result )
			{
				echo json_encode ( array ( 
					'status' => 200, 'mode' => 'get', 'result' => $result 
				) );
			}
			else
			{
				echo json_encode ( $jsonFault );
			}
			break;
		
		default :
			echo json_encode ( $jsonFault );
			break;
	
	}

} //ends $_GET


/** ==============================================================================================
 * CLASS TESTING
 *

//To update a table record, simply just specify the the values for the fields in which you are wanting to update.
//Make sure it is an assoc array containing array keys ( which are table columns ) and values ( which are the //updated values )


$updateVO = array ( 
	'id' => 100, 'title' => 'This record just got updated', 'body' => 'Dont you just love PHP programming?' 
);

//To create a table record, do the same as above just make the id field for your table 0, this is because the //class does a check, to see
//if there is a key with the value of ( table primary key ), if there is a key, then it continues and checks the //value of that key, in the array
//if the value is set to 0 or '', then it creates a new record, otherwise it updates that record in which is //specified in the value of the key array.


$createVO = array ( 
	'id' => 0, 'title' => 'This is a new post', 'body' => 'I really dont know what to say here.' 
);

$database = 'codegen';
$table = 'posts';
$key = 'id';

echo '<pre>';

//=========================================================================================
echo '<h2>Universal Value Object</h2>';
$vo = new ValueObject ( );
$vo->__set ( 'id', 0 );
$vo->__set ( 'title', 'Flex Value Object' );
$vo->__set ( 'body', 'This is just a sample get and set value objerct' );

print_r ( $vo );


//=========================================================================================
echo '<h2>Universal DataAccess Object</h2>';
$service = new DataAccessObject ( );


//=========================================================================================
echo '<h2>get(database, table)</h2>';
print_r ( $service->get ( $database, $table ) );

//URL for REST usage:
echo 'http://localhost/DataAccessObject.php?m=get&d=codegen&t=posts';
//Example JSON output
echo '
[{
    id: "25"
    title: "this is rest"
    body: "this is sick, rest with any database or table"
    date: "2009-05-01 00:22:24"
    user_id: "0"
}]';

//=========================================================================================
echo '<h2>getOne(database, table, value)</h2>';
print_r ( $service->getOne ( $database, $table, 93 ) );
//URL for REST usage:
echo 'http://localhost/CodeGen/library/DataAccessObject.php?m=getOne&d=codegen&t=posts&id=5';

//=========================================================================================
echo '<h2>update(database, table, value)</h2>';
//print_r ( $service->update ( $database, $table, $updateVO ) );
//URL for REST usage:
echo '';

//=========================================================================================
echo '<h2>save(database, table, value)</h2>';
print_r ( $service->save ( $database, $table, $createVO ) );
//URL for REST usage:
echo 'http://localhost/CodeGen/library/DataAccessObject.php?m=save&d=codegen&t=posts&id=0&title=URLPost&body=I%20am%20goin%20to%20bed%20soon.';

//=========================================================================================
echo '<h2>remove(database, table, value)</h2>';
//print_r ( $service->remove ( $database, $table, 9 ) );
//URL for REST usage:
echo 'http://localhost/CodeGen/library/DataAccessObject.php?m=remove&d=codegen&t=posts&id=5';

//echo '<li>multiSelect(database, table, table, value)</li>';
//print_r ( $service->multiSelect( $database, 'posts', 'users', 'id' ) );


echo '</pre>';

/* ============================================================================================== */
?>