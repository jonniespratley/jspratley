<div title="Step 5" class="panel">
<div class="wrapper">
	<h2>5. HTML Preview</h2>
	<?php
	
	//echo ConfigManager::getHtmlDemoURL();
	
	?>
	
	
	<iframe id="iframe_preview" 
		width="100%" 
		height="450">
	</iframe><!--ends #iframe_preview-->    
	<div class="paging">
        <a class="cross-link" href="#4">Prev</a>
        <a class="cross-link" href="#1">Next</a>
    </div>
</div><!--ends .wrapper-->
</div><!--ends .panel-->