<?php

/**
 *
 */
interface IGenerate
{
	static public function generate( $namespace, $database, $table, $fields = null );
}

?>