<?php

include 'Required.php';

class FlexAmfphpServiceGen implements IGenerate
{
	
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		//upper case the table name
		$table = ucfirst ( $table );
		
		//Create the fileame
		$filename = $table . 'ServiceDelegate.as';
		
		//make the folder namespace
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		$namespace = Utilities::namespaceApplication ( $namespace );

		$tableService = FileSystemService::readFile ( TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'Delegate.txt' );
		
		//replace the table name inside of the template
		$template = preg_replace ( TemplateManager::$TABLE_PATTERN, $table, $tableService );
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $template );
		
		Utilities::checkOrMakeFolders ( TemplateManager::$CLIENT_OUTPUT, $folderNamespace, 'business' );
		FileSystemService::writeFile ( TemplateManager::$CLIENT_OUTPUT . $folderNamespace . '/business/' . $filename, $template );
		
		return 'Generated Amfphp Service for ' . $table;
	}
}

?>