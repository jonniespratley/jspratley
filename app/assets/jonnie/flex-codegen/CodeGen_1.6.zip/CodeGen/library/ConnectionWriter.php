<?php

include 'Required.php';

class ConnectionWriter
{
	
	public static function writeConnection( $database )
	{
		$config = new ConfigReader ( );
		$config->readConfig ( TemplateManager::$CONFIG_OUTPUT.'/'.ucfirst($database ).'Config.xml' );
	
		$folderNamespace = Utilities::namespaceFolders ( $config->getNamespace () );
		
		//read the template
		$conn = FileSystemService::readFile ( TemplateManager::$PHP_TEMPLATE_LOCATION.'conn.txt' );
		
		//replace the table name inside of the template
		$template = preg_replace ( TemplateManager::$HOST_PATTERN, $config->getHost (), $conn );
		$template = preg_replace ( TemplateManager::$USER_PATTERN, $config->getUser (), $template );
		$template = preg_replace ( TemplateManager::$PASS_PATTERN, $config->getPass (), $template );
		
		$template = preg_replace ( TemplateManager::$CG_VERSION_PATTERN, CGManager::$CG_VERSION, $template );
		$template = preg_replace ( TemplateManager::$CG_AUTHOR_PATTERN, CGManager::$CG_AUTHOR, $template );
		
		//write the file 
		FileSystemService::writeFile ( TemplateManager::$SERVER_OUTPUT . $folderNamespace . '/Connection.php', $template );
		
		return 'Connection File Written';
	}

}

?>