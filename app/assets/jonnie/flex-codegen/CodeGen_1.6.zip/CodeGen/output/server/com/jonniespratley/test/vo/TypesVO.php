<?php/**  * I am a object representing the Types table. *  * @version 1.6 * @author Jonnie Spratley (http://jonniespratley.com/code) * * @package com.jonniespratley.test.VO * @name TypesVO.php */class TypesVO{	var $_explicitType = 'com.jonniespratley.test.VO.TypesVO';		
			public $id;
			public $type_title;
			public $user_id;		public function __construct( $vo )	{		
			$this->id = $vo["id"];
			$this->type_title = $vo["type_title"];
			$this->user_id = $vo["user_id"];	}	}?>                                          