<?php
/**
 * @name  	PHPGen.php
 * @author  Jonnie Spratley
 * @version 1.7
 * @description 
 * 
 * This class holds all of the static methods 
 * for creating all the neccessary files for the PHP on the server side.
 * 
 * @method generateValueObject -
 * @method generateBaseService -
 * @method generateRESTService -
 * 
 */

class Utilities
{
	/**
	 * I camel case a string
	 *
	 * @param unknown_type $in
	 * @return unknown
	 */
	public static function toCamelCase( $in )
	{
		$ret = str_replace ( ' ', '_', ucwords ( preg_replace ( '/[^A-Z^a-z^0-9]+/', ' ', $in ) ) );
		if ( $ret == "Default" )
		{
			$ret = "DefaultOption";
		}
		return ( $ret );
		
	//return $in;
	}
	
	public static function toCamelCaseMember( $in )
	{
		$ret = ( strtolower ( substr ( $in, 0, 1 ) ) . substr ( $this->toCamelCase ( $in ), 1, strlen ( $in ) - 1 ) );
		if ( $ret == "default" )
		{
			$ret = "defaultOption";
		}
		return ( $ret );
		
	//return $in;
	}
	
	public static function printNestedArray( $array )
	{
		echo '<ul>';
		
		foreach ( $array as $key => $value )
		{
			echo '<li>' . htmlspecialchars ( "$key: " );
			
			if ( is_array ( $value ) )
			{
				$this->printNestedArray ( $value );
			}
			else
			{
				echo htmlspecialchars ( "$value " ) . '</li>';
			}
		}
		echo '</ul>';
	}
	
	public static function log( $var )
	{
		//write to log file
		$file = "log.txt";
		
		//$date = date('n/j/y  g:i a  ');
		$date = DATE_W3C;
		
		//append to end of content in log fil
		$fp = fopen ( $file, "a+" );
		
		//make sure file is writable
		chmod ( "log.txt", 0777 );
		
		$contents = $date . $var;
		
		fwrite ( $fp, $contents, 1024 );
		
		fclose ( $fp );
	}
	
	public static function readLog()
	{
		$file = "log.txt";
		
		$print = file_get_contents ( $file );
		echo '<pre>';
		print_r ( $print );
		echo '</pre>';
	}
	
	public static function dump( $title, $var )
	{
		echo "<h3>$title</h3>";
		echo '<pre>';
		print_r ( $var );
		echo '<pre>';
	}
	
	public static function trimSQL( $sql )
	{
		return substr ( $sql, 0, strlen ( $sql ) - 2 );
	}
	
	public static function trim( $str, $len )
	{
		return substr ( $str, 0, strlen ( $str ) - $len );
	}
	
	public static function namespaceFolders( $namespace )
	{
		$folderNamespace = str_replace ( '.', '/', $namespace );
		
		return $folderNamespace;
	}
	
	public static function namespaceApplication( $namespace )
	{
		$folderNamespace = str_replace ( '/', '.', $namespace );
		
		return $folderNamespace;
	}
	
	public static function makeServerNamespaceFolders( $namespace )
	{
		$newNamespace = str_replace ( '.', '/', $namespace );
		
		if ( ! is_dir ( 'output/' . $newNamespace ) )
		{
			mkdir ( $newNamespace, 0777, true );
		}
		chmod ( $newNamespace, 0777 );
		
		return $newNamespace;
	}
	
	public static function makeClientNamespaceFolders( $namespace )
	{
		$newNamespace = str_replace ( '.', '/', $namespace );
		if ( ! is_dir ( 'output/' . $newNamespace ) )
		{
			
			mkdir ( $newNamespace, 0777, true );
		}
		chmod ( $newNamespace, 0777 );
		
		return $newNamespace;
	}
	
	/**
	 * I replace the numbers from the table schema to nothing.
	 *
	 * @param [string] $search type you want replaced
	 * @return [string] the string with the (num) taken off
	 */
	public static function replaceNumbers( $search )
	{
		$replacement = '';
		$pattern = '/[(\d*)]/';
		$new = preg_replace ( $pattern, $replacement, $search );
		return $new;
	}
	
	public static function checkOrMakeFolders( $outputLocation, $folderNamespace, $folder )
	{
		$path = $outputLocation . $folderNamespace . $folder . '/';
		if ( ! is_dir ( $outputLocation . $folderNamespace . '/' . $folder ) )
		{
			mkdir ( $outputLocation . $folderNamespace . '/' . $folder, 0777, true );
		}
		//chmod ( $outputLocation . $folderNamespace . '/' . $folder, 0777 );
		

		return $path;
	}
}

?>