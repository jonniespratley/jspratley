<?php 

include 'assets/_cg_header.php';
include 'assets/_step_1.php';
include 'assets/_step_2.php';
include 'assets/_step_3.php';
include 'assets/_step_4.php';
include 'assets/_step_5.php';
include 'assets/_cg_footer.php';

?>		