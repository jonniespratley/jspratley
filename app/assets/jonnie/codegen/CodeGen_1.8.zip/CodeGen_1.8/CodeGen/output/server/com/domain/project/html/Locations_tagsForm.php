<?php 
require_once '../Locations_tagsService.php';
require_once '../vo/Locations_tagsVO.php';


			$id = "";
			$location_id = "";
			$tag_id = "";
$id = '';

if ( $_GET['id'] )
{
	$id = $_GET['id'];
	$service = new Locations_tagsService();
	$recordVO = new Locations_tagsVO();
	$record = $service->getOneLocations_tags( $id ); 
	$recordVO = $record[0];//First object in array
	
	
			$id = $recordVO->id;
			$location_id = $recordVO->location_id;
			$tag_id = $recordVO->tag_id;
	
	
}
?>
<?php include '_header.php'; ?>
<form id="formLocations_tags" name="formLocations_tags" method="post" action="Locations_tagsList.php">
	 
	
	
			<div>
		 		<label for="id">Id</label>
		 		<input type="text" name="id" value="<?php echo $id; ?>"/>
		 	</div>
			<div>
		 		<label for="location_id">Location_id</label>
		 		<input type="text" name="location_id" value="<?php echo $location_id; ?>"/>
		 	</div>
			<div>
		 		<label for="tag_id">Tag_id</label>
		 		<input type="text" name="tag_id" value="<?php echo $tag_id; ?>"/>
		 	</div>
    
    <div>
    	<input type="hidden" name="id" value="<?php echo $id; ?>"/>
	   <input name="save" type="submit" value="Save" />
		<button onclick="window.location='Locations_tagsList.php'">Back</button>
    </div>
</form>
 <?php include '_footer.php'; ?>