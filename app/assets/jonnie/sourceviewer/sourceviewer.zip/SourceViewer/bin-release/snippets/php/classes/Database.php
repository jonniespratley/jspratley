<?php

/** *******************************************************************
 * MySnippets
 * Free for use
 *
 * @author  Jonnie Spratley
 * @contact jonniespratley@gmail.com
 ******************************************************************* */
class Database
{
	//Enter your credentials
	public $db_host = "HOST";
	public $db_name = "DATABASE";
	public $db_user = "USER";
	public $db_pass = "PASSWORD";
	public $dbconn;

	/**
	 * Enter description here...
	 *
	 * @return Database
	 */
	public function Database()
	{
		$this->dbconn = mysql_connect( $this->db_host, $this->db_user, $this->db_pass );
		
		mysql_select_db( $this->db_name, $this->dbconn );
	}
}
?>