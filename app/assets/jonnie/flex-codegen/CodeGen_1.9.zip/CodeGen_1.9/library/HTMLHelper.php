<?php

class HTMLHelper
{
	
	public function __construct()
	{
	
	}
	
	public function doUL( $id, $class = null, $items = null )
	{
		$ul = '<ul id="' . $id . '" class="' . $class . '">';
		
		foreach ( $items as $item )
		{
			$ul .= '<li>' . $item . '</li>';
		}
		$ul .= '</ul>';
		
		echo $ul;
	}
	
	public function doOL( $id, $class = null, $items = null )
	{
		$ul = '<ol id="' . $id . '" class="' . $class . '">';
		
		foreach ( $items as $item )
		{
			$ul .= '<li>' . $item . '</li>';
		}
		$ul .= '</ol>';
		
		echo $ul;
	}
	
	public function doTabs( $id, $class = null, $items = null )
	{
		$links = array ();
		foreach ( $items as $title => $link )
		{
			$link = '<a href="' . $link . '">' . $title . '</a>';
			
			array_push ( $links, $link );
		}
		
		echo $this->doUL ( $id, $class, $links );
	}
	
	/**
	 * <input name="txt_application" type="text" id="txt_application" value="CodeGenTest" class="medium"/>
	 *	<label class="description" for="txt_namespace">
	 *		Application Namespace: 
	 *	</label>
	 */
	
	/**
	 * I create a options form
	 *
	 * @param array $options Array with key value pairs, keys should be ( name, type, value, class )
	 */
	public function doOptions( $options )
	{
		
		$item = '';
		
		foreach ( $options as $option )
		{
			$item .= $this->doLabel ( $option [ 'name' ], ucfirst ( $option [ 'label' ] ) );
			
			if ( $option [ 'type' ] == 'select' )
			{
				$item .= $this->doSelect ( $option [ 'name' ], $option [ 'options' ], $option [ 'class' ] );
			
			}
			
			else
			
			{
				
				$item .= $this->doInput ( $option [ 'type' ], $option [ 'name' ], $option [ 'value' ], $option [ 'class' ] );
			}
			if ( $option['other'] )
			{
				
			}
		}
		
		echo $item;
	}
	
	public function doInput( $type, $name, $value, $class, $other = null )
	{
		$input = '
		<input name="' . $name . '" type="' . $type . '" id="' . $name . '" value="' . $value . '" class="' . $class . '" ';
		
		if ( $other)
		{
			foreach( $other as $att => $value )
			{
				$input .= $att.'="'.$value.'" ';
			}
		}
			$input .= '/>';		
		
		
		
		return $input;
	}
	
	public function doLabel( $for, $name )
	{
		$label = '
		<label for="' . $for . '">' . ucfirst ( $name ) . '</label>';
		
		return $label;
	}
	
	public function doButton( $name, $value, $class )
	{
		$button = '
		<button name="' . $name . '" class="' . $class . '">' . $value . '</button>';
		
		return $button;
	}
	
	public function doSelect( $name, $options, $class )
	{
		$select = '
		<select name="' . $name . '" id="' . $name . '" class="' . $class . '">';
		$selectOptions = '';
		
		foreach ( $options as $value => $label )
		{
			$selectOptions .= '
			<option value="' . $value . '">' . $label . '</option>';
		}
		$select .= $selectOptions . '</select>';
		
		return $select;
	
	}
	
	/**
	 * I wrap something in a <div> tag
	 * 
	 * <code>
	 * 
	 * <div id="ID" class="CLASS">WRAP</div>
	 * 
	 * </code>
	 *
	 * @param [string] $id
	 * @param [string] $class
	 * @param [string] $wrap
	 */
	public function doDiv( $id, $class, $wrap )
	{
		$div = '<div id="'.$id.'" class="'.$class.'">'.$wrap.'</div>';
		
		return $div;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}

?>