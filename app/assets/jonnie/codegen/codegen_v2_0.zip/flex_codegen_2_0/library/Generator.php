<?php 
require_once "IGen.php";
require_once "FlexGen.php";
require_once "CairngormGen.php";
require_once "EclipseGen.php";
require_once "PHPGen.php";

class Generator implements IGen {

    private $flexGen;
    private $cairngormGen;
    private $eclipseGen;
    private $phpGen;
    private $options;
    
    public function __construct($options) {
        $this->options = $options;
        
        $this->flexGen = new FlexGen($options);
        $this->cairngormGen = new CairngormGen($options);
        $this->eclipseGen = new EclipseGen($options);
        $this->phpGen = new PHPGen($options);
    }
    
    public function generateServerSide() {
    
        for ($i = 0; $i < count($this->options['tables']); $i++) {
        	$daos[] = $this->phpGen->generateBaseService($this->options['tables'][$i]['name'], $this->options['tables'][$i]['fields']);
            $vos[] = $this->phpGen->generateValueObject($this->options['tables'][$i]['name'], $this->options['tables'][$i]['fields']);
            
            foreach ($vos as $vo) {
                //file_put_contents($outputPath.'/vo/'.$vo['filename'], $vo['contents']);
            }
        }
        $results = array('label' => 'services', 'children' => array_merge($daos, $vos));
		return $results;
    }
    
    public function generate() {
    	return $this->generateServerSide();
    }
    
}
?>
