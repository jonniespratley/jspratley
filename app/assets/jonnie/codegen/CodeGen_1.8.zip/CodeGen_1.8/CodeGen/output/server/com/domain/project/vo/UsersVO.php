<?php/**                    My Test Application
                *//**  * I am a object representing the @TABLE table. *  * @version CodeGen - 1.8 * @author CodeGen - Jonnie Spratley (http://jonniespratley.com/code) * * @package com.domain.project.VO * @name UsersVO.php */class UsersVO{	/* Official boycott on amphp, because its trash */	//public $_explicitType = 'com.domain.project.vo.UsersVO';		
			public $branch_id;
			public $comp_id;
			public $user_address;
			public $user_cell;
			public $user_dob;
			public $user_docid;
			public $user_email;
			public $user_empid;
			public $user_fname;
			public $user_id;
			public $user_idtype;
			public $user_lname;
			public $user_logindate;
			public $user_password;
			public $user_securityrole;
			public $user_telh;
			public $user_telw;		public function __construct(){}		public function mapObject( $vo )	{		
			$this->branch_id = $vo["branch_id"];
			$this->comp_id = $vo["comp_id"];
			$this->user_address = $vo["user_address"];
			$this->user_cell = $vo["user_cell"];
			$this->user_dob = $vo["user_dob"];
			$this->user_docid = $vo["user_docid"];
			$this->user_email = $vo["user_email"];
			$this->user_empid = $vo["user_empid"];
			$this->user_fname = $vo["user_fname"];
			$this->user_id = $vo["user_id"];
			$this->user_idtype = $vo["user_idtype"];
			$this->user_lname = $vo["user_lname"];
			$this->user_logindate = $vo["user_logindate"];
			$this->user_password = $vo["user_password"];
			$this->user_securityrole = $vo["user_securityrole"];
			$this->user_telh = $vo["user_telh"];
			$this->user_telw = $vo["user_telw"];	}		public function setNamespace( $namespace )	{		$this->explicitType = $namespace;	}		public function __get( $name )	{		return $this->$name;	}		public function __set( $name, $value )	{		$this->$name = $value;	}	}?>                                          