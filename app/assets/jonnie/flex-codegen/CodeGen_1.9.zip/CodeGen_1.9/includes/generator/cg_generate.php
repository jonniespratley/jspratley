<div class="title">
<h2>Generate</h2>
</div>
 
<?php include 'includes/generator/_step_1.php'; ?>
<?php include 'includes/generator/_step_2.php'; ?>
<?php include 'includes/generator/_step_3.php'; ?>
<?php include 'includes/generator/_step_4.php'; ?>