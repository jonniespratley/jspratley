<?php
/**
 * I am the connection to the database
 * @version 1.6
 * @author Jonnie Spratley (http://jonniespratley.com/code)
 *
 * @package @NAMESPACE
 * @name Connection.php
 */
class Connection
{
	private $link;
	
	/**
	 * I create a new connection to a database
	 *
	 * @return [link] a link to the connection
	 */
	public function __construct()
	{
		$host = 'localhost';
		$user = 'root';
		$pass = 'fred';
		
		$link = new mysqli ( $host, $user, $pass );
		
		return $this->setLink ( $link );
	}
	
	public static function get_handle()
	{
		static $db = null;
		if ( !isset( $db ) ) 
		{
			$db = new Connection();
		}
		return $db->link;
	}
	
	/**
	 * I execute a query on the database
	 *
	 * @param [string] $query
	 * @return [result] the result
	 */
	public function execute( $query )
	{
		return $this->link->query ( $query );
	}
	
	public function executeAndReturn( $sql )
	{
		$query = $this->link->query ( $sql );
		$array = array ();
		while ( $row = mysqli_fetch_assoc ( $query ) )
		{
			$array [] = $row;
		}
		return $array;
	}
	/**
	 * @return unknown
	 */
	public function getLink()
	{
		return $this->link;
	}
	
	/**
	 * @param unknown_type $link
	 */
	public function setLink( $link )
	{
		$this->link = $link;
	}

}
?>