<div title="Step 3" class="panel">
    <div class="wrapper">
        <h2>3. Application Review</h2>
        <form id="form_app" name="form_app" method="" action="" onsubmit="return;">
            <div>
                <label class="description" for="txt_configLocation">
                    Application Config Location: 
                </label>
                <input name="txt_configLocation" type="text" id="txt_configLocation" />
            </div>
            <div>
                <input type="button" name="btn_generateSchema" id="btn_generateSchema" value="Create Schema" />
            </div>
            <div>
                <label class="description" for="txt_schemaLocation">
                    Application Schema Location: 
                </label>
                <input name="txt_schemaLocation" type="text" id="txt_schemaLocation" value="" />
            </div>
            <div>
                <input type="button" name="btn_generateApp" id="btn_generateApp" value="Create Application" />
            </div>
        </form>
        <div class="paging">
            <a class="cross-link" href="#2">Prev</a>
            <a class="cross-link" href="#4">Next</a>
        </div>
    </div>
</div>
