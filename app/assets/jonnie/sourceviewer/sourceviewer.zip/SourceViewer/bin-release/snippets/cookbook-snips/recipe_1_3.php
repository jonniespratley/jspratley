<?php 

//A PHP class uses the following syntax:
class MyClass
{  
	var local1 = 1;     
	var local2 = 2; 
	
	public function MyClass()
	{
		//do something
	}    

	public function someMethod( $arg )  
	{ 
		//do something else
	} 
}

?>

//An ActionScript class uses this following syntax:
package
{   
	class MyClass
	{   
		public var someVariable:Number; 
		public var anotherVariable:Number; 
	
		public function MyClass()
		{
	  		//do something
		}
		
		public function someFunction( arg:Object ) 
		{
			//do something else 
		}  
	}	  
}