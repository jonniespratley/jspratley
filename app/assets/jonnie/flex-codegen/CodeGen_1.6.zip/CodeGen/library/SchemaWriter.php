<?php

include 'Required.php';

class SchemaWriter
{
	
	public static function writeSchema( $dblink, $database )
	{
		$dom = new DOMDocument ( '1.0' );
		
		/************************************
		 * Builds the root 
		 ************************************/
		//create a element
		$schema = $dom->createElement ( 'schema' );
		
		//set the element on itself
		$schema = $dom->appendChild ( $schema );
		
		//set a attribute for the schema node 
		$schema->setAttribute ( 'name', $database );
		
		/***********************************
		 * Builds the table inside the root
		 **********************************/
		$tableQuery = mysqli_query ( $dblink, "SHOW TABLES FROM $database" );
		
		while ( $tableRow = mysqli_fetch_row ( $tableQuery ) )
		{
			//create a table element
			$table = $dom->createElement ( 'table' );
			
			//set the table element on itself
			$table = $dom->appendChild ( $table );
			
			//set the name attribute on the table
			$table->setAttribute ( 'name', $tableRow [ 0 ] );
			
			$fieldQuery = mysqli_query ( $dblink, "DESCRIBE $database.$tableRow[0]" );
			
			while ( $fieldRow = mysqli_fetch_assoc ( $fieldQuery ) )
			{
				//create a element
				$field = $dom->createElement ( 'field' );
				
				//set the element on itself
				$field = $dom->appendChild ( $field );
				
				//set the name attribute
				$field->setAttribute ( 'name', $fieldRow [ 'Field' ] );
				
				//set the type attribute
				$field->setAttribute ( 'type', Utilities::replaceNumbers ( $fieldRow [ 'Type' ] ) );
				
				//set the null attribute
				$field->setAttribute ( 'required', $fieldRow [ 'Null' ] == 'NO' ? 'true' : 'false' );
				
				if ( $fieldRow [ 'Default' ] != '' )
				{
					//set the default
					$field->setAttribute ( 'default', strtolower ( $fieldRow [ 'Default' ] ) );
				}
				if ( $fieldRow [ 'Key' ] != '' )
				{
					//set the key
					$field->setAttribute ( 'key', strtolower ( $fieldRow [ 'Key' ] ) );
				}
				if ( $fieldRow [ 'Extra' ] != '' )
				{
					//set the value/length attribute
					$field->setAttribute ( 'extra', strtolower ( $fieldRow [ 'Extra' ] ) );
				}
				//put the field inside of the table
				$table->appendChild ( $field );
			}
			//put the table inside of the schema
			$schema->appendChild ( $table );
		}
		$dom->formatOutput = true;
		$filename = 'output/' . ucfirst ( $database ) . 'Schema.xml';
		$dom->save ( $filename );
		
		//change the permissions
		//chmod ( $filename, 0777 );
		$filepath = $filename; 
		
		return $filepath;	
	}

}

?>