<?php/**                    My Test Application
                *//**  * I am a object representing the @TABLE table. *  * @version CodeGen - 1.8 * @author CodeGen - Jonnie Spratley (http://jonniespratley.com/code) * * @package com.domain.project.VO * @name TagsVO.php */class TagsVO{	/* Official boycott on amphp, because its trash */	//public $_explicitType = 'com.domain.project.vo.TagsVO';		
			public $id;
			public $tag_title;
			public $user_id;		public function __construct(){}		public function mapObject( $vo )	{		
			$this->id = $vo["id"];
			$this->tag_title = $vo["tag_title"];
			$this->user_id = $vo["user_id"];	}		public function setNamespace( $namespace )	{		$this->explicitType = $namespace;	}		public function __get( $name )	{		return $this->$name;	}		public function __set( $name, $value )	{		$this->$name = $value;	}	}?>                                          