<?php 
require_once '../States_stateService.php';
require_once '../vo/States_stateVO.php';

$service = new States_stateService();
$result = '';
$recordList = '';

if ( isset($_POST['save']) )
{
	unset( $_POST['save'] );
	$recordValues = $_POST;
	$result = $service->saveStates_state( $recordValues );	
}

$recordsArray = $service->getAllStates_state();
$recordVO = new States_stateVO();

for ( $i = 0; $i < count( $recordsArray ); $i++ ) 
{
	$recordVO = $recordsArray[ $i ];
	
	$recordList .= '<tr id="'.$recordVO->id.'">';

	
			$recordList .= "<td>$recordVO->id_state</td>";
			$recordList .= "<td>$recordVO->name_state</td>";

	$recordList .= '<td class="actions">';
	$recordList .= '<button class="edit" onclick="window.location=\'States_stateForm.php?id='.$recordVO->id.'\'">Edit</button>';
	$recordList .= '<button class="delete" onclick=" remove('.$recordVO->id.')">Delete</button></td>';
	$recordList .= '</tr>';
}

?>
<?php include '_header.php'; ?> 

<script type="text/javascript">
var service = '../States_stateService.php';

function remove( id ){
	$.get( service, { m: 'remove', id: id }, function(data){
		if ( data ) {
			$('#'+id).fadeOut('slow');
		} else {
			alert( 'There was a problem!' );
		}
	});
}
</script>

<h3>States_state</h3>

    <table width="100%" border="0">
	<tr>
		
			<th scope="col">id_state</th>
			<th scope="col">name_state</th><th scope="col">Actions</th>   
    </tr>
       <?php echo $recordList; ?>
    </table>
    
    <a href="States_stateForm.php">New States_state</a>
  
 <?php include '_footer.php'; ?>