<?php 
require_once '../TypesService.php';
require_once '../vo/TypesVO.php';

$service = new TypesService();
$result = '';
$recordList = '';

if ( isset($_POST['save']) )
{
	unset( $_POST['save'] );
	$recordValues = $_POST;
	$result = $service->saveTypes( $recordValues );	
}

$recordsArray = $service->getAllTypes();
$recordVO = new TypesVO();

for ( $i = 0; $i < count( $recordsArray ); $i++ ) 
{
	$recordVO = $recordsArray[ $i ];
	
	$recordList .= '<tr id="'.$recordVO->id.'">';

	
			$recordList .= "<td>$recordVO->id</td>";
			$recordList .= "<td>$recordVO->type_title</td>";
			$recordList .= "<td>$recordVO->user_id</td>";

	$recordList .= '<td class="actions">';
	$recordList .= '<button class="edit" onclick="window.location=\'TypesForm.php?id='.$recordVO->id.'\'">Edit</button>';
	$recordList .= '<button class="delete" onclick=" remove('.$recordVO->id.')">Delete</button></td>';
	$recordList .= '</tr>';
}

?>
<?php include '_header.php'; ?> 

<script type="text/javascript">
var service = '../TypesService.php';

function remove( id ){
	$.get( service, { m: 'remove', id: id }, function(data){
		if ( data ) {
			$('#'+id).fadeOut('slow');
		} else {
			alert( 'There was a problem!' );
		}
	});
}
</script>

<h3>Types</h3>

    <table width="100%" border="0">
	<tr>
		
			<th scope="col">id</th>
			<th scope="col">type_title</th>
			<th scope="col">user_id</th><th scope="col">Actions</th>   
    </tr>
       <?php echo $recordList; ?>
    </table>
    
    <a href="TypesForm.php">New Types</a>
  
 <?php include '_footer.php'; ?>