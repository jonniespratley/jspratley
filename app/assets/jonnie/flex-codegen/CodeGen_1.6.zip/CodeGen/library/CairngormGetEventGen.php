<?php

include 'Required.php';

class CairngormGetEventGen implements IGenerate
{
	
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		$outputLocation = 
		
		//upper case the table name
		$table = ucfirst ( $table );
		
		//Create the fileame
		$filename = 'Get' . $table . 'Event.as';
		
		//make the folder namespace
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		$namespace = Utilities::namespaceApplication ( $namespace );

		$tableService = FileSystemService::readFile ( TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'GetEvent.txt' );
		
		//replace the table name inside of the template
		$template = preg_replace ( TemplateManager::$TABLE_PATTERN, $table, $tableService );
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $template );
		$template = preg_replace ( TemplateManager::$EVENT_CONST, strtoupper ( $table ), $template );
		
		Utilities::checkOrMakeFolders ( TemplateManager::$CLIENT_OUTPUT, $folderNamespace, 'events' );
		FileSystemService::writeFile ( TemplateManager::$CLIENT_OUTPUT. $folderNamespace . '/events/' . $filename, $template );
		
		return 'Generated Cairngorm Get Event for ' . $table;
	}
}

?>