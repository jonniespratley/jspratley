<?php

require_once 'MySQLService.php';

/* ********** Build from the URL ********** */
$host 			= $_REQUEST['h']; //Host
$user 			= $_REQUEST['u']; //Username
$pass	 		= $_REQUEST['p']; //Password
$database		= $_REQUEST['d']; //Database
$table 			= $_REQUEST['t']; //Table
$mode 			= $_REQUEST['m']; //Mode
$query 			= $_REQUEST['q']; //Query
$action = '';

//Create new db service
$service = new MySQLService($host, $user, $pass);

//Switch depending on mode
switch ( $_REQUEST['m'] )
{
	case 'getDatabasesAndTables':
		$action = 'getDatabasesAndTables';
		$db = $service->getDatabasesAndTables( $database );
		echo $db;
	break;
	
	case 'getDatabases':
		$action = 'getDatabases';
		$db = $service->getDatabases();
		echo $db;
	break;
	
	case 'showTableStatus':
		$action = 'showTableStatus';
		$db = $service->showTableStatus( $database );
		echo $db;
	break;
	
	case 'getTablesAndShowStatus':
		$action = 'getTablesAndShowStatus';
		$db = $service->getTablesAndShowStatus( $database );
		echo $db;
	break;
	
	case 'getTables':
		$action = 'getTables';
		$db = $service->getTables( $database );
		echo $db;
	break;
		
	case 'getTableData':
		$action = 'getTableData';
		$db = $service->getTableData( $database, $table );
		echo $db;
	break;
		
	case 'describeTable':
		$action = 'describeTable';
		$db = $service->describeTable( $database, $table );
		echo $db;
	break;
		
	case 'executeQuery':
		$action = 'executeQuery';
		$db = $service->executeQuery( $query );
		echo $db;
	break;
		
	case 'showSystemVariables':
		$action = 'showSystemVariables';
		$db = $service->showSystemVariables();
		echo $db;
	break;
		
	case 'showSystemPrivileges':
		$action = 'showSystemPrivileges';
		$db = $service->showPrivileges();
		echo $db;
	break;
		
	case 'showSystemStatus':
		$action = 'showSystemStatus';
		$db = $service->showSystemStatus();
		echo $db;
	break;
		
	case 'showSystemProcess':
		$action = 'showSystemProcess';
		$db = $service->showSystemProcess();
		echo $db;
	break;
		
	case 'analyzeTable':
		$action = 'analyzeTable';
		$db = $service->analyzeTable( $database, $table );
		echo $db;
	break;
		
	case 'checkTable':
		$action = 'checkTable';
		$db = $service->checkTable( $database, $table );
		echo $db;
	break;
		
	case 'optimizeTable':
		$action = 'optimizeTable';
		$db = $service->optimizeTable( $database, $table );
		echo $db;
	break;
		
	case 'repairTable':
		$action = 'repairTable';
		$db = $service->repairTable( $database, $table );
		echo $db;
	break;
		
	case 'createDatabase':
		$action = 'createDatabase';
		$db = $service->createDatabase( $database );
		echo $db;
	break;
		
	case 'createTable':
		$action = 'createTable';
		$db = $service->createTable( $database, $table, null );
		echo $db;
	break;
	
	case 'getServerInfo':
		$ACTION = 'getServerInfo';
		$db = $service->getServerInfo();
		echo $db;
	break;
	
	case 'getMySQLInfo':
		$action = 'getMySQLInfo';
		$db = $service->getMySQLInfo();
		echo $db;
	break;
	
	case 'getPHPInfo':
		$action = 'getPHPInfo';
		$db = $service->getPHPInfo();
		echo $db;
	break;
		
	default:
		//Error
		exit();	
}

?>