<div class="AccordionPanel">
<div class="AccordionPanelTab">Formatter</div>
<div class="AccordionPanelContent">
<form class="appnitro">
<div class="form_description">
<h2>JSON Formatter</h2>
<p>This is a JSON formatter created for the CodeGen.</p>
</div>
<ul>

	<li id="li_1"><label for="element_1" class="description">Ugly JSON: </label>
	<div><textarea id="RawJson" class="element textarea large"></textarea>
	</div>
	<p id="guide_1" class="guidelines"><small>Enter your ugly JSON here.</small></p>
	</li>

	<li class="section_break">
	<h3>Clean JSON</h3>
	<p>This is your clean JSON.</p>
	<div id="Canvas" class="Canvas"></div>
	</li>

	<li class="buttons"><input value="Format" onclick="Process()"
		type="button" class="button_text" /></li>
</ul>
</form>
</div>
</div>