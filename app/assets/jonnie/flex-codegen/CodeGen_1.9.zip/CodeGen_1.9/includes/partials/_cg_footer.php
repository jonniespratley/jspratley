	<div id="footer">
		<p>Copywrite 2009</p>
	</div><!--/footer-->
</div><!--/wrapper-->
<div id="dump"></div>
</body>
</html>