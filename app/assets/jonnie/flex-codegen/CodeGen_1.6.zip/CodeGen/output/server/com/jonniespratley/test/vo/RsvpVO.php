<?php/**  * I am a object representing the Rsvp table. *  * @version 1.6 * @author Jonnie Spratley (http://jonniespratley.com/code) * * @package com.jonniespratley.test.VO * @name RsvpVO.php */class RsvpVO{	var $_explicitType = 'com.jonniespratley.test.VO.RsvpVO';		
			public $id;
			public $first;
			public $last;
			public $phone;
			public $email;
			public $state;		public function __construct( $vo )	{		
			$this->id = $vo["id"];
			$this->first = $vo["first"];
			$this->last = $vo["last"];
			$this->phone = $vo["phone"];
			$this->email = $vo["email"];
			$this->state = $vo["state"];	}	}?>                                          