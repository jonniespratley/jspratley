<div class="box round">
	<h3>JSON Formatter</h3>
	<textarea id="rawJson" class="medium"></textarea>
	<input value="Format" onclick="Process()" type="button" class="submit" />
</div>
	<div id="canvas" class="box round"></div>