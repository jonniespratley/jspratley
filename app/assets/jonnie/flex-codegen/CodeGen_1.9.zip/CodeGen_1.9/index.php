<?php 
include 'includes/partials/_cg_header.php';
include 'includes/partials/_cg_sidebar.php';
include 'includes/partials/_cg_content.php';
include 'includes/partials/_cg_footer.php';
?>