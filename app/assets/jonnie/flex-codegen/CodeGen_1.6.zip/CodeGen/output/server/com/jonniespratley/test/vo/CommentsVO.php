<?php/**  * I am a object representing the Comments table. *  * @version 1.6 * @author Jonnie Spratley (http://jonniespratley.com/code) * * @package com.jonniespratley.test.VO * @name CommentsVO.php */class CommentsVO{	var $_explicitType = 'com.jonniespratley.test.VO.CommentsVO';		
			public $id;
			public $comment_name;
			public $comment_body;
			public $comment_created;		public function __construct( $vo )	{		
			$this->id = $vo["id"];
			$this->comment_name = $vo["comment_name"];
			$this->comment_body = $vo["comment_body"];
			$this->comment_created = $vo["comment_created"];	}	}?>                                          