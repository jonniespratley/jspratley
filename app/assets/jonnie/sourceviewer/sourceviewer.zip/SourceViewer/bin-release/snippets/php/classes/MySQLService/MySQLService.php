<?php
require_once 'FileSystemService.php';
require_once 'arrayQuery.php';
/**
 * I am a MySQL Database Manager Service the structure for the url is as follows. 
 *
 * @name MySQLService
 * @author  Jonnie Spratley
 * @version 1.1
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 */
class MySQLService
{
	/**
	 * I am the database link
	 *
	 * @var public
	 */
	public $mysqli;
	public $fileSvc;
	public $jquery;
	
	/**
	 * I hold alot of access to monitor and manager mysql tables
	 *
	 * @param [string] $host Host name
	 * @param [string] $username User name
	 * @param [string] $password User password
	 * 
	 * @return MySQLService
	 */
	public function MySQLService( $host, $username, $password )
	{
		//temporary for the bs warning signs on live
		// Report simple running errors
		error_reporting ( E_ERROR | E_USER_ERROR | E_PARSE );
		
		//Using init() to connect
		//$this->mysqli = new mysqli ( $host, $username, $password );
		

		/* create a connection object which is not connected */
		$this->mysqli = mysqli_init ();
		
		/* set connection options */
		//$this->mysqli->options ( MYSQLI_CLIENT_COMPRESS );
		

		$this->mysqli->options ( MYSQLI_OPT_CONNECT_TIMEOUT, 5 );
		
		/* connect to server */
		$this->mysqli->real_connect ( $host, $username, $password );
		
		/* check connection */
		if ( mysqli_connect_errno () )
		{
			trigger_error ( 'Database connection failure: Username/Password was incorrect.', E_USER_ERROR );
			exit ();
		}
		
		$this->fileSvc = new FileSystemService ( );
		$this->jquery = new arrayQuery ( $this->mysqli );
	}
	
	/* ********************************************************************
 * ********************************************************************
 *  
 * 			 				1. MYSQL SHOW METHODS
 *
 * Below is all the methods for getting tables, columns, databases,
 * indexs, statusus from the database.
 * 
 * SHOW DATABASES;
 * SHOW TABLES FROM test;
 * SHOW TABLE STATUS LIKE 'users';
 * SHOW INDEX FROM 'contacts';
 * SHOW INDEX FROM contacts;
 * SHOW COLUMNS FROM contacts;
 * SHOW STATUS FROM test;
 * SHOW TABLE STATUS FROM test;
 * 
 * ********************************************************************
 * *********************************************************************/
	
	/**
	 * I get all databases, tables, columns, and fields in the database.
	 * Formatted specially for Flex's Tree control.
	 *
	 * @return [array]
	 */
	public function getDatabasesAndTableTree()
	{
		//Database query     
		$databaseSQL = mysqli_query ( $this->mysqli, "SHOW DATABASES" );
		
		//New database array
		$databases = array ();
		
		//Loop the query
		while ( $database = mysqli_fetch_assoc ( $databaseSQL ) )
		{
			//Create a new array of tables for each database
			$tables = array ();
			
			foreach ( $database as $key => $value )
			{
				//Set the table array to get the tbles from the database 
				$tables = $this->_getTables ( $value );
			}
			
			//Add the tables to the database array
			$databases [] = array ( "aDatabase" => $value, "aType" => "database", "aData" => $key, "aIcon" => "databaseIcon", "aTables" => $tables );
		}
		sort ( $databases );
		
		//Encode in array
		return ( $databases );
	}
	
	/**
	 * I get all the databases
	 *
	 * @return [array]
	 */
	public function getDatabaseTree()
	{
		//Database query     
		$databaseSQL = mysqli_query ( $this->mysqli, "SHOW DATABASES" );
		
		//New database array
		$databases = array ();
		
		//Loop the query
		while ( $database = mysqli_fetch_assoc ( $databaseSQL ) )
		{
			//Create a new array of tables for each database
			$tables = array ();
			$status = array ();
			$size = array ();
			foreach ( $database as $key => $value )
			{
				//Set the table array to get the tbles from the database 
				$tables = $this->_getTables ( $value );
				$status = $this->_getTableStatus ( $value );
				$size = $this->_getDatabaseSize ( $value );
			}
			
			//Add the tables to the database array
			$databases [] = array ( "aDatabase" => $value, "aType" => "database", "aData" => $key, "aIcon" => "databaseIcon", "aTables" => $tables, "aStatus" => $status, "aSize" => $size );
		}
		sort ( $databases );
		
		//Encode in array
		return ( $databases );
		//return $databases;
	}
	
	/**
	 * I get all tables in the database
	 *
	 * @param [string] $whatDatabase the name of the database
	 * @return [array]
	 */
	public function getTablesTree( $whatDatabase )
	{
		//table query
		$tableSQL = mysqli_query ( $this->mysqli, "SHOW TABLES FROM $whatDatabase" );
		
		//create a new array of tables
		$tables = array ();
		
		//loop all the results
		while ( $table = mysqli_fetch_assoc ( $tableSQL ) )
		{
			$fields = array ();
			$indexes = array ();
			$statuss = array ();
			//for each table in the result make an array
			foreach ( $table as $key => $value )
			{
				//now descibe each table
				$fields = $this->_describeTable ( $whatDatabase, $value );
				//now get the indexes
				$indexes = $this->_getTableIndexes ( $whatDatabase, $value );
				//now get the status for that table
				$statuss = $this->_getSingleTableStatus ( $whatDatabase, $value );
			}
			//build a tree
			$tables [] = array ( "tableName" => $value, "aFields" => $fields, "aIndexes" => $indexes, 'aStatus' => $statuss );
		}
		
		return ( $tables );
	}
	
	/**
	 * I describe a table
	 *
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the table
	 * @return [array]
	 */
	public function describeTable( $whatDatabase, $whatTable )
	{
		$sql = mysqli_query ( $this->mysqli, "DESCRIBE $whatDatabase.$whatTable" );
		$tables = array ();
		
		while ( $row = mysqli_fetch_assoc ( $sql ) )
		{
			$tables = array ( $row );
		}
		sort ( $tables );
		
		return ( $tables );
	}
	
	public function getDatabases()
	{
		return $this->_queryToArray ( "SHOW DATABASES" );
	}
	
	public function getTables( $database )
	{
		return $this->_queryToArray ( "SHOW TABLES FROM $database" );
	}
	
	/**
	 * I show all of the columns for a specified table.
	 *
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the table
	 * @return [array] array of all the columns
	 */
	public function getTableColumns( $whatDatabase, $whatTable )
	{
		$sql = "SHOW COLUMNS FROM $whatDatabase.$whatTable";
		
		return $this->_queryToArray ( $sql );
	}
	
	/**
	 * I get all tables in database
	 *
	 * @param [string] $database the database
	 * @return [array]
	 */
	public function showTableStatus( $whatDatabase )
	{
		return $this->_queryToArray ( "SHOW TABLE STATUS FROM $whatDatabase" );
	}
	
	/**
	 * I get the primary key for the table.
	 *
	 * @param [string] $database the database
	 * @param [string] $table the table
	 * @return [array]
	 */
	public function getTableIndex( $whatDatabase, $whatTable )
	{
		return $this->_queryToArray ( "SHOW INDEX FROM $whatDatabase.$whatTable" );
	}
	
	/**
	 * I get user information
	 *
	 * @param [string] $username the users name
	 * @return [array]
	 */
	public function getUserInfo( $username )
	{
		$sql = "SELECT * FROM mysql.user_info WHERE User = '$username'";
		$result = mysqli_query ( $this->mysqli, $sql );
		//return $this->_queryToArray($sql);
		$array = array ();
		
		while ( $row = mysqli_fetch_assoc ( $result ) )
		{
			$array [] = array ( "User" => $row [ 'User' ], 
					/*"Fullname" => $row[ 'Fullname' ],*/ 
					"Description" => $row [ 'Description' ], "Icon" => base64_encode ( $row [ 'Icon' ] ), "Email" => $row [ 'Email' ], "Info" => $row [ 'Contact_information' ] );
		}
		return ( $array );
	}
	
	/**
	 * I get all open tables for a database
	 *
	 * @param [string] $whatDatabase the database name
	 * @return [array]
	 */
	public function getOpenTables( $whatDatabase )
	{
		$sql = "SHOW OPEN TABLES FROM $whatDatabase";
		return $this->_queryToArray ( $sql );
	
	}
	
	/**
	 * I get a count of rows from the table
	 *
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the table
	 * @return [array]
	 */
	public function getTableRows( $whatDatabase, $whatTable )
	{
		return $this->_queryToArray ( "SELECT COUNT(*) FROM $whatDatabase.$whatTable" );
	}
	
	/* ********************************************************************
 * ********************************************************************
 * 
 * 						2. public DATABASE/TABLE METHODS
 * 
 * Below is all the public methods that build up the database 
 * and table tree with information about each item. 
 * 
 * Example:
 * 
 * DatabaseName/
 * 		TableName/
 * 			FieldName/
 * 
 * ********************************************************************
 * ********************************************************************
	
	/**
	 * I get all tables for a database
	 *
	 * @param [string] $whatDatabase the database
	 * @return [array]
	 */
	public function _getTables( $whatDatabase )
	{
		//table query
		$tableSQL = mysqli_query ( $this->mysqli, "SHOW TABLES FROM $whatDatabase" );
		
		//create a new array of tables
		$tables = array ();
		
		//loop all the results
		while ( $table = mysqli_fetch_assoc ( $tableSQL ) )
		{
			$fields = array ();
			$statuss = array ();
			$indexes = array ();
			
			//for each table in the result make an array
			foreach ( $table as $t_key => $t_value )
			{
				//get the tables fields for each table
				$fields = $this->_describeTable ( $whatDatabase, $t_value );
				
				//now get the primary key for each table
				$primaryKey = $this->_getTableKey ( $whatDatabase, $t_value );
				
				//now get the status for that table
				$statuss = $this->_getSingleTableStatus ( $whatDatabase, $t_value );
				
				//now get the indexes for each table
				$indexes = $this->_getTableIndexes ( $whatDatabase, $t_value );
			
			}
			
			$tables [] = array ( "aTable" => $t_value, "aKey" => $primaryKey, "aType" => "table", "aIcon" => "tableIcon", "aData" => $t_key, "aFields" => $fields, "aStatus" => $statuss, "aIndexes" => $indexes );
		}
		//sort ( $tables );
		

		return $tables;
	}
	
	/**
	 * I describe a table for the getDatabasesAndTables() method
	 *
	 * @param [string]  $database the database
	 * @param [string]  $table the table
	 * @return [array]
	 */
	public function _describeTable( $whatDatabase, $whatTable )
	{
		return $this->_queryToArray ( "SHOW FIELDS FROM $whatDatabase.$whatTable" );
	}
	
	public function _getTableIndexes( $whatDatabase, $whatTable )
	{
		return $this->_queryToArray ( "SHOW INDEX FROM $whatDatabase.$whatTable" );
	}
	
	/**
	 * I get the table status for a table only when called from getDatabases()
	 *
	 * @param [string] $whatDatabase
	 * @return [array]
	 */
	public function _getTableStatus( $whatDatabase )
	{
		return $this->_queryToArray ( "SHOW TABLE STATUS FROM $whatDatabase" );
	}
	
	public function _getSingleTableStatus( $whatDatabase, $whatTable )
	{
		return $this->_queryToArray ( "SHOW TABLE STATUS FROM $whatDatabase LIKE '$whatTable'" );
	}
	
	/**
	 * I get tables and fields 
	 *
	 * @param [string] $whatDatabase the database
	 * @return [array]
	 */
	public function _getTableAndFields( $whatDatabase )
	{
		$tableInfoSql = mysqli_query ( $this->mysqli, "SHOW TABLE STATUS FROM $whatDatabase" );
		
		$tables = array (); //array of all table info
		$fields = array (); //array of all field info
		

		//get the table name from the result
		while ( $tableInfo = mysqli_fetch_row ( $tableInfoSql ) )
		{
			$tables [] = $tableInfo [ 0 ];
			
			//loop threw every table inside of the tables array
			foreach ( $tables as $table )
			{
				//for each table, get the fields info for that table
				$fields = $this->_showFieldInfo ( $whatDatabase, $table );
			}
			$tableInfoAndFields [] = array ( 'aTable' => $table, 'aType' => 'table', 'aFields' => $fields );
		}
		$databaseInfoAndTables [] = array ( 'aDatabase' => $whatDatabase, 'aType' => 'database', 'aTables' => $tableInfoAndFields );
		
		//return $fields;
		//return $databaseInfoAndTables;
		return ( $databaseInfoAndTables );
	}
	
	public function _getDatabasesTablesAndFields()
	{
		$databaseInfoSql = mysqli_query ( $this->mysqli, "SHOW DATABASES" );
		
		$databases = array (); //array of all databases info
		$tables = array (); //array of all table info
		$fields = array (); //array of all field info
		

		//get the table name from the result
		while ( $databaseInfo = mysqli_fetch_row ( $databaseInfoSql ) )
		{
			
			$databases [] = $databaseInfo [ 0 ];
			//loop threw every table inside of the tables array
			foreach ( $databases as $database )
			{
				$tables = $this->_showTableInfo ( $database );
				//for each table, get the fields info for that table
				foreach ( $tables as $table )
				{
					$fields = $this->_showFieldInfo ( $database, $table );
				}
			}
			
			$tableInfoAndFields [] = array ( 'aTable' => $table, 'aFields' => $fields );
		}
		
		//return $fields;
		//return $tables;
		return ( $tableInfoAndFields );
	}
	
	/**
	 * I get information about the table.
	 *
	 * @param [string] $whatDatabase the database
	 * @return [array]
	 */
	public function _showTableInfo( $whatDatabase )
	{
		$tableInfoSql = "SHOW TABLE STATUS FROM $whatDatabase";
		$result = mysqli_query ( $this->mysqli, $tableInfoSql );
		$tableInfo = array ();
		
		while ( $tables = mysqli_fetch_assoc ( $result ) )
		{
			$tableInfo [] = $tables;
		}
		return $tableInfo;
	}
	
	/**
	 * I get the fields for a table
	 *
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the table
	 * @return [array]
	 */
	public function _showFieldInfo( $whatDatabase, $whatTable )
	{
		$fieldInfoSql = "SHOW FIELDS FROM $whatDatabase.$whatTable";
		$fieldInfo = array ();
		
		$result = $this->mysqli->query ( $fieldInfoSql );
		
		while ( $fields = mysqli_fetch_assoc ( $result ) )
		{
			$fieldInfo [] = $fields;
		}
		return $fieldInfo;
	}
	
	/**
	 * I get the key for the table.
	 *
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the table
	 * @return [string]
	 */
	public function _getTableKey( $whatDatabase, $whatTable )
	{
		$indexInfoSql = "SHOW INDEX FROM $whatDatabase.$whatTable";
		$index = array ();
		
		$result = $this->mysqli->query ( $indexInfoSql );
		
		while ( $indexes = mysqli_fetch_assoc ( $result ) )
		{
			if ( $indexes [ 'Key_name' ] == 'PRIMARY' )
			{
				$index = $indexes [ 'Column_name' ];
			}
		}
		return $index;
	}
	
	/**
	 * I get the size of all databases in the database
	 *
	 * @return [array]
	 */
	public function getDatabaseSpace()
	{
		$sql = 'SELECT table_schema "Database",
				sum( data_length + index_length ) / 1024 / 1024  "TotalSize",
				sum( data_length ) / 1024 / 1024  "DataSize",
				sum( index_length ) / 1024 / 1024 "IndexSize",
				sum( data_free ) / 1024 / 1024  "FreeSize"
				FROM information_schema.TABLES
				GROUP BY table_schema';
		
		return $this->_queryToArray ( $sql );
	}
	
	/**
	 * I get the database size for all tables
	 *
	 * @param [string] $whatDatabase the database name
	 */
	public function _getDatabaseSize( $whatDatabase )
	{
		$statusSQL = mysqli_query ( $this->mysqli, "SHOW TABLE STATUS FROM $whatDatabase" );
		$sizeArray = array ();
		
		$totalSize = 0;
		$dataSize = 0;
		$indexSize = 0;
		
		//loop all the results
		while ( $size = mysqli_fetch_assoc ( $statusSQL ) )
		{
			$dataSize += $size [ 'Data_length' ];
			$indexSize += $size [ 'Index_length' ];
		}
		$totalSize = $dataSize + $indexSize;
		$sizeArray [] = array ( 'totalSize' => $totalSize, 'dataSize' => $dataSize, 'indexSize' => $indexSize );
		
		return $sizeArray;
	}
	
	/* ********************************************************************
 * ********************************************************************
 *  
 *  			3. QUERY BUILDER/CREATE/UPDATE/DELETE METHODS
 * 
 * Below is all the methods for building insert queries, creating
 * databases, creating tables, creating users, removing data,
 * inserting data, and updating data.
 * Also there is methods for altering databases, and tables.
 * 
 * ********************************************************************
 * *********************************************************************/
	
	/**
	 * I create a database
	 *
	 * @param [string] $whatDatabase the name of the database
	 * @return [string] the result outcome
	 */
	public function createDatabase( $whatDatabase )
	{
		//CREATE DATABASE `tutorial_library` 
		//DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
		$sql = "CREATE SCHEMA IF NOT EXISTS $whatDatabase
				CHARACTER SET utf8";
		$result = mysqli_query ( $this->mysqli, $sql );
		
		if ( ! $result )
		{
			return 'There was an error creating the database.';
		}
		return 'Database created!';
	}
	
	/**
	 * I create a table
	 *
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the name of the new table
	 * @return [string] the result
	 */
	public function createTable( $whatDatabase, $whatTable )
	{
		/**
		 * CREATE TABLE `books` ( id int ) DEFAULT CHARACTER SET latin1;
		 * 
		 */
		$sql = "CREATE TABLE $whatDatabase.$whatTable ( id int ) DEFAULT CHARACTER SET latin1";
		
		$result = mysqli_query ( $this->mysqli, $sql );
		
		if ( ! $result )
		{
			return false;
		}
		return true;
	}
	
	/**
	 * I alter a database table
	 *
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the name of the new table
	 * @param [string] $whatQuery a query array of what to change
	 * @return [string] the result
	 */
	public function alterTable( $whatDatabase, $whatTable, $whatQuery )
	{
		/**
		 *  ALTER TABLE `cars` ADD `engine` varchar(225) DEFAULT NULL ;
		 */
		$sql = "ALTER TABLE $whatDatabase.$whatTable ADD $whatQuery";
		
		$result = mysqli_query ( $this->mysqli, $sql );
		
		if ( ! $result )
		{
			return false;
		}
		return true;
	}
	
	/**
	 * I remove a table
	 *
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the table
	 * @return [string] the result
	 */
	public function removeTable( $whatDatabase, $whatTable )
	{
		/**
		 *   DROP TABLE `library`;
		 */
		$sql = "DROP TABLE $whatDatabase.$whatTable";
		
		$result = mysqli_query ( $this->mysqli, $sql );
		
		if ( ! $result )
		{
			return false;
		}
		return true;
	}
	
	/**
	 * I rename a table
	 *
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the table
	 * @param [string] $newName the new name
	 * @return [string] the result
	 */
	public function renameTable( $whatDatabase, $whatTable, $newName )
	{
		/**
		 *   RENAME TABLE test.books TO test.the_books
		 */
		$sql = "RENAME TABLE $whatDatabase.$whatTable TO $newName";
		
		$result = mysqli_query ( $this->mysqli, $sql );
		
		if ( ! $result )
		{
			return false;
		}
		return true;
	}
	
	/**
	 * I insert data into the database
	 * 
	 * 
	 * 
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the table
	 * @param [array] $whatQuery Array of Key/Value pairs for inserting in the database
	 * @return [string] the result
	 */
	public function insertRecord( $arrayQuery )
	{
		return $this->jquery->buildQuery ( $arrayQuery, 'INSERT', true );
	}
	
	/**
	 * I update data from the database
	 * UPDATE db.tbl SET name='value'
	 * 
	 *
	 * @param [string] $arrayQuery Array of Key/Value pairs for updating the database
	 * @return [string] the result
	 */
	public function updateRecord( $arrayQuery )
	{
		return $this->jquery->buildQuery ( $arrayQuery, 'UPDATE', true );
	}
	
	/**
	 * I remove data from the database
	 *
	 * @param [array] $arrayQuery the value to which remove by
	 * @return [string] the result
	 */
	public function removeRecord( $arrayQuery )
	{
		return $this->jquery->buildQuery ( $arrayQuery, 'DELETE', true );
	}
	
	/* ********************************************************************
 * ********************************************************************
 *  
 * 	 			4. ANALYZE/CHECK/OPTIMIZE/REPAIR METHODS
 * 
 * Below is all the methods analyzing, checking, optimizing and repairing
 * database tables.
 * 
 * ********************************************************************
 * *********************************************************************/
	
	/**
	 * I analyze a table
	 *
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the table
	 * @return [array]
	 */
	public function analyzeTable( $whatDatabase, $whatTable )
	{
		return $this->_queryToArray ( "ANALYZE TABLE $whatDatabase.$whatTable" );
	}
	
	/**
	 * I check a table
	 *
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the table
	 * @return [array]
	 */
	public function checkTable( $whatDatabase, $whatTable )
	{
		return $this->_queryToArray ( "CHECK TABLE $whatDatabase.$whatTable" );
	}
	
	/**
	 * I optimize a table
	 *
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the table
	 * @return [array]
	 */
	public function optimizeTable( $whatDatabase, $whatTable )
	{
		return $this->_queryToArray ( "OPTIMIZE TABLE $whatDatabase.$whatTable" );
	}
	
	/**
	 * I repair a table
	 *
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the table
	 * @return [array]
	 */
	public function repairTable( $whatDatabase, $whatTable )
	{
		return $this->_queryToArray ( "REPAIR TABLE $whatDatabase.$whatTable" );
	}
	
	/**
	 * I analyze a query are return the statistics
	 *
	 * @param [string] $sql query string
	 * @return [array] array results
	 */
	public function analyzeQuery( $sql )
	{
		$setProfileSQL = $this->mysqli->query ( 'SET profiling = 1' );
		$analyzeSQL = $this->mysqli->query ( $sql );
		$showProfileSQL = $this->mysqli->query ( 'SHOW PROFILE' );
		$showProfilesSQL = $this->mysqli->query ( 'SHOW PROFILES' );
		
		$resultArray = array ();
		$profileArray = array ();
		$profilesArray = array ();
		
		/* fetch associative array */
		while ( $row1 = $analyzeSQL->fetch_assoc () )
		{
			$resultArray [] = $row1;
		}
		
		/* fetch associative array */
		while ( $row2 = $showProfileSQL->fetch_assoc () )
		{
			$profileArray [] = $row2;
		}
		
		/* fetch associative array */
		while ( $row3 = $showProfilesSQL->fetch_assoc () )
		{
			$profilesArray [] = $row3;
		}
		
		$analyzedQuery [] = array ( 'aProfile' => $profileArray, 'aProfiles' => $profilesArray, 'aResults' => $resultArray );
		//$analyzedQuery[] = array( $profileArray, $profilesArray, $resultArray );
		

		/* Free all of the results */
		$analyzeSQL->close ();
		$showProfileSQL->close ();
		$showProfilesSQL->close ();
		
		/* close connection */
		//$this->mysqli->close ();
		

		return ( $analyzedQuery );
	}
	
	/* ********************************************************************
 * ********************************************************************
 * 
 * 						7. POLLING METHODS
 * 
 * Below is all the methods for executing a query on the database, 
 * and getting all records from the database.
 * 
 * ********************************************************************
 * ********************************************************************/
	
	/**
	 * I get the health of a mysql server
	 *
	 * @return [array] of results
	 */
	public function _getHealth()
	{
		$query = $this->mysqli->query ( "SHOW GLOBAL STATUS LIKE '%Key_%'" );
		$array = array ();
		
		while ( $row = mysqli_fetch_assoc ( $query ) )
		{
			$array [ $row [ 'Variable_name' ] ] = array ( $row [ 'Variable_name' ] => $row [ 'Value' ] );
		}
		
		return ( $array );
	}
	
	/**
	 * I am a polling method for checking the current select statements.
	 * @return [array] array
	 */
	public function pollQueries()
	{
		$result = mysqli_query ( $this->mysqli, "SHOW GLOBAL STATUS LIKE '%Com_select%'" );
		$timestamp = date ( DATE_W3C );
		
		while ( $row = mysqli_fetch_row ( $result ) )
		{
			$array [] = array ( $row [ 0 ] => $row [ 1 ], 'aTimestamp' => $timestamp );
		}
		return ( $array );
	}
	
	/**
	 * I am a polling method for checking the current bytes sent.
	 * @return [array] results
	 */
	public function pollTraffic()
	{
		$result = mysqli_query ( $this->mysqli, "SHOW GLOBAL STATUS LIKE '%Bytes_sent%'" );
		$timestamp = date ( DATE_W3C );
		
		while ( $row = mysqli_fetch_row ( $result ) )
		{
			$array [] = array ( $row [ 0 ] => $row [ 1 ], 'aTimestamp' => $timestamp );
		}
		return ( $array );
	}
	
	/**
	 * I am a polling method for checking the current connections.
	 * @example Results
	 * <code>
	 * [
	 * 	  {
	 * 		"Com_select":"97",
	 * 		"aTimestamp":"2009-02-20T21:52:34-08:00"
	 *	  }
	 * ]
	 *</code> 
	 * 
	 * @return [array] encoded results
	 */
	public function pollConnections()
	{
		$result = mysqli_query ( $this->mysqli, "SHOW GLOBAL STATUS LIKE '%Threads_connected%'" );
		$timestamp = date ( DATE_W3C );
		$array = array ();
		while ( $row = mysqli_fetch_row ( $result ) )
		{
			$array [] = array ( $row [ 0 ] => $row [ 1 ], 'aTimestamp' => $timestamp );
		}
		
		return ( $array );
	}
	
	/* ********************************************************************
 * ********************************************************************
 * 
 * 						8. DATA METHODS
 * 
 * Below is all the methods for executing a query on the database, 
 * and getting all records from the database.
 * 
 * ********************************************************************
 * ********************************************************************/
	
	/**
	 * I get all the table data
	 *
	 * @param [string] $whatDatabase the database
	 * @param [string] $whatTable the table
	 * @return [array]
	 */
	public function getTableData( $whatDatabase, $whatTable )
	{
		return $this->_queryToArray ( "SELECT * FROM $whatDatabase.$whatTable" );
	}
	
	/**
	 * I execute a query
	 *
	 * @param [string] $query the query to execute
	 * @return [array]
	 */
	public function executeQuery( $sql )
	{
		$query = mysqli_escape_string ( $this->mysqli, $sql );
		return $this->_queryToArray ( $query );
	}
	
	/* ********************************************************************
* ********************************************************************
* 
* 					RESULT HANDLERS
* 
* ********************************************************************
* ********************************************************************/
	
	/**
	 * I execute a query and return the result as an array.
	 *
	 * @param [string] $sql the query to be executed
	 * @return [array] the result array
	 */
	public function _queryToArray( $sql )
	{
		$query = mysqli_query ( $this->mysqli, $sql );
		$array = array ();
		
		while ( $row = mysqli_fetch_assoc ( $query ) )
		{
			$array [] = $row;
		}
		
		return $array;
	}
	
/* ********************************************************************
* ********************************************************************
* 
* 						UTILITY METHODS
* 
* Below is all the utility methods for handling the results from a query
* and dumping variables or creating timestamps
* 
* 
* ********************************************************************
* ********************************************************************/
	
	/**
	 * I ping mysql for a connection
	 *
	 * @return true or false
	 */
	public function ping()
	{
		$msg = '';
		/* check if server is alive */
		if ( $this->mysqli->ping () )
		{
			$msg = true;
		}
		else
		{
			$msg = false;
		}
		return $msg;
	}

}

?>