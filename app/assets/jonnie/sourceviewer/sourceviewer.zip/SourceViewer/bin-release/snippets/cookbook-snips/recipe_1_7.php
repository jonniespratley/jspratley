package com.jonniespratley.snippr.services
{
	import com.jonniespratley.snippr.model.ModelLocator;
	import com.jonniespratley.snippr.vo.EmailVO;
	import com.jonniespratley.snippr.vo.SnippetVO;
	
	import flash.net.NetConnection;
	import flash.net.Responder;
	import flash.utils.ByteArray;
	
	import mx.collections.ArrayCollection;
	import mx.controls.Alert;
	import mx.rpc.events.ResultEvent;
	
	/**
	 * This file is for use without! using the services-config.xml file 
	 * @author Jonnie Spratley
	 * @website http://jonniespratley.com
	 * 
	 */	
	public class SnipprService
	{
		/** NetConnection variable for creating our amfphp connection */		
		private static var _service:NetConnection;
		
		/** Location of our gateway for amfphp */
		private var gateway:String = "http://localhost/snippr/amfphp/gateway.php";
				
		/** Our model so we can update it when we receive our data */		
		private var model:ModelLocator = ModelLocator.getInstance();
		
		/**
		 * Here we are creating a new connection to our amfphp service, when this is instantiated, 
		 * it connects to our service.
		 * 
		 */		
		public function SnipprService()
		{
			_service = new NetConnection();
			_service.connect( gateway );
		}		
		
		/* **********************************************************************
		*			All Service Calls to AMFPHP (updated)
		*
		* 	This is where all of our service calls are taken, when our
		*	outside componets calls these functions all required arguemtns
		*	must be passed to properly send/update/delete data.
		*	
		*	If arguments are not present Flex wont compile. In all of our
		*	calls we attach assigned result handlers for the specific calls
		*	that we are making. They all use the same fault handler.
		************************************************************************/
	
		
		/**
		 * Here we are calling the getSnippets on our server (amfphp) and setting the result and fault handlers 
		 * 
		 */		
		public function getSnippets():void
		{
			_service.call( "snippr.SnipprService.getSnippets", new Responder( snippetResultHandler, snipprFaultHandler ) );
			trace( "Gettings Snippets" );
		}
		
		/**
		 * We take one argument here, and that is a snippet, because our server (amfphp) is expecting a snippetVO 
		 * 
		 * @param snippet snippetVO object
		 * 
		 */		
		public function saveSnippet( snippet:SnippetVO ):void
		{
			_service.call( "snippr.SnipprService.saveSnippet", new Responder( snippetSavedHandler, snipprFaultHandler ), snippet );
			trace( "Saving Snippet" );
		}
		
		/**
		 * We take one argument here, and that is the id of the snippet we are wanting to remove 
		 * 
		 * @param snippet_id the id to be removed
		 * 
		 */		
		public function removeSnippet( snippet_id:uint ):void
		{
			_service.call( "snippr.SnipprService.removeSnippet", new Responder( snippetRemoveHandler, snipprFaultHandler ), snippet_id );
			trace( "Removing Snippet" );
		}
		
		public function searchSnippets( args:Array ):void
		{
			_service.call( "snippr.SnipprService.searchSnippets", new Responder( snippetResultHandler, snippetSearchHandler ), args );
		}
		
		/**
		 * We take two arguments here, one is a byte array and the other is the filename of the file
		 *  
		 * @param bytes byte array
		 * @param filename filename of the file
		 * 
		 */		
		public function takeScreenshot( bytes:ByteArray, filename:String ):void
		{
			_service.call( "snippr.MediaService.takeScreenshot", new Responder( snapshotResultHandler, snipprFaultHandler ), bytes, filename );
			trace( "Sending Screenshot" );
		}
		
		
		/**
		 * We take one argument here, and that is a email value object. 
		 * We are passing this object to amfphp where our email will be sent
		 * 
		 * @param email
		 * 
		 */		
		public function sendEmail( email:EmailVO ):void
		{
			_service.call( "snippr.MediaService.sendEmail", new Responder( emailResultHandler, snippetSavedHandler ), email );
			trace( "Sending Email" ); 
		}		
		
				
		/* ***********************************************************
		*			Result and Fault Handlers
		*
		* 	This is where all of our result and fault handling is 
		*	going to take place, we updating the model on the results
		* 	that we get back. Or simply displaying to the user what
		* 	comes back to Flex.
		**************************************************************/
		
		/**
		 * We are handling the result coming back as an array of snippets, 
		 * then we add our snippets to our model
		 * 
		 * @param data the array of snippets
		 * 
		 */				
		private function snippetResultHandler( data:Array ):void
		{			
			model.snippetCollection =  new ArrayCollection( data );
		}
		
		private function snippetSearchHandler( data:Array ):void
		{
			trace( data );
		}
		
		/**
		 * We are taking the data object as the result, 
		 * tracing it and we could display an alert to 
		 * the user showing him/her whatever message 
		 * we want.
		 * 
		 * @param data a message showing us the status
		 * 
		 */		
		private function emailResultHandler( data:Object ):void
		{
			var result:ResultEvent = data as ResultEvent;
			trace( data );
		}
		
		/**
		 * We are taking the data object as the result, and 
		 * creating a new window, then adding a image inside 
		 * the window. Then populating that image's source
		 * with the url that is sent back, which happens to 
		 * be the url location where the photo is. So we just
		 * add the result which is a string to the source of the image
		 * and displying it.
		 * 
		 * @param data image url 
		 * 
		 */		
		private function snapshotResultHandler( data:Object ):void
		{
			var result:ResultEvent = data as ResultEvent;						
	
			Alert.show( "Nice shot, here is the link to your shot." + data, "Screenshot Saved" );		
				
			trace( data );
		}
		
		
		/**
		 * Here we are handling the result and adding it to the value of serviceResponse in our model
		 * 
		 * @param data the result from amfphp 
		 */		
		private function snippetSavedHandler( data:Object ):void
		{
			ModelLocator.getInstance().serviceResponse = data.toString();
		}
		
		/**
		 * Here we are handling the result that is being returned, which will be the id of the removed snippet, 
		 * removing it from our model, at the snippet index
		 * 
		 * @param data we are just refreshing/calling for the snippets again.
		 */
		private function snippetRemoveHandler( data:Object ):void
		{
			getSnippets();
		}
		
		/**
		 * Here we are alerting the user that there was an error connection to our server
		 * 
		 * @param fault the fault object from the call
		 */
		private function snipprFaultHandler( fault:Object ):void
		{
			Alert.show( "There was an error connecting to the server.", "Snippr Service Error" );
		}		
	}		
}


SnipprForm.mxml

<!--SnippetFormProxyService-->
<mx:VBox xmlns:mx="http://www.adobe.com/2006/mxml" width="100%" height="100%" 
	creationComplete="init()" 
	xmlns:components="com.jonniespratley.snippr.view.components.*">
	
	<mx:Script>
		<![CDATA[
			import mx.events.CloseEvent;
			import mx.controls.Alert;
			import com.jonniespratley.snippr.events.SnippetSaveEvent;
			import mx.validators.Validator;
		
			import com.jonniespratley.snippr.vo.SnippetVO;
			import com.jonniespratley.snippr.model.ModelLocator;
	

			/* Out Model so we can bind to the selectedSnippet */
			[Bindable] public var selectedSnippet:SnippetVO;
			[Bindable] private var model:ModelLocator = ModelLocator.getInstance();
			
			/* Our validation array to hold the values of our validators */
			[Bindable] private var validators:Array = new Array();			
			
			/* We alway set our validators to our validator array */
			private function init():void
			{				
				validators = [ titleV, authorV, codeV, typeV ];
			}
			
			/* 
			When the save button is clicked instead of sending the data right away
			we first check it to see if it is indeed valid. If our validation array 
			is empty, then we can go ahead and send our value object to amfphp, other
			wise we need to alert the user that there are some errors in the form
			*/
			private function checkForm():void
			{
				var vals:Array = new Array();
					vals = Validator.validateAll( validators );
				
				//If no errors
				if ( vals.length == 0 )
				{
					saveSnippet();
					//cleanForms();
				} else {
					Alert.show( "Please correct invalid form entries", "Validation Error" );
				}
			}
						
			/* 
			The saveSnippet function that gets called when there is no errors in our form
			This is one function that is going to handle both creating a new snippet, and
			updating an existing one. Our server side php script says that if the snippetVO[snippet_id]
			is equal to 0, then go ahead and insert it as a new snippet. But if the snippetVO[snippet_id]
			is not set to 0, then update that snippet where the recieved id is equal to the id we are updating.
			*/
			private function saveSnippet():void
			{
				/* If the selectedSnippet is empty create a new snippet */
				if ( selectedSnippet == null ) 
				{					
				var createS:SnippetVO = new SnippetVO();
					createS.snippet_id = 0;
					createS.snippet_title = txt_title.text;
					createS.snippet_code = txt_code.text;
					createS.snippet_user = txt_author.text;
					createS.snippet_type = txt_type.text;
				
				/* Cairngorm Event */
				var cEvent:SnippetSaveEvent = new SnippetSaveEvent( createS );
					cEvent.dispatch();				
				} else {
					Alert.show( "This snippet is going to be edited", "Are you Sure?", 3, null, editSnippetHandler );
				}		
				/* Do nothing */
			}
			
			private function editSnippetHandler( event:CloseEvent ):void
			{
				if ( event.detail == Alert.YES )
				{					
					/* Set the snippet id to the value of the selected snippet_id */					
					var updateS:SnippetVO = new SnippetVO();
						updateS.snippet_id = selectedSnippet.snippet_id;
						updateS.snippet_title = txt_title.text;
						updateS.snippet_code = txt_code.text;
						updateS.snippet_user = txt_author.text;
						updateS.snippet_type = txt_type.text;
				
					/* Cairngorm Event */
				var uEvent:SnippetSaveEvent = new SnippetSaveEvent( updateS );
					uEvent.dispatch();										
				}
				//Just return
			}
			
			/* Clears all form inputs, and resets the selected index of the snippet list */
			private function cleanForms():void
			{
				//Set the model.selectedSnippet to null, so we dont have any fields used up
				selectedSnippet = new SnippetVO();
				txt_title.text = "";
				txt_author.text = "";
				txt_code.text = "";
				txt_type.text = "";
			}
			
			private function selectHandler( event:Event ):void
			{
				selectedSnippet = event.target.selectedItem as SnippetVO;
			}

							
		]]>
	</mx:Script>
	
	<mx:ApplicationControlBar width="100%" styleName="formBar">
		<mx:HBox width="100%" verticalAlign="middle">			
			<mx:Label text="Author:" fontWeight="bold"/>
			<mx:TextInput id="txt_author"
				text="{ selectedSnippet.snippet_user }" 
				width="100%"/>			
		</mx:HBox>				
	</mx:ApplicationControlBar>
	
	<mx:ApplicationControlBar width="100%" styleName="formBar">		
		<mx:HBox width="100%" verticalAlign="middle">
				
				<mx:Label text="Title:" fontWeight="bold"/>
				<mx:TextInput id="txt_title"
					text="{ selectedSnippet.snippet_title }"
					 width="100%"/>	
					 	
				<mx:Label text="Type:" fontWeight="bold"/>
				<mx:TextInput id="txt_type"
					text="{ selectedSnippet.snippet_type }" 
					width="100%"/>
		
			<mx:Button id="btn_clear"
				click="cleanForms()"
 				label="Clear"/>
 				
			<mx:Button id="btn_save"
				click="checkForm()" 
 				label="Save"/>
 				
		</mx:HBox>
	</mx:ApplicationControlBar>
		
			<mx:VBox width="100%" height="100%" label="Edit">				
				<mx:TextArea id="txt_code"
					text="{ selectedSnippet.snippet_code }"
					width="100%" 
					height="100%" 
 					styleName="codeView"/>				
			</mx:VBox>	
	 <mx:DataGrid dataProvider="{ model.snippetCollection }"
	 	change="selectHandler( event )"/>
	
	
	<!-- Validators -->
	<mx:StringValidator id="titleV"
		source="{ txt_title }"
		minLength="1"
		maxLength="200"
		required="true"
		property="text"/>
	<mx:StringValidator id="authorV"
		source="{ txt_author }"
		minLength="1"
		maxLength="200"
		required="true"
		property="text"/>
	<mx:StringValidator id="codeV"
		source="{ txt_code }"
		minLength="5"
		required="true"
		property="text"/>
	<mx:StringValidator id="typeV"
		source="{ txt_type }"
		minLength="1"
		maxLength="200"
		required="true"
		property="text"/>		
</mx:VBox>


SnippetList.mxml
<!--SnippetList-->
<mx:VBox 
	xmlns:mx="http://www.adobe.com/2006/mxml" 
	width="200" 
	height="100%" 
	creationComplete="getSnippets()">

	<mx:Script>
		<![CDATA[
			import mx.events.CloseEvent;
			import com.jonniespratley.snippr.events.SnippetRemoveEvent;
			import mx.controls.Alert;
			import com.jonniespratley.snippr.vo.SnippetVO;
			import com.jonniespratley.snippr.events.SnippetGetEvent;
			import com.jonniespratley.snippr.model.ModelLocator;			
			
			//Make a instance of our model for our data display
			[Bindable] private var model:ModelLocator = ModelLocator.getInstance();
			[Bindable] public var selectedSnippet:SnippetVO;				
						
			[Bindable] private var isSelected:Boolean = false;	
			
			//Send a call to get the snippets
			private function getSnippets():void
			{			
				var evt:SnippetGetEvent = new SnippetGetEvent();
					evt.dispatch();
			}
			
			//Make sure we handle the selected snippet and bind it to our model
			private function selectHandler( event:Event ):void
			{
				selectedSnippet = event.target.selectedItem as SnippetVO;
				isSelected = true;
			}
			
			private function removeSnippet():void
			{		
				Alert.show( "Are you sure?", "Remove Snippet", 3, null, removeSnippetAlertHandler );						
			}
			
	
			private function removeSnippetAlertHandler( event:CloseEvent ):void
			{
				if ( event.detail == Alert.YES )
				{
					var evt:SnippetRemoveEvent = new SnippetRemoveEvent( lt_snippets.selectedItem.snippet_id ); 
						evt.dispatch();
				}
			}
			
		]]>
	</mx:Script>
	
	<!--List of Snippets-->
	<mx:List id="lt_snippets"
		dataProvider="{ model.snippetCollection }"
		change="selectHandler( event )"
		labelField="snippet_title" 
		width="100%" 
		height="100%"/>
		
	<!--Refrest Button -->
	<mx:Button label="Remove"
		click="removeSnippet()"
		enabled="{ isSelected }" 
		width="100%"/>			
</mx:VBox>