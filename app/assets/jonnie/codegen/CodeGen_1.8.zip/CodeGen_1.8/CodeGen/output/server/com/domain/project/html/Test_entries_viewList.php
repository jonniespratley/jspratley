<?php 
require_once '../Test_entries_viewService.php';
require_once '../vo/Test_entries_viewVO.php';

$service = new Test_entries_viewService();
$result = '';
$recordList = '';

if ( isset($_POST['save']) )
{
	unset( $_POST['save'] );
	$recordValues = $_POST;
	$result = $service->saveTest_entries_view( $recordValues );	
}

$recordsArray = $service->getAllTest_entries_view();
$recordVO = new Test_entries_viewVO();

for ( $i = 0; $i < count( $recordsArray ); $i++ ) 
{
	$recordVO = $recordsArray[ $i ];
	
	$recordList .= '<tr id="'.$recordVO->user_id.'">';

	
			$recordList .= "<td>$recordVO->entry_body</td>";
			$recordList .= "<td>$recordVO->entry_created</td>";
			$recordList .= "<td>$recordVO->entry_title</td>";
			$recordList .= "<td>$recordVO->id</td>";
			$recordList .= "<td>$recordVO->location_id</td>";
			$recordList .= "<td>$recordVO->upload_id</td>";
			$recordList .= "<td>$recordVO->user_id</td>";

	$recordList .= '<td class="actions">';
	$recordList .= '<button class="edit" onclick="window.location=\'Test_entries_viewForm.php?id='.$recordVO->user_id.'\'">Edit</button>';
	$recordList .= '<button class="delete" onclick=" remove('.$recordVO->user_id.')">Delete</button></td>';
	$recordList .= '</tr>';
}

?>
<?php include '_header.php'; ?> 

<script type="text/javascript">
var service = '../Test_entries_viewService.php';

function remove( id ){
	$.get( service, { m: 'remove', id: id }, function(data){
		if ( data ) {
			$('#'+id).fadeOut('slow');
		} else {
			alert( 'There was a problem!' );
		}
	});
}
</script>

<h3>Test_entries_view</h3>

    <table width="100%" border="0">
	<tr>
		
			<th scope="col">entry_body</th>
			<th scope="col">entry_created</th>
			<th scope="col">entry_title</th>
			<th scope="col">id</th>
			<th scope="col">location_id</th>
			<th scope="col">upload_id</th>
			<th scope="col">user_id</th><th scope="col">Actions</th>   
    </tr>
       <?php echo $recordList; ?>
    </table>
    
    <a href="Test_entries_viewForm.php">New Test_entries_view</a>
  
 <?php include '_footer.php'; ?>