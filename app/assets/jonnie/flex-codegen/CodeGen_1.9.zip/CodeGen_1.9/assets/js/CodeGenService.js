$(function(){


    /* ======================================================================
     * Private variables for service management
     * ====================================================================== */
    var baseURL = "http://" + window.location.hostname + "/CodeGen";
    var service = "library/FlexService.php";
    var cg_host;// Host
    var cg_user;// Username
    var cg_pass;// Password
    var cg_database;// Database
    var cg_app;// Application
    var cg_namespace;// Namespace
    var cg_endpoint;// Endpoint
    var cg_framework;// Framework
    var cg_copywrite;// Copywrite
    var cg_config;// Config
    var cg_schema;// Schema
    var resultData;
    var cg_demoURL = '';

	 
	 /* ======================================================================
     * File System Reader
     * ====================================================================== */
	
    $('#fileTree').fileTree(
    {
        root: '../../Templates/',
		  script: 'assets/js/jqueryFileTree.php',
		  loadMessage: 'Loading...'
		 
    }, function( file ) {
	
		var newFile = file.replace(/^(..\/..\/)/gi, '');
		
		//TODO: Fix the path to the file
		$.get( service, { 
				m: 'readFile', 
				f: '/Applications/MAMP/htdocs/CodeGen/' + newFile 
			}, function(data)
			{
				$("#code").html( data );
		});
    });
	 
	 
	 /* ======================================================================
     * Generated Files Reader
     * ====================================================================== */
	 $('#outputFileTree').fileTree(
    {
        root: '../../output/',
		  script: 'assets/js/jqueryFileTree.php',
		
    }, function( file ) {
	
		var newFile = file.replace(/^(..\/..\/)/gi, '');
		
		//TODO: Fix the path to the file
		$.get( service, { 
				m: 'readFile', 
				f: '/Applications/MAMP/htdocs/CodeGen/' + newFile 
			}, function(data)
			{
				$("#outputCode").html( data ).chili();
		});
    });
	 
	 
	 /* ======================================================================
     * Save Settings to text file as json
     * ====================================================================== */
	 $("#btn_saveSettings").click(function(){
	 	
		//Build and encode the json
		//$.toJSON(thing);
		var jsonSettings = $.toJSON( [ { 'appName': cg_app, 'appURL': cg_demoURL } ] );
		
	 	$.get( service, {
			m: 'saveSettings',
			s: jsonSettings
		}, function( data )
		{
			alert( data );
		});
	 });
	 
	 
	
	
    /* ======================================================================
     * Gets all databases when password input is out of focus
     * ====================================================================== */
    $("#txt_pass").blur(function(){
        $("#db_loader").toggle();
        $.get(service, {
            m: 'getDatabases',
            h: $("#txt_host").val(),
            u: $("#txt_user").val(),
            p: $("#txt_pass").val()
        }, function(result)
        {
            $("#db_loader").toggle();
            var options = '';
            var dbArray = [];
            var dbArray = $.evalJSON(result);
            
            for (i = 0; i < dbArray.length; i++) {
                options += '<option>' + dbArray[i]['label'] + '</option>';
            }
            $("select#txt_database").html(options).highlightFade('yellow');
        });
    });
    
    
    /* ======================================================================
     * Config Form
     * ====================================================================== */
    $("#btn_generateConfig").click(function(){
    
        // Step 1
        cg_host = $("#txt_host").val();
        cg_user = $("#txt_user").val();
        cg_pass = $("#txt_pass").val();
        cg_database = $("#txt_database").val();
        
        // Step 2
        cg_app = $("#txt_application").val();
        cg_namespace = $("#txt_namespace").val();
        cg_endpoint = $("#txt_endpoint").val();
        cg_framework = $("#txt_framework").val();
        cg_copywrite = $("#txt_copywrite").val();
        
        
        //Cookies$.cookies.set('sidebar', 'Jonnie', null );
        //Array of cookies
        var cookieArray = [{
            h: cg_host,
            u: cg_user,
            p: cg_pass,
            d: cg_database,
            a: cg_app,
            n: cg_namespace,
            e: cg_endpoint,
            f: cg_framework,
            c: cg_copywrite
        }];
        
      
	
	   // Send the call
        $.get(service, {
            m: "generateConfig",
            h: cg_host,
            u: cg_user,
            p: cg_pass,
            d: cg_database,
            a: cg_app,
            n: cg_namespace,
            e: cg_endpoint,
            f: cg_framework,
            c: cg_copywrite
        }, function(result){            
            result = $.trim(result).replace(/[\\]*[\\"]/g, '');

            //@TODO: Hack to remove the .. from the url
            cg_config = result;
            
			$("#configLocation").html(result);
            $("#txt_configLocation").val(result).highlightFade("yellow");
        });
    });
    
    
    /* ======================================================================
     * Schema Form
     * ====================================================================== */
    $("#btn_generateSchema").click(function(){
        $.get(service, {
            m: "generateSchema",
            c: cg_config,
            d: cg_database
        }, function(result){
            result = $.trim(result).replace(/[\\]*[\\"]/g, '');
            cg_schema = result;
            
            $("#schemaLocation").html(result);
            $("#txt_schemaLocation").val(result).highlightFade("yellow");
            
            
        });
    });
	 
    
    /* ======================================================================
     * Application Info Form
     * ====================================================================== */
    $("#btn_generateApp").click(function(){
        
        cg_config = $("#txt_configLocation").val();
        cg_database = $("#txt_database").val();
        
		  $.get(service, {
            m: "generateApplication",
            d: cg_database,
            s: cg_schema
        }, function(result){
            result = $.trim(result).replace(/^(..)/gi, '');
            
                //Set the demo url 
                cg_demoURL = baseURL + result
				
				//Dump into debug
				$("#dump").html( "<b>Trimmed URL:</b> " + result + "<br/><b>Demo URL:</b> " + cg_demoURL );

                //Show the generated files, and ask to save application
				$("#step4").show('slow');
				
				//Open the preview
				$.fn.colorbox( { href: cg_demoURL, open:true, iframe: true, width: "90%", height:"90%" } ); 	
				
			
        });
    });
    
	 
	 
	
 /* ============================================================================================================================================ 
  * Samples
	============================================================================================================================================   */
	 
    
    /* ======================================================================
     * getDemoURL
     * ====================================================================== */
    function getDemoURL(){
      
		  $.get(service, {
            m: 'getHTMLDemo'
        }, function(result){
        
            // result = $.trim( result ).replace( /[\\]*[\\"]/g, '' );
            $("#iframe_preview").attr("src", result);
        });
    }
    
	 
    /* ======================================================================
     * Gets all databases and tables for management
     * ====================================================================== */
    $('.db').bind('click', function(){
        var db = this.text;
        $.get(service, {
            m: 'getTables',
            h: $("#txt_host").val(),
            u: $("#txt_user").val(),
            p: $("#txt_pass").val(),
            d: db
        }, 
		  function(result){
            var options = '';
            var dbArray = [];
            var dbArray = $.evalJSON(result);
            
            for (i = 0; i < dbArray.length; i++) {
                options += '<li><b>' + dbArray[i]['label'] + '</b></li>';
                
                if ((dbArray[i]['aFields'])) {
                    var fieldArray = dbArray[i]['aFields'];
                    for (j = 0; j < fieldArray.length; j++) {
                        options += '<ul><li>' + fieldArray[j]['Field'] + '</li></ul>';
                    }
                    
                }
                options += '</li>';
            }
            $("div#tables").html(options);
        });
        return false;
    });
	 
	 
    /* ======================================================================
     * 
     * ====================================================================== */
    $("#btn_db").click(function(){
	 
        $.get(service, {
            m: 'getDatabases',
            h: $("#txt_host").val(),
            u: $("#txt_user").val(),
            p: $("#txt_pass").val()
        }, function(result){
		  		$('.loader').css({display: 'none'});
            var options = '';
            var dbArray = [];
            var dbArray = $.evalJSON(result);
            
            for (i = 0; i < dbArray.length; i++) {
                options += '<li>' + dbArray[i]['label'] + '</li>';
            }
            $("div#db").html(options);
        });
    });
	
	
	/* ======================================================================
    * Ajax Requests, utility functions 
    * ====================================================================== */ 
	$("#svcMessage").ajaxSend(function(request, settings){
	  $( this ).html('<p class="notice">Starting request at ' + settings.url + '</p>');
	});
	
	$("#svcMessage").ajaxSuccess(function(request, settings){
	  $( this ).html('<p class="success">Successful Request!</p>');
	});	
	
	$("#svcMessage").ajaxComplete(function(request, settings){
	  $( this ).html('<p class="success">Request Complete.</p>');
	});
	
	$("#svcMessage").ajaxError(function(request, settings){
	  $( this ).html('<p class="error">Error requesting page ' + settings.url + '</p>');
	});
	
	$("#svcLoader").ajaxStart(function(){
	  $( this ).show();
	});
	
	$("#svcLoader").ajaxStop(function(){
	  $( this ).hide();
	});




	 
});
