<?php 
require_once '../PostsService.php';
require_once '../vo/PostsVO.php';

$service = new PostsService();
$result = '';
$recordList = '';

if ( isset($_POST['save']) )
{
	unset( $_POST['save'] );
	$recordValues = $_POST;
	$result = $service->savePosts( $recordValues );	
}

$recordsArray = $service->getAllPosts();
$recordVO = new PostsVO();

for ( $i = 0; $i < count( $recordsArray ); $i++ ) 
{
	$recordVO = $recordsArray[ $i ];
	
	$recordList .= '<tr id="'.$recordVO->id.'">';

	
			$recordList .= "<td>$recordVO->body</td>";
			$recordList .= "<td>$recordVO->excerpt</td>";
			$recordList .= "<td>$recordVO->id</td>";
			$recordList .= "<td>$recordVO->title</td>";

	$recordList .= '<td class="actions">';
	$recordList .= '<button class="edit" onclick="window.location=\'PostsForm.php?id='.$recordVO->id.'\'">Edit</button>';
	$recordList .= '<button class="delete" onclick=" remove('.$recordVO->id.')">Delete</button></td>';
	$recordList .= '</tr>';
}

?>
<?php include '_header.php'; ?> 

<script type="text/javascript">
var service = '../PostsService.php';

function remove( id ){
	$.get( service, { m: 'remove', id: id }, function(data){
		if ( data ) {
			$('#'+id).fadeOut('slow');
		} else {
			alert( 'There was a problem!' );
		}
	});
}
</script>

<h3>Posts</h3>

    <table width="100%" border="0">
	<tr>
		
			<th scope="col">body</th>
			<th scope="col">excerpt</th>
			<th scope="col">id</th>
			<th scope="col">title</th><th scope="col">Actions</th>   
    </tr>
       <?php echo $recordList; ?>
    </table>
    
    <a href="PostsForm.php">New Posts</a>
  
 <?php include '_footer.php'; ?>