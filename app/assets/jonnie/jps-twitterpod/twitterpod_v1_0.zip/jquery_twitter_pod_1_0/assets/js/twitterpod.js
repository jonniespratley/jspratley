/**
 * jQuery - jCarousel Plugin
 *   http://sorgalla.com/jcarousel/
 */
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('(9($){$.1B.z=9(o){r 4.1i(9(){36 $t(4,o)})};8 1K={Z:F,2g:1,1R:1,h:7,1d:3,P:7,22:\'35\',2u:\'37\',1t:0,A:7,1x:7,21:7,2y:7,2O:7,2L:7,2H:7,2I:7,2J:7,2K:7,29:\'<Q></Q>\',27:\'<Q></Q>\',2G:\'2D\',2w:\'2D\',1Q:7,1T:7};$.z=9(e,o){4.5=$.1e({},1K,o||{});4.S=F;4.C=7;4.G=7;4.g=7;4.T=7;4.V=7;4.B=!4.5.Z?\'26\':\'2i\';4.E=!4.5.Z?\'2e\':\'2f\';8 1o=\'\',1l=e.K.1l(\' \');1s(8 i=0;i<1l.I;i++){6(1l[i].2M(\'z-1o\')!=-1){$(e).1E(1l[i]);8 1o=1l[i];1u}}6(e.2x==\'2W\'||e.2x==\'34\'){4.g=$(e);4.C=4.g.1c();6(4.C.1A(\'z-G\')){6(!4.C.1c().1A(\'z-C\'))4.C=4.C.A(\'<Q></Q>\');4.C=4.C.1c()}16 6(!4.C.1A(\'z-C\'))4.C=4.g.A(\'<Q></Q>\').1c()}16{4.C=$(e);4.g=$(e).33(\'>2Q,>2P,Q>2Q,Q>2P\')}6(1o!=\'\'&&4.C.1c()[0].K.2M(\'z-1o\')==-1)4.C.A(\'<Q 2X=" \'+1o+\'"></Q>\');4.G=4.g.1c();6(!4.G.I||!4.G.1A(\'z-G\'))4.G=4.g.A(\'<Q></Q>\').1c();4.V=$(\'.z-19\',4.C);6(4.V.h()==0&&4.5.27!=7)4.V=4.G.1H(4.5.27).19();4.V.Y(4.K(\'z-19\'));4.T=$(\'.z-1g\',4.C);6(4.T.h()==0&&4.5.29!=7)4.T=4.G.1H(4.5.29).19();4.T.Y(4.K(\'z-1g\'));4.G.Y(4.K(\'z-G\'));4.g.Y(4.K(\'z-g\'));4.C.Y(4.K(\'z-C\'));8 1m=4.5.P!=7?1z.25(4.10()/4.5.P):7;8 18=4.g.32(\'18\');8 k=4;6(18.h()>0){8 B=0,i=4.5.1R;18.1i(9(){k.2b(4,i++);B+=k.W(4,1m)});4.g.q(4.B,B+\'U\');6(!o||o.h===J)4.5.h=18.h()}4.C.q(\'1O\',\'1L\');4.T.q(\'1O\',\'1L\');4.V.q(\'1O\',\'1L\');4.2F=9(){k.1g()};4.2v=9(){k.19()};4.20=9(){k.2s()};6(4.5.1x!=7)4.5.1x(4,\'2B\');6($.2p.2q){4.1q(F,F);$(2c).1F(\'30\',9(){k.1C()})}16 4.1C()};8 $t=$.z;$t.1B=$t.2Y={z:\'0.2.3\'};$t.1B.1e=$t.1e=$.1e;$t.1B.1e({1C:9(){4.u=7;4.y=7;4.14=7;4.1a=7;4.1f=F;4.1p=7;4.N=7;4.11=F;6(4.S)r;4.g.q(4.E,4.H(4.5.1R)+\'U\');8 p=4.H(4.5.2g);4.14=4.1a=7;4.1w(p,F);$(2c).1W(\'2d\',4.20).1F(\'2d\',4.20)},2h:9(){4.g.2k();4.g.q(4.E,\'39\');4.g.q(4.B,\'38\');6(4.5.1x!=7)4.5.1x(4,\'2h\');4.1C()},2s:9(){6(4.N!=7&&4.11)4.g.q(4.E,$t.L(4.g.q(4.E))+4.N);4.N=7;4.11=F;6(4.5.21!=7)4.5.21(4);6(4.5.P!=7){8 k=4;8 1m=1z.25(4.10()/4.5.P),B=0,E=0;$(\'18\',4.g).1i(9(i){B+=k.W(4,1m);6(i+1<k.u)E=B});4.g.q(4.B,B+\'U\');4.g.q(4.E,-E+\'U\')}4.1d(4.u,F)},3a:9(){4.S=1n;4.1q()},2S:9(){4.S=F;4.1q()},h:9(s){6(s!=J){4.5.h=s;6(!4.S)4.1q()}r 4.5.h},2R:9(i,13){6(13==J||!13)13=i;6(4.5.h!==7&&13>4.5.h)13=4.5.h;1s(8 j=i;j<=13;j++){8 e=4.M(j);6(!e.I||e.1A(\'z-1b-1I\'))r F}r 1n},M:9(i){r $(\'.z-1b-\'+i,4.g)},2j:9(i,s){8 e=4.M(i),15=0,2j=0;6(e.I==0){8 c,e=4.1N(i),j=$t.L(i);1y(c=4.M(--j)){6(j<=0||c.I){j<=0?4.g.2m(e):c.28(e);1u}}}16 15=4.W(e);e.1E(4.K(\'z-1b-1I\'));1U s==\'2V\'?e.2T(s):e.2k().2U(s);8 1m=4.5.P!=7?1z.25(4.10()/4.5.P):7;8 B=4.W(e,1m)-15;6(i>0&&i<4.u)4.g.q(4.E,$t.L(4.g.q(4.E))-B+\'U\');4.g.q(4.B,$t.L(4.g.q(4.B))+B+\'U\');r e},1Z:9(i){8 e=4.M(i);6(!e.I||(i>=4.u&&i<=4.y))r;8 d=4.W(e);6(i<4.u)4.g.q(4.E,$t.L(4.g.q(4.E))+d+\'U\');e.1Z();4.g.q(4.B,$t.L(4.g.q(4.B))-d+\'U\')},1g:9(){4.1G();6(4.N!=7&&!4.11)4.1V(F);16 4.1d(((4.5.A==\'1P\'||4.5.A==\'y\')&&4.5.h!=7&&4.y==4.5.h)?1:4.u+4.5.1d)},19:9(){4.1G();6(4.N!=7&&4.11)4.1V(1n);16 4.1d(((4.5.A==\'1P\'||4.5.A==\'u\')&&4.5.h!=7&&4.u==1)?4.5.h:4.u-4.5.1d)},1V:9(b){6(4.S||4.1f||!4.N)r;8 H=$t.L(4.g.q(4.E));!b?H-=4.N:H+=4.N;4.11=!b;4.14=4.u;4.1a=4.y;4.1w(H)},1d:9(i,a){6(4.S||4.1f)r;4.1w(4.H(i),a)},H:9(i){6(4.S||4.1f)r;6(4.5.A!=\'1h\')i=i<1?1:(4.5.h&&i>4.5.h?4.5.h:i);8 17=4.u>i;8 H=$t.L(4.g.q(4.E));8 f=4.5.A!=\'1h\'&&4.u<=1?1:4.u;8 c=17?4.M(f):4.M(4.y);8 j=17?f:f-1;8 e=7,l=0,p=F,d=0;1y(17?--j>=i:++j<i){e=4.M(j);p=!e.I;6(e.I==0){e=4.1N(j).Y(4.K(\'z-1b-1I\'));c[17?\'1H\':\'28\'](e)}c=e;d=4.W(e);6(p)l+=d;6(4.u!=7&&(4.5.A==\'1h\'||(j>=1&&(4.5.h==7||j<=4.5.h))))H=17?H+d:H-d}8 10=4.10();8 1D=[];8 P=0,j=i,v=0;8 c=4.M(i-1);1y(++P){e=4.M(j);p=!e.I;6(e.I==0){e=4.1N(j).Y(4.K(\'z-1b-1I\'));c.I==0?4.g.2m(e):c[17?\'1H\':\'28\'](e)}c=e;8 d=4.W(e);6(d==0){3B(\'3u: 3t 26/2i 3s 1s 3v. 3w 3A 3x 3y 3z 3b. 3D...\');r 0}6(4.5.A!=\'1h\'&&4.5.h!==7&&j>4.5.h)1D.3q(e);16 6(p)l+=d;v+=d;6(v>=10)1u;j++}1s(8 x=0;x<1D.I;x++)1D[x].1Z();6(l>0){4.g.q(4.B,4.W(4.g)+l+\'U\');6(17){H-=l;4.g.q(4.E,$t.L(4.g.q(4.E))-l+\'U\')}}8 y=i+P-1;6(4.5.A!=\'1h\'&&4.5.h&&y>4.5.h)y=4.5.h;6(j>y){P=0,j=y,v=0;1y(++P){8 e=4.M(j--);6(!e.I)1u;v+=4.W(e);6(v>=10)1u}}8 u=y-P+1;6(4.5.A!=\'1h\'&&u<1)u=1;6(4.11&&17){H+=4.N;4.11=F}4.N=7;6(4.5.A!=\'1h\'&&y==4.5.h&&(y-P+1)>=1){8 m=$t.12(4.M(y),!4.5.Z?\'1r\':\'1Y\');6((v-m)>10)4.N=v-10-m}1y(i-->u)H+=4.W(4.M(i));4.14=4.u;4.1a=4.y;4.u=u;4.y=y;r H},1w:9(p,a){6(4.S||4.1f)r;4.1f=1n;8 k=4;8 24=9(){k.1f=F;6(p==0)k.g.q(k.E,0);6(k.5.A==\'1P\'||k.5.A==\'y\'||k.5.h==7||k.y<k.5.h)k.2z();k.1q();k.2a(\'2r\')};4.2a(\'3r\');6(!4.5.22||a==F){4.g.q(4.E,p+\'U\');24()}16{8 o=!4.5.Z?{\'2e\':p}:{\'2f\':p};4.g.1w(o,4.5.22,4.5.2u,24)}},2z:9(s){6(s!=J)4.5.1t=s;6(4.5.1t==0)r 4.1G();6(4.1p!=7)r;8 k=4;4.1p=3f(9(){k.1g()},4.5.1t*3e)},1G:9(){6(4.1p==7)r;3d(4.1p);4.1p=7},1q:9(n,p){6(n==J||n==7){8 n=!4.S&&4.5.h!==0&&((4.5.A&&4.5.A!=\'u\')||4.5.h==7||4.y<4.5.h);6(!4.S&&(!4.5.A||4.5.A==\'u\')&&4.5.h!=7&&4.y>=4.5.h)n=4.N!=7&&!4.11}6(p==J||p==7){8 p=!4.S&&4.5.h!==0&&((4.5.A&&4.5.A!=\'y\')||4.u>1);6(!4.S&&(!4.5.A||4.5.A==\'y\')&&4.5.h!=7&&4.u==1)p=4.N!=7&&4.11}8 k=4;4.T[n?\'1F\':\'1W\'](4.5.2G,4.2F)[n?\'1E\':\'Y\'](4.K(\'z-1g-1J\')).23(\'1J\',n?F:1n);4.V[p?\'1F\':\'1W\'](4.5.2w,4.2v)[p?\'1E\':\'Y\'](4.K(\'z-19-1J\')).23(\'1J\',p?F:1n);6(4.T.I>0&&(4.T[0].1k==J||4.T[0].1k!=n)&&4.5.1Q!=7){4.T.1i(9(){k.5.1Q(k,4,n)});4.T[0].1k=n}6(4.V.I>0&&(4.V[0].1k==J||4.V[0].1k!=p)&&4.5.1T!=7){4.V.1i(9(){k.5.1T(k,4,p)});4.V[0].1k=p}},2a:9(O){8 X=4.14==7?\'2B\':(4.14<4.u?\'1g\':\'19\');4.R(\'2y\',O,X);6(4.14!==4.u){4.R(\'2O\',O,X,4.u);4.R(\'2L\',O,X,4.14)}6(4.1a!==4.y){4.R(\'2H\',O,X,4.y);4.R(\'2I\',O,X,4.1a)}4.R(\'2J\',O,X,4.u,4.y,4.14,4.1a);4.R(\'2K\',O,X,4.14,4.1a,4.u,4.y)},R:9(1j,O,X,1v,13,2C,2o){6(4.5[1j]==J||(1U 4.5[1j]!=\'2l\'&&O!=\'2r\'))r;8 R=1U 4.5[1j]==\'2l\'?4.5[1j][O]:4.5[1j];6(!$.3g(R))r;8 k=4;6(1v===J)R(k,X,O);16 6(13===J)4.M(1v).1i(9(){R(k,4,1v,X,O)});16{1s(8 i=1v;i<=13;i++)6(i!==7&&!(i>=2C&&i<=2o))4.M(i).1i(9(){R(k,4,i,X,O)})}},1N:9(i){r 4.2b(\'<18></18>\',i)},2b:9(e,i){8 $e=$(e).Y(4.K(\'z-1b\')).Y(4.K(\'z-1b-\'+i));$e.23(\'3l\',i);r $e},K:9(c){r c+\' \'+c+(!4.5.Z?\'-3k\':\'-Z\')},W:9(e,d){8 D=e.2t!=J?e[0]:e;8 15=!4.5.Z?D.1M+$t.12(D,\'2E\')+$t.12(D,\'1r\'):D.2N+$t.12(D,\'2A\')+$t.12(D,\'1Y\');6(d==J||15==d)r 15;8 w=!4.5.Z?d-$t.12(D,\'2E\')-$t.12(D,\'1r\'):d-$t.12(D,\'2A\')-$t.12(D,\'1Y\');$(D).q(4.B,w+\'U\');r 4.W(D)},10:9(){r!4.5.Z?4.G[0].1M-$t.L(4.G.q(\'3n\'))-$t.L(4.G.q(\'3p\')):4.G[0].2N-$t.L(4.G.q(\'3o\'))-$t.L(4.G.q(\'3j\'))},3i:9(i,s){6(s==J)s=4.5.h;r 1z.3c((((i-1)/s)-1z.3h((i-1)/s))*s)+1}});$t.1e({1K:9(d){r $.1e(1K,d||{})},12:9(e,p){6(!e)r 0;8 D=e.2t!=J?e[0]:e;6(p==\'1r\'&&$.2p.2q){8 15={\'1O\':\'1L\',\'3E\':\'3C\',\'26\':\'1t\'},1S,1X;$.2n(D,15,9(){1S=D.1M});15[\'1r\']=0;$.2n(D,15,9(){1X=D.1M});r 1X-1S}r $t.L($.q(D,p))},L:9(v){v=31(v);r 2Z(v)?0:v}})})(3m);',62,227,'||||this|options|if|null|var|function|||||||list|size|||self||||||css|return||jc|first||||last|jcarousel|wrap|wh|container|el|lt|false|clip|pos|length|undefined|className|intval|get|tail|evt|visible|div|callback|locked|buttonNext|px|buttonPrev|dimension|state|addClass|vertical|clipping|inTail|margin|i2|prevFirst|old|else|back|li|prev|prevLast|item|parent|scroll|extend|animating|next|circular|each|cb|jcarouselstate|split|di|true|skin|timer|buttons|marginRight|for|auto|break|i1|animate|initCallback|while|Math|hasClass|fn|setup|cache|removeClass|bind|stopAuto|before|placeholder|disabled|defaults|block|offsetWidth|create|display|both|buttonNextCallback|offset|oWidth|buttonPrevCallback|typeof|scrollTail|unbind|oWidth2|marginBottom|remove|funcResize|reloadCallback|animation|attr|scrolled|ceil|width|buttonPrevHTML|after|buttonNextHTML|notify|format|window|resize|left|top|start|reset|height|add|empty|object|prepend|swap|i4|browser|safari|onAfterAnimation|reload|jquery|easing|funcPrev|buttonPrevEvent|nodeName|itemLoadCallback|startAuto|marginTop|init|i3|click|marginLeft|funcNext|buttonNextEvent|itemLastInCallback|itemLastOutCallback|itemVisibleInCallback|itemVisibleOutCallback|itemFirstOutCallback|indexOf|offsetHeight|itemFirstInCallback|ol|ul|has|unlock|html|append|string|UL|class|prototype|isNaN|load|parseInt|children|find|OL|normal|new|swing|10px|0px|lock|loop|round|clearTimeout|1000|setTimeout|isFunction|floor|index|borderBottomWidth|horizontal|jcarouselindex|jQuery|borderLeftWidth|borderTopWidth|borderRightWidth|push|onBeforeAnimation|set|No|jCarousel|items|This|cause|an|infinite|will|alert|none|Aborting|float'.split('|'),0,{}))

/**
 * jQuery - Cookie Plugin
 * Copyright (c) 2006 Klaus Hartl (stilbuero.de)
 */
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('o.5=B(9,b,2){6(h b!=\'E\'){2=2||{};6(b===n){b=\'\';2.3=-1}4 3=\'\';6(2.3&&(h 2.3==\'j\'||2.3.k)){4 7;6(h 2.3==\'j\'){7=w u();7.t(7.q()+(2.3*r*l*l*x))}m{7=2.3}3=\'; 3=\'+7.k()}4 8=2.8?\'; 8=\'+(2.8):\'\';4 a=2.a?\'; a=\'+(2.a):\'\';4 c=2.c?\'; c\':\'\';d.5=[9,\'=\',C(b),3,8,a,c].y(\'\')}m{4 e=n;6(d.5&&d.5!=\'\'){4 g=d.5.A(\';\');s(4 i=0;i<g.f;i++){4 5=o.z(g[i]);6(5.p(0,9.f+1)==(9+\'=\')){e=D(5.p(9.f+1));v}}}F e}};',42,42,'||options|expires|var|cookie|if|date|path|name|domain|value|secure|document|cookieValue|length|cookies|typeof||number|toUTCString|60|else|null|jQuery|substring|getTime|24|for|setTime|Date|break|new|1000|join|trim|split|function|encodeURIComponent|decodeURIComponent|undefined|return'.split('|'),0,{}))

$(function(){
    
    /*jQuery UI Theme Switcher*/
	$('#jtwitter_switcher').themeswitcher();

	/* Show/Hide Status Updater*/
	$('#jtwitter-update-toggle').click(function(){
		$('#jtwitter-update-holder').toggle('blind', 1000);
	});

	/* Show/Hide Left Toolbar*/
	$('#jwtitter-toggle-left').click(function(){
		$('.jtwitter-left').toggle('slow');	
	});
	
	/* Current User/Button Hover class*/
	$('.jtwitter-current-user li, .ui-button').hover(function(){
		$(this).addClass('ui-state-hover');
	}, function(){
		$(this).removeClass('ui-state-hover');
	});
   
    /* Callback for TwitterPod Carousel*/
    function mycarousel_initCallback(carousel){
    	$('#1').bind('click', function(){
    		carousel.scroll(1);
    		return false;
    	});
    	$('#2').bind('click', function(){
    		carousel.scroll(2);
    		return false;
    	});
    	$('#3').bind('click', function(){
    		carousel.scroll(3);
    		return false;
    	});
    	$('#4').bind('click', function(){
    		carousel.scroll(4);
    		return false;
    	});
    	$('#5').bind('click', function(){
    		carousel.scroll(5);
    		return false;
    	});
    	$('#6').bind('click', function(){
    		carousel.scroll(6);
    		return false;
    	});
    	$('#7').bind('click', function(){
    		carousel.scroll(7);
    		return false;
    	});
    };
	/* Twitter-Pod Carousel*/
	$("#jtwitter-carousel").jcarousel({
		scroll: 1,
		vertical: true,
		wrap: 'both',
		start: 9,
		initCallback: mycarousel_initCallback,
		buttonNextHTML: null,
		buttonPrevHTML: null
	});
	
	/* Get Friends Timeline*/
	$('#timeline').bind('click', function(){
		$.jtwitter.getFriendsTimeline(100, 1);
		$.jtwitter.getRateLimit(function(result){
			$('.jtwitter-api-rate span').html(result.hourly_limit)
			$('.jtwitter-api-calls span').html(result.remaining_hits)
		});
	});
	
	/* Get Favorites*/
	$('#favorites').bind('click', function(){
		$.jtwitter.getFavorites(1);
		$.jtwitter.getRateLimit(function(result){
			$('.jtwitter-api-rate span').html(result.hourly_limit)
			$('.jtwitter-api-calls span').html(result.remaining_hits)
		});
	});
	
	/* Get Messages*/
	$('#messages').bind('click', function(){
		$.jtwitter.getMessages(100, 1);
		$.jtwitter.getRateLimit(function(result){
			$('.jtwitter-api-rate span').html(result.hourly_limit)
			$('.jtwitter-api-calls span').html(result.remaining_hits)
		});
	});
	
	/* Get Followers*/
	$('#followers').bind('click', function(){
		$.jtwitter.getFollowers(1);
		$.jtwitter.getRateLimit(function(result){
			$('.jtwitter-api-rate span').html(result.hourly_limit)
			$('.jtwitter-api-calls span').html(result.remaining_hits)
		});
	});
	
	/* Get Replies*/
	$('#replies').bind('click', function(){
		$.jtwitter.getReplies(100, 1);
		$.jtwitter.getRateLimit(function(result){
			$('.jtwitter-api-rate span').html(result.hourly_limit)
			$('.jtwitter-api-calls span').html(result.remaining_hits)
		});
	});
	
	/* Update Status*/
	$('#btn_status_create').bind('click', function(){
		$.jtwitter.postTweet( $('#txt_status_create').val(), function(result){
			//alert('Status Updated');
			$('#txt_status_create').val('');	
		});
	
	});
	
	/* Twitter Login*/
	$('#btn_twitter_login').bind('click', function(){
		$.jtwitter.verifyCredentials($('#txt_twitter_username').val(), $('#txt_twitter_password').val(), function(result){
			if (result != false) {
				$('.jtwitter-left').show('slide', 1000);
				//Build the User Profile
				$('.jtwitter-current-user-image').html('<img src="' + result.profile_image_url + '" alt="' + result.screen_name + '"/>');
				//Latest message
				$('.jtwitter-latest-status span').html(result.status.text);
				$('#jtwitter_profile_name').html(result.name);
				$('#jtwitter_profile_url').html(result.url);
				$('#jtwitter_profile_description').html(result.description);
				$('#jtwitter_profile_location').html(result.location);
				$('#jtwitter_profile_image').attr('src', result.profile_image_url);
				$('#jtwitter_profile_tweets').html(result.statuses_count);
				$('#jtwitter_profile_followers').html(result.followers_count);
				$('#jtwitter_profile_following').html(result.friends_count);
				$('#jtwitter_profile_favorites').html(result.favourites_count);
				
				//Save User Info in cookie
				$.cookie('twitterpodUser', $('#txt_twitter_username').val());
				$.cookie('twitterpodPass', $('#txt_twitter_password').val());
				
			} else {
			    $('#txt_twitter_username').addClass('ui-state-error');
			    $('#txt_twitter_password').addClass('ui-state-error');
			    alert('Im sorry, your username/password was incorrect. Please try again.')
			}
		});
	});
	
    /* Clear the Textarea*/
	$('#txt_status_create').val('');
	
	/* jQuery Twitter API Plugin Options*/
	$("#jtwitter").jtwitter('js/TwitterService.php', {
		defaultTimeline: 'friends',
		autoFetch: false,
		showActions: true,
		tweetarea: '#txt_status_create',
		tweetareaCount: '.jtwitter-count',
		loader: function(bool){
			(bool) ? $('#jtwitter_loader').show() : $('#jtwitter_loader').hide();
		},
		resultLocations: {
			getFollowing: '#jtwitter_following_list',
			getFollowers: '#jtwitter_followers_list',
			getFriendsTimeline: '#jtwitter_timeline_friends_list',
			getUserTimeline: '#jtwitter_timeline_user_list',
			getReplies: '#jtwitter_timeline_replies_list',
			getMessages: '#jtwitter_messages_get_list',
			getFavorites: '#jtwitter_favorites_list'
		}
	});
	
	//Check for cookie and populate
	if ( $.cookie('twitterpodUser') && $.cookie('twitterpodPass') )
	{
        $('#txt_twitter_username').val($.cookie('twitterpodUser'));
        $('#txt_twitter_password').val($.cookie('twitterpodPass'));        
	}
	
	
}); 