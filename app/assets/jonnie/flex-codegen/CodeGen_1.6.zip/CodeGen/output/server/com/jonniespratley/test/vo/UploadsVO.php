<?php/**  * I am a object representing the Uploads table. *  * @version 1.6 * @author Jonnie Spratley (http://jonniespratley.com/code) * * @package com.jonniespratley.test.VO * @name UploadsVO.php */class UploadsVO{	var $_explicitType = 'com.jonniespratley.test.VO.UploadsVO';		
			public $id;
			public $upload_name;
			public $upload_size;
			public $upload_type;
			public $user_id;		public function __construct( $vo )	{		
			$this->id = $vo["id"];
			$this->upload_name = $vo["upload_name"];
			$this->upload_size = $vo["upload_size"];
			$this->upload_type = $vo["upload_type"];
			$this->user_id = $vo["user_id"];	}	}?>                                          