<?php

class ConfigReader
{
	private $host;
	private $user;
	private $pass;
	private $endpoint;
	private $namespace;
	private $database;
	private $application;
	
	public function readConfig( $config )
	{
		$configFile = $config;
		
		$dom = new DOMDocument ( );
		$dom->load ( $configFile );
		
		$configs = $dom->getElementsByTagName ( "config" );
		
		foreach ( $configs as $config )
		{
			$hosts = $config->getElementsByTagName ( "host" );
			$this->setHost ( $hosts->item ( 0 )->nodeValue );
			
			$users = $config->getElementsByTagName ( "user" );
			$this->setUser ( $users->item ( 0 )->nodeValue );
			
			$passes = $config->getElementsByTagName ( "pass" );
			$this->setPass ( $passes->item ( 0 )->nodeValue );
			
			$endpoints = $config->getElementsByTagName ( "endpoint" );
			$this->setEndpoint ( $endpoints->item ( 0 )->nodeValue );
			
			$namespaces = $config->getElementsByTagName ( "namespace" );
			$this->setNamespace ( $namespaces->item ( 0 )->nodeValue );
			
			$databases = $config->getElementsByTagName ( "database" );
			$this->setDatabase( $databases->item ( 0 )->nodeValue );
			
			$applications = $config->getElementsByTagName ( "application" );
			$this->setApplication ( $applications->item ( 0 )->nodeValue );
		
		}
	}
	
	/**
	 * @return unknown
	 */
	public function getHost()
	{
		return $this->host;
	}
	
	/**
	 * @return unknown
	 */
	public function getPass()
	{
		return $this->pass;
	}
	
	/**
	 * @return unknown
	 */
	public function getUser()
	{
		return $this->user;
	}
	
	/**
	 * @return unknown
	 */
	public function getEndpoint()
	{
		return $this->endpoint;
	}
	
	/**
	 * @return unknown
	 */
	public function getNamespace()
	{
		return $this->namespace;
	}
	
	/**
	 * @return unknown
	 */
	public function getDatabase()
	{
		return $this->database;
	}
	
	/**
	 * @param unknown_type $host
	 */
	public function setHost( $host )
	{
		$this->host = $host;
	}
	
	/**
	 * @param unknown_type $pass
	 */
	public function setPass( $pass )
	{
		$this->pass = $pass;
	}
	
	/**
	 * @param unknown_type $user
	 */
	public function setUser( $user )
	{
		$this->user = $user;
	}
	
	/**
	 * @param unknown_type $endpoint
	 */
	public function setEndpoint( $endpoint )
	{
		$this->endpoint = $endpoint;
	}
	
	/**
	 * @param unknown_type $namespace
	 */
	public function setNamespace( $namespace )
	{
		$this->namespace = $namespace;
	}
	
	/**
	 * @param unknown_type $schema
	 */
	public function setDatabase( $database )
	{
		$this->database = $database;
	}
	/**
	 * @return unknown
	 */
	public function getApplication()
	{
		return $this->application;
	}
	
	/**
	 * @param unknown_type $application
	 */
	public function setApplication( $application )
	{
		$this->application = $application;
	}

}

?>