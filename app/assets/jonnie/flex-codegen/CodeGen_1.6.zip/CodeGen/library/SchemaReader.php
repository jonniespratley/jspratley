<?php

include 'Required.php';

class SchemaReader
{
	/**
	 * I read the schema.xml file and generate all of the required items for a CRUD application.
	 *
	 * @param [xml] $schema The location of the xml file.
	 * @return [results]
	 */
	public static function readSchema( $schema, $database )
	{
		
		
		//Read the Config
		$config = new ConfigReader ( );
		$config->readConfig ( TemplateManager::$CONFIG_OUTPUT.'/'.ucfirst( $database ).'Config.xml' );
		
		//write the namespace folders
		//Utilities::makeServerNamespaceFolders ( $namespace );
		//$namespace = Utilities::namespaceFolders ( $config->getNamespace () );
		$namespace = $config->getNamespace ();
		
		$dom = new DOMDocument ( );
		$dom->load ( $schema );
		
		$tables = $dom->getElementsByTagName ( 'table' );
		$tableArray = array ();
		
		//Each table needs one of these files being generated below
		foreach ( $tables as $table )
		{
			if ( $table->hasAttribute ( 'name' ) )
			{
				$tableName = $table->getAttribute ( 'name' );
				$fieldArray = array ();
				
				//For each field inside of the table node
				foreach ( $table->childNodes as $node )
				{
					if ( is_a ( $node, 'DOMElement' ) )
					{
						$field = $node->getAttribute ( 'name' );
						$type = $node->getAttribute ( 'type' );
						$null = $node->getAttribute ( 'required' );
						
						$fieldArray [] = array ( 'name' => $field, 'type' => Utilities::replaceNumbers ( $type ), 'required' => $null );
					}
				}
				
				//Push the into an array of a table and there fields
				$tableArray [ $tableName ] = array ( 'table' => ucfirst ( $tableName ), 'fields' => $fieldArray );
				
				/*
				 * Start looping every table in the schema.xml file and generating each application file for that table.
				 */
				
				
				/* =========================================================================
				 * SERVER SIDE CODE GENERATION
				 * ========================================================================= */
				
				//Server Side DAO/VO
				CGManager::$PHP_DAO_GEN = PHPServiceGen::generate ( $namespace, $config->getDatabase (), $tableName, $fieldArray );
				CGManager::$PHP_VO_GEN = PHPValueObjectGen::generate ( $namespace, $config->getDatabase (), $tableName, $fieldArray );
			
				/* =========================================================================
				 * CLIENT SIDE CAIRNGORM GENERATION
				 * ========================================================================= */
				
				//Get/Save/Remove Events
				CGManager::$CAIRNGORM_GET_EVENT_GEN = CairngormGetEventGen::generate ( $namespace, $config->getDatabase (), $tableName, $fieldArray );
				CGManager::$CAIRNGORM_SAVE_EVENT_GEN = CairngormSaveEventGen::generate ( $namespace, $config->getDatabase (), $tableName, $fieldArray );
				CGManager::$CAIRNGORM_REMOVE_EVENT_GEN = CairngormRemoveEventGen::generate ( $namespace, $config->getDatabase (), $tableName, $fieldArray );
				
				//Get/Save/Remove Commands
				CGManager::$CAIRNGORM_GET_COMMAND_GEN = CairngormGetCommandGen::generate ( $namespace, $config->getDatabase (), $tableName, $fieldArray );
				CGManager::$CAIRNGORM_SAVE_COMMAND_GEN = CairngormSaveCommandGen::generate ( $namespace, $config->getDatabase (), $tableName, $fieldArray );
				CGManager::$CAIRNGORM_REMOVE_COMMAND_GEN = CairngormRemoveCommandGen::generate ( $namespace, $config->getDatabase (), $tableName, $fieldArray );
								
				//Service Delegate				
				CGManager::$CAIRNGORM_SERVICE_DELEGATE_GEN = CairngormServiceDelegateGen::generate ( $namespace, $config->getDatabase (), $tableName, $fieldArray );
				
				//Value Object
				CGManager::$CAIRNGORM_VO_GEN = CairngormValueObjectGen::generate ( $namespace, $config->getDatabase (), $tableName, $fieldArray );
				
				/* =========================================================================
				 * CLIENT SIDE FLEX GENERATION
				 * ========================================================================= */
				
				//Flex List Component
				CGManager::$FLEX_LIST_GEN = FlexListGen::generate( $namespace, $config->getDatabase (), $tableName, $fieldArray );
				
				//Flex Form Component
				CGManager::$FLEX_FORM_GEN = FlexFormGen::generate( $namespace, $config->getDatabase (), $tableName, $fieldArray );
				
				//Flex Main Component 
				CGManager::$FLEX_MAIN_GEN = FlexMainGen::generate ( $namespace, $config->getDatabase (), $tableName, $fieldArray );
				
			}
			//sort ( $tableArray );
		}
		
		/* =========================================================================
		 * 
		 * Since there is one per database of these, we are going to generate 
		 *
		 * 1 Service.mxml 
		 * 1 Application.mxml
		 * 1 Controller.as
		 * 1 ModelLocator.as
		 * 1 Project Properties for Flex builder (@todo:)
		 * 1 Connection.php
		 * 1 FlexRemotingService.as (@todo:)
		 * 1 RESTService.php
		 * ========================================================================= */
		
		/* =========================================================================
		 * SERVER SIDE PHP GENERATION
		 * ========================================================================= */
		
		//Write the RESTService.php file
		CGManager::$PHP_REST_GEN = PHPRESTServiceGen::generate( $namespace, $config->getDatabase(), $tableArray, $fieldArray );
		
		//Write the Connection.php file
		CGManager::$PHP_CONN_GEN = ConnectionWriter::writeConnection($database);
		/* =========================================================================
		 * CLIENT SIDE CAIRNGORM GENERATION
		 * ========================================================================= */
		
		//Write the Services.mxml file
		CGManager::$CAIRNGORM_SERVICE_LOCATOR_GEN = CairngormServiceLocatorGen::generate ( $namespace, $config->getDatabase (), $tableArray, $fieldArray );
		
		//Write the ModelLocator.as file
		CGManager::$CAIRNGORM_MODEL_GEN = CairngormModelGen::generate ( $namespace, $config->getDatabase (), $tableArray, $fieldArray );
		
		//Write the FrontController.as file
		CGManager::$CAIRNGORM_CONTROLLER_GEN = CairngormControllerGen::generate ( $namespace, $config->getDatabase (), $tableArray, $fieldArray );
		
		/* =========================================================================
		 * CLIENT SIDE FLEX GENERATION
		 * ========================================================================= */

		//Write the main application
		CGManager::$FLEX_APP_GEN = FlexApplicationGen::generate ( $namespace, $config->getDatabase(), $tableArray, $fieldArray );
		
		//Write the FlexREST Service Class ( if selected )
		CGManager::$FLEX_REST_SERVICE_GEN = FlexRESTServiceGen::generate( $namespace, $config->getDatabase(), $tableArray, $fieldArray );
		
		//Write the project properites 
		//(@todo): Write the eclipse project properties files
	$appMessage = '
	Application written. 
	<li>a. All php service files for all database tables</li>
 	<li>b. All php value object files for all database tables</li>
 	<li>c. All flex value object files for all database tables</li>
 	<li>d. All flex table testers that have a datagrid and form, with all services calls.</li>
 	<li>e. All config files, connection files, and namespace folders.</li>
	<li>Just drop inside the services folder of your amfphp installation, and your ready to roll.</li>
 	<li>Server side gets generated into the output/server folder.</li>
 	<li>Client side get generated into the output/client folder.</li>';
		return $appMessage; 
		
	}
}

?>