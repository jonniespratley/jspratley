<?php

include 'Required.php';

class CairngormSaveEventGen implements IGenerate
{ 
	
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		//upper case the table name
		$table = ucfirst ( $table );
		
		//Create the fileame
		$filename = 'Save' . $table . 'Event.as';
		
		//make the folder namespace
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		$namespace = Utilities::namespaceApplication ( $namespace );
		
		$tableService = FileSystemService::readFile ( TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'SaveEvent.txt' );
		
		//replace the table name inside of the template
		$template = preg_replace ( TemplateManager::$TABLE_PATTERN, $table, $tableService );
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $template );
		$template = preg_replace ( TemplateManager::$EVENT_CONST, strtoupper ( $table ), $template );
		
		Utilities::checkOrMakeFolders ( TemplateManager::$CLIENT_OUTPUT, $folderNamespace, 'events' );
		FileSystemService::writeFile ( TemplateManager::$CLIENT_OUTPUT . $folderNamespace . '/events/' . $filename, $template );
		
		return 'Generated Cairngorm Event for ' . $table;
	}
}

?>