<?php/**                    My Test Application
                *//**  * I am a object representing the @TABLE table. *  * @version CodeGen - 1.8 * @author CodeGen - Jonnie Spratley (http://jonniespratley.com/code) * * @package com.domain.project.VO * @name Locations_tagsVO.php */class Locations_tagsVO{	/* Official boycott on amphp, because its trash */	//public $_explicitType = 'com.domain.project.vo.Locations_tagsVO';		
			public $id;
			public $location_id;
			public $tag_id;		public function __construct(){}		public function mapObject( $vo )	{		
			$this->id = $vo["id"];
			$this->location_id = $vo["location_id"];
			$this->tag_id = $vo["tag_id"];	}		public function setNamespace( $namespace )	{		$this->explicitType = $namespace;	}		public function __get( $name )	{		return $this->$name;	}		public function __set( $name, $value )	{		$this->$name = $value;	}	}?>                                          