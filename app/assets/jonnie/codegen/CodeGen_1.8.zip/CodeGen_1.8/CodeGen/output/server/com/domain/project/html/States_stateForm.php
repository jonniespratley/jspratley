<?php 
require_once '../States_stateService.php';
require_once '../vo/States_stateVO.php';


			$id_state = "";
			$name_state = "";
$id = '';

if ( $_GET['id'] )
{
	$id = $_GET['id'];
	$service = new States_stateService();
	$recordVO = new States_stateVO();
	$record = $service->getOneStates_state( $id ); 
	$recordVO = $record[0];//First object in array
	
	
			$id_state = $recordVO->id_state;
			$name_state = $recordVO->name_state;
	
	
}
?>
<?php include '_header.php'; ?>
<form id="formStates_state" name="formStates_state" method="post" action="States_stateList.php">
	 
	
	
			<div>
		 		<label for="id_state">Id_state</label>
		 		<input type="text" name="id_state" value="<?php echo $id_state; ?>"/>
		 	</div>
			<div>
		 		<label for="name_state">Name_state</label>
		 		<input type="text" name="name_state" value="<?php echo $name_state; ?>"/>
		 	</div>
    
    <div>
    	<input type="hidden" name="id" value="<?php echo $id; ?>"/>
	   <input name="save" type="submit" value="Save" />
		<button onclick="window.location='States_stateList.php'">Back</button>
    </div>
</form>
 <?php include '_footer.php'; ?>