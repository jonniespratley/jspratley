<?php

include 'Required.php';

class PHPValueObjectGen implements IGenerate
{
	
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		$table = ucfirst ( $table );
		$filename = ucfirst ( $table ) . 'VO.php';
	
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		$namespace = Utilities::namespaceApplication ( $namespace );
		
		$fieldVars = '';
		$fieldsCon = '';
		
		foreach ( $fields as $field )
		{
			$fieldVars .= '
			public $' . $field [ 'name' ] . ';';
			
			$fieldsCon .= '
			$this->' . $field [ 'name' ] . ' = $vo["' . $field [ 'name' ] . '"];';
		}
			
		$tableService = FileSystemService::readFile ( TemplateManager::$PHP_TEMPLATE_LOCATION.'vo.txt' );
	
		$template = preg_replace ( TemplateManager::$TABLE_PATTERN, $table, $tableService );
		$template = preg_replace ( TemplateManager::$FIELD_VARS_PATTERN, $fieldVars, $template );
		$template = preg_replace ( TemplateManager::$FIELDS_PATTERN, $fieldsCon, $template );
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $template );
		$template = preg_replace ( TemplateManager::$CG_VERSION_PATTERN, CGManager::$CG_VERSION, $template );
		$template = preg_replace ( TemplateManager::$CG_AUTHOR_PATTERN, CGManager::$CG_AUTHOR, $template );
		
		Utilities::checkOrMakeFolders ( TemplateManager::$SERVER_OUTPUT, $folderNamespace, 'vo' );
		FileSystemService::writeFile ( TemplateManager::$SERVER_OUTPUT . $folderNamespace . '/vo/' . $filename, $template );
		
		return 'Generated PHP Value Object for ' . $table;
	}
}

?>