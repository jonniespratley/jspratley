<?php

include 'Required.php';

class FlexFormGen implements IGenerate
{
	
	/*
	 * <mx:FormItem label="Category_id" required="true">
		<mx:TextInput id="txt_category_id"
			editable="false"
			text="{ selectedRecord.category_id }"/>
		</mx:FormItem>
	 * 
	 */
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		$table = ucfirst ( $table );
		
		//make the folder namespace com/jonnie/test/
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		
		//make the actual namespace com.jonnie.test
		$namespace = Utilities::namespaceApplication ( $namespace );
				
		//Flex Form
		$formFields = '';
		$setFields = '';
		$clearFields = '';
		$validatorFields = '';
		$validatorInitFields = '';
		
		
		foreach ( $fields as $field )
		{
			/*
			 * Build the form inputs - 
			 * <mx:FormItem label="Category_id" required="true" width="100%">
			 *		<mx:TextInput id="txt_category_id" text="{ model.selectedCategories.category_id }" width="100%"/>
			 *	</mx:FormItem>
			 */
			$formFields .= '
				<mx:FormItem label="' . ucfirst ( $field [ 'name' ] ) . '" required="' . $field [ 'required' ] . '" width="100%">
					<mx:TextInput id="txt_' . $field [ 'name' ] . '" text="{ model.selected' . $table . '.' . $field [ 'name' ] . ' }" width="100%"/>
				</mx:FormItem>';
			
			
			/* Set the field values - vo.category_name = txt_category_name.text; */
			$setFields .= '
			vo.' . $field [ 'name' ] . ' = txt_' . $field [ 'name' ] . '.text;';
			

			/*Clear the field values - txt_category_name.text = ""; */
			$clearFields .= '
			txt_' . $field [ 'name' ] . '.text = "";
			txt_' . $field [ 'name' ] . '.errorString = "";
			';
			
			if ( $field [ 'required' ] == 'true' )
			{
				/* Set up the validators inside of the init - validators = [ @INITVALIDATORS ]; */
				$validatorInitFields .= '' . $field [ 'name' ] . 'V, ';
				
				/* Set up the validators in the main component - <mx:StringValidator id="cateogoryNameV" source="{ txt_category_name }" required="true" property="text"/> */
				$validatorFields .= '
				<mx:StringValidator id="' . $field [ 'name' ] . 'V" source="{ txt_' . $field [ 'name' ] . ' }" required="true" property="text"/>';
			}
		}
		
		
		$validatorInitFields = Utilities::trimSQL ( $validatorInitFields );
		
		/* Read the template, and prepare to search and replace the template */
		$flexForm = FileSystemService::readFile ( TemplateManager::$FLEX_TEMPLATE_LOCATION.'FlexForm.txt' );
		
		/* Set and replace the table name */
		$template = preg_replace ( TemplateManager::$TABLE_PATTERN, $table, $flexForm );
		
		/* Set and replace the form fields */
		$template = preg_replace ( TemplateManager::$FORM_FIELDS_PATTERN, $formFields, $template );
		
		/* Set and replace the namespaces */
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $template );
		
		/* Set and replace the clearing of the form field values */
		$template = preg_replace ( TemplateManager::$CLEAR_FIELDS_PATTERN, $clearFields, $template );
		
		/* Set and replace the values on the new object for insertion */
		$template = preg_replace ( TemplateManager::$SET_FIELDS_PATTERN, $setFields, $template );
		
		/* Set and replace the form init validators array */
		$template = preg_replace ( TemplateManager::$INIT_VALIDATORS_PATTERN, $validatorInitFields, $template );
		
		/* Set and replace the validator fields at the bottom of the template */
		$template = preg_replace ( TemplateManager::$VALIDATORS_PATTERN, $validatorFields, $template );
		
		Utilities::checkOrMakeFolders ( TemplateManager::$CLIENT_OUTPUT, $folderNamespace, 'view/'.$table.'/' );
		FileSystemService::writeFile ( TemplateManager::$CLIENT_OUTPUT . $folderNamespace . '/view/'.$table.'/' .  $table . 'Form.mxml', $template );
	
		return 'Generated Flex Form for ' . $table;
	}

}

?>