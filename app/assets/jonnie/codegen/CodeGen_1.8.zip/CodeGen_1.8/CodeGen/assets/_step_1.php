<div title="Step 1" class="panel">
    <div class="wrapper">
        <h2>1. Database Information</h2>
        <form id="form_config" name="form_config" method="" action="">
           
            <div>
                <label class="description" for="txt_host">
                    Database Host:
                </label>
                <input name="txt_host" type="text" id="txt_host" value="localhost" />
            </div>
            <div>
                <label class="description" for="txt_user">
                    Database Username: 
                </label>
                <input name="txt_user" type="text" id="txt_user" value="root" />
            </div>
            <div>
                <label class="description" for="txt_pass">
                    Database Password: 
                </label>
                <input name="txt_pass" type="password" id="txt_pass" value="fred" />
            </div>
            <div>
                <label class="description" for="txt_database">
                    Database Name:
                </label>
                <input name="txt_database" type="text"id="txt_database" value="test" />
            </div>
        </form>
        <div class="paging">
            <a class="cross-link" href="#5">Prev</a>
            <a class="cross-link" href="#2">Next</a>
        </div>
    </div>
</div>
