<div title="Step 2" class="panel">
    <div class="wrapper">
        <h2>2. Application Information</h2>
        <form id="form_config" method="" onsubmit="return;" action="">
            
            <div>
                <label class="description" for="txt_application">
                    Application Name: 
                </label>
                <input name="txt_application" type="text" id="txt_application" value="CodeGenTest" />
            </div>
            <div>
                <label class="description" for="txt_namespace">
                    Application Namespace: 
                </label>
                <input name="txt_namespace" type="text" id="txt_namespace" value="com.domain.project" />
            </div>
            <div>
                <label class="description" for="txt_endpoint">
                    Location of Services: 
                </label>
                <input name="txt_endpoint" type="text" id="txt_endpoint" value="http://localhost/project/services" />
            </div>
            <div>
                <label class="description" for="txt_framework">
                    Code Framework 
                </label>
                <select id="txt_framework" name="txt_framework">
                    <option value="Cairngorm">Cairngorm Framework</option>
                    <option value="AS3">General Flex HTTPService/AS3</option>
                </select>
            </div>
            <div>
                <label class="description" for="txt_copywrite">
                    Copywrite:
                </label>
                <textarea id="txt_copywrite" name="txt_copywrite">
                    My Test Application
                </textarea>
            </div>
            <div>
                <input type="button" name="btn_generateConfig" id="btn_generateConfig" value="Create Configuration"/>
            </div>
        </form>
        <div class="paging">
            <a class="cross-link" href="#1">Prev</a>
            <a class="cross-link" href="#3">Next</a>
        </div>
    </div>
</div>
