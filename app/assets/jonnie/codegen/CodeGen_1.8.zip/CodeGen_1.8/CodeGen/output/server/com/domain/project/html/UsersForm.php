<?php 
require_once '../UsersService.php';
require_once '../vo/UsersVO.php';


			$branch_id = "";
			$comp_id = "";
			$user_address = "";
			$user_cell = "";
			$user_dob = "";
			$user_docid = "";
			$user_email = "";
			$user_empid = "";
			$user_fname = "";
			$user_id = "";
			$user_idtype = "";
			$user_lname = "";
			$user_logindate = "";
			$user_password = "";
			$user_securityrole = "";
			$user_telh = "";
			$user_telw = "";
$id = '';

if ( $_GET['user_id'] )
{
	$id = $_GET['user_id'];
	$service = new UsersService();
	$recordVO = new UsersVO();
	$record = $service->getOneUsers( $id ); 
	$recordVO = $record[0];//First object in array
	
	
			$branch_id = $recordVO->branch_id;
			$comp_id = $recordVO->comp_id;
			$user_address = $recordVO->user_address;
			$user_cell = $recordVO->user_cell;
			$user_dob = $recordVO->user_dob;
			$user_docid = $recordVO->user_docid;
			$user_email = $recordVO->user_email;
			$user_empid = $recordVO->user_empid;
			$user_fname = $recordVO->user_fname;
			$user_id = $recordVO->user_id;
			$user_idtype = $recordVO->user_idtype;
			$user_lname = $recordVO->user_lname;
			$user_logindate = $recordVO->user_logindate;
			$user_password = $recordVO->user_password;
			$user_securityrole = $recordVO->user_securityrole;
			$user_telh = $recordVO->user_telh;
			$user_telw = $recordVO->user_telw;
	
	
}
?>
<?php include '_header.php'; ?>
<form id="formUsers" name="formUsers" method="post" action="UsersList.php">
	 
	
	
			<div>
		 		<label for="branch_id">Branch_id</label>
		 		<input type="text" name="branch_id" value="<?php echo $branch_id; ?>"/>
		 	</div>
			<div>
		 		<label for="comp_id">Comp_id</label>
		 		<input type="text" name="comp_id" value="<?php echo $comp_id; ?>"/>
		 	</div>
			<div>
		 		<label for="user_address">User_address</label>
		 		<input type="text" name="user_address" value="<?php echo $user_address; ?>"/>
		 	</div>
			<div>
		 		<label for="user_cell">User_cell</label>
		 		<input type="text" name="user_cell" value="<?php echo $user_cell; ?>"/>
		 	</div>
			<div>
		 		<label for="user_dob">User_dob</label>
		 		<input type="text" name="user_dob" value="<?php echo $user_dob; ?>"/>
		 	</div>
			<div>
		 		<label for="user_docid">User_docid</label>
		 		<input type="text" name="user_docid" value="<?php echo $user_docid; ?>"/>
		 	</div>
			<div>
		 		<label for="user_email">User_email</label>
		 		<input type="text" name="user_email" value="<?php echo $user_email; ?>"/>
		 	</div>
			<div>
		 		<label for="user_empid">User_empid</label>
		 		<input type="text" name="user_empid" value="<?php echo $user_empid; ?>"/>
		 	</div>
			<div>
		 		<label for="user_fname">User_fname</label>
		 		<input type="text" name="user_fname" value="<?php echo $user_fname; ?>"/>
		 	</div>
			<div>
		 		<label for="user_id">User_id</label>
		 		<input type="text" name="user_id" value="<?php echo $user_id; ?>"/>
		 	</div>
			<div>
		 		<label for="user_idtype">User_idtype</label>
		 		<input type="text" name="user_idtype" value="<?php echo $user_idtype; ?>"/>
		 	</div>
			<div>
		 		<label for="user_lname">User_lname</label>
		 		<input type="text" name="user_lname" value="<?php echo $user_lname; ?>"/>
		 	</div>
			<div>
		 		<label for="user_logindate">User_logindate</label>
		 		<input type="text" name="user_logindate" value="<?php echo $user_logindate; ?>"/>
		 	</div>
			<div>
		 		<label for="user_password">User_password</label>
		 		<input type="text" name="user_password" value="<?php echo $user_password; ?>"/>
		 	</div>
			<div>
		 		<label for="user_securityrole">User_securityrole</label>
		 		<input type="text" name="user_securityrole" value="<?php echo $user_securityrole; ?>"/>
		 	</div>
			<div>
		 		<label for="user_telh">User_telh</label>
		 		<input type="text" name="user_telh" value="<?php echo $user_telh; ?>"/>
		 	</div>
			<div>
		 		<label for="user_telw">User_telw</label>
		 		<input type="text" name="user_telw" value="<?php echo $user_telw; ?>"/>
		 	</div>
    
    <div>
    	<input type="hidden" name="user_id" value="<?php echo $id; ?>"/>
	   <input name="save" type="submit" value="Save" />
		<button onclick="window.location='UsersList.php'">Back</button>
    </div>
</form>
 <?php include '_footer.php'; ?>