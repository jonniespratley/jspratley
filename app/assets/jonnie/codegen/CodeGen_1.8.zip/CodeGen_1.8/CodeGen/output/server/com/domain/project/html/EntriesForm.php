<?php 
require_once '../EntriesService.php';
require_once '../vo/EntriesVO.php';


			$entry_body = "";
			$entry_created = "";
			$entry_title = "";
			$id = "";
			$location_id = "";
			$upload_id = "";
			$user_id = "";
$id = '';

if ( $_GET['id'] )
{
	$id = $_GET['id'];
	$service = new EntriesService();
	$recordVO = new EntriesVO();
	$record = $service->getOneEntries( $id ); 
	$recordVO = $record[0];//First object in array
	
	
			$entry_body = $recordVO->entry_body;
			$entry_created = $recordVO->entry_created;
			$entry_title = $recordVO->entry_title;
			$id = $recordVO->id;
			$location_id = $recordVO->location_id;
			$upload_id = $recordVO->upload_id;
			$user_id = $recordVO->user_id;
	
	
}
?>
<?php include '_header.php'; ?>
<form id="formEntries" name="formEntries" method="post" action="EntriesList.php">
	 
	
	
			<div>
		 		<label for="entry_body">Entry_body</label>
		 		<input type="text" name="entry_body" value="<?php echo $entry_body; ?>"/>
		 	</div>
			<div>
		 		<label for="entry_created">Entry_created</label>
		 		<input type="text" name="entry_created" value="<?php echo $entry_created; ?>"/>
		 	</div>
			<div>
		 		<label for="entry_title">Entry_title</label>
		 		<input type="text" name="entry_title" value="<?php echo $entry_title; ?>"/>
		 	</div>
			<div>
		 		<label for="id">Id</label>
		 		<input type="text" name="id" value="<?php echo $id; ?>"/>
		 	</div>
			<div>
		 		<label for="location_id">Location_id</label>
		 		<input type="text" name="location_id" value="<?php echo $location_id; ?>"/>
		 	</div>
			<div>
		 		<label for="upload_id">Upload_id</label>
		 		<input type="text" name="upload_id" value="<?php echo $upload_id; ?>"/>
		 	</div>
			<div>
		 		<label for="user_id">User_id</label>
		 		<input type="text" name="user_id" value="<?php echo $user_id; ?>"/>
		 	</div>
    
    <div>
    	<input type="hidden" name="id" value="<?php echo $id; ?>"/>
	   <input name="save" type="submit" value="Save" />
		<button onclick="window.location='EntriesList.php'">Back</button>
    </div>
</form>
 <?php include '_footer.php'; ?>