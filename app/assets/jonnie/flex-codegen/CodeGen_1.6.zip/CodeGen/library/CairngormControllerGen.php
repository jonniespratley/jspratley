<?php

include 'Required.php';

class CairngormControllerGen implements IGenerate
{
	
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		$config = new ConfigReader ( );
		$config->readConfig ( TemplateManager::$CONFIG_OUTPUT.'/'.ucfirst($database ).'Config.xml' );
		$application = $config->getApplication ();
		$eventsToCommands = '';
		
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		$namespace = Utilities::namespaceApplication ( $namespace );
		
		foreach ( $table as $tbl )
		{
			$eventsToCommands .= '
			this.addCommand( Get' . $tbl [ "table" ] . 'Event.GET_' . strtoupper ( $tbl [ "table" ] ) . '_EVENT, Get' . $tbl [ "table" ] . 'Command );
			this.addCommand( Remove' . $tbl [ "table" ] . 'Event.REMOVE_' . strtoupper ( $tbl [ "table" ] ) . '_EVENT, Remove' . $tbl [ "table" ] . 'Command );
			this.addCommand( Save' . $tbl [ "table" ] . 'Event.SAVE_' . strtoupper ( $tbl [ "table" ] ) . '_EVENT, Save' . $tbl [ "table" ] . 'Command );
			';
		}
		
		$tableService = FileSystemService::readFile ( TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'Controller.txt' );
		
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $tableService );
		$template = preg_replace ( TemplateManager::$APPLICATION_PATTERN, $application, $template );
		$template = preg_replace ( TemplateManager::$EVENT_COMMAND_PATTERN, $eventsToCommands, $template );
		
		$filename = ucfirst ( $application ) . 'Controller.as';
		
		Utilities::checkOrMakeFolders ( TemplateManager::$CLIENT_OUTPUT, $folderNamespace, 'control' );
		FileSystemService::writeFile ( TemplateManager::$CLIENT_OUTPUT . $folderNamespace . '/control/' . $filename, $template );
		
		return 'Generated Cairngorm Controller for ' . $application;
	}
}

?>