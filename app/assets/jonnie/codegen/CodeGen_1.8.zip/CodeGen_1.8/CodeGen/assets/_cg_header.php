<?php 
require_once 'library/CGManager.php';
require_once 'library/ConfigManager.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>CodeGen V. <?php echo CGManager::$CG_VERSION ?></title>

<link rel="stylesheet" type="text/css" href="assets/css/CodeGen.css" media="all"/>
<script type="text/javascript" src="assets/js/view.js"></script>
<script src="assets/js/jquery-1.2.1.pack.js" type="text/javascript"></script>
<script src="assets/js/jquery-easing.1.2.pack.js" type="text/javascript"></script>
<script src="assets/js/jquery-easing-compatibility.1.2.pack.js" type="text/javascript"></script>
<script src="assets/js/coda-slider.1.1.1.pack.js" type="text/javascript"></script>
 

<script type="text/javascript">
	 
$(document).ready(function() 
{ 
	
	$("div#slider1").codaSlider();
	var service = "library/FlexService.php";
	var cg_host;//Host
	var cg_user;//Username
	var cg_pass;//Password
	var cg_database;//Database
	var cg_app;//Application
	var cg_namespace;//Namespace
	var cg_endpoint;//Endpoint
	var cg_framework;//Framework
	var cg_copywrite;//Copywrite
	var cg_config;//Config
	var cg_schema;//Schema
		
/* ======================================================================
 *  						Config Form
 * ====================================================================== */
	$("#btn_generateConfig").click(function()
	{	
		//Step 1
		cg_host = $("#txt_host").val();
		cg_user = $("#txt_user").val();
		cg_pass = $("#txt_pass").val();
		cg_database = $("#txt_database").val();
		
		//Step 2
		cg_app = $("#txt_application").val();
		cg_namespace = $("#txt_namespace").val();
		cg_endpoint = $("#txt_endpoint").val();
		cg_framework = $("#txt_framework").val();
		cg_copywrite = $("#txt_copywrite").val();
		
		//Send the call
		$.get( service,
		{ 
			m: 'generateConfig', //Mode
			h: cg_host, 
			u: cg_user, 
			p: cg_pass, 
			d: cg_database, 
			a: cg_app, 
			n: cg_namespace, 
			e: cg_endpoint, 
			f: cg_framework, 
			c: cg_copywrite
			}, function( result )
			{
				//Trim up all of the whitespace and escaped quotes
				result = $.trim( result ).replace(  /[\\]*[\\"]/g, '' );
				
				//Display the results in the message div
				$("#message").html( result ).fadeIn("slow", function()
				{
				//Set the config location to the result
				cg_config = result;
				
				//Set the text value to the result
				$("#configLocation").html( result );
				$("#txt_configLocation").val( result );
				
				
			});//ends result
		});//ends .get
	});//ends function
	
	
	
/* ======================================================================
 *  						Schema Form
 * ====================================================================== */
	$("#btn_generateSchema").click( function() 
	{
		//alert( cg_config );
		$.get( service, 
		{ 
			m: "generateSchema", 
			c: cg_config, 
			d: cg_database 
			}, function( result )
			{
				//Trim up all of the whitespace and escaped quotes
				result = $.trim( result ).replace(  /[\\]*[\\"]/g, '' );
				
				//Display the results in the message div
				$("#message").html( result ).fadeIn("slow", function()
				{	
					//Set the schema location to the result
					cg_schema = result;
					
					//Set the text value to the result				
					$("#schemaLocation").html( result );
					$("#txt_schemaLocation").val( result );
					
				});//ends result
		});//ends .get
	});//ends function
	
/* ======================================================================
 *  						Application Form
 * ====================================================================== */
	$("#btn_generateApp").click( function() 
	{
		cg_config = $("#txt_configLocation").val();
		cg_database = $("#txt_database").val();
		
		//alert( cg_config );
		$.get( service, 
		{ 
			m: "generateApplication",  
			d: cg_database,
			s: cg_schema
			}, function( result )
			{
				//Trim up all of the whitespace and escaped quotes
				result = $.trim( result ).replace(  /[\\]*[\\"]/g, '' );
				
				//Display the results in the message div
				$("#div_dump").html( result ).fadeIn("slow", function()
				{	
					//Set the schema location to the result
					//cg_schema = result;
					
					//Set the text value to the result				
					//$("#message").html( "<p>" + result + "<p>" );
					
				});//ends result
		});//ends .get

		getDemoURL();
				
	});//ends function

	function getDemoURL()
	{
		$.get( service, 
		{ 
			m: 'getHTMLDemo' 
		},function( result ){
			alert( result );
			
			result = $.trim( result ).replace(  /[\\]*[\\"]/g, '' );
			$("#iframe_preview").attr( "src", result );
		});
	}

	

});//ends dom
</script>

</head>
<body>
<div id="container">

<div id="header">
<h1><a href="http://jonniespratley.com">CodeGen: v. <?php echo CGManager::$CG_VERSION ?> the rapid php &amp; flex generator</a></h1>
</div><!--ends #-->

<div id="content">
<div id="message" class="success" style="display:none;"></div><!--ends #-->
<div class="slider-wrap">
<div id="slider1">
<div class="panelContainer" style="width: 3500px; left: 0px;">