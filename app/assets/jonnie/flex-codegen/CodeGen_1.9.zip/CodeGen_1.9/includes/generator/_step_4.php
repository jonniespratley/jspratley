<div id="step4" class="box round" style="display:none;">	
	<h3>Application Files</h3>
	<p>Here is all of the files that we generated</p>

	<table>
		<tr>
			<td  align="left" valign="top" id="editorSidebar" scope="col" width="20%">
				<ul id="outputFileTree"></ul>
			</td>
			<td  align="left" valign="top" id="editorSource" scope="col" width="80%">
				<code id="outputCode" class="html"></code>
			</td>
		</tr>
		<tr>
			<td scope="col">&nbsp;</td>
			<td id="editorToolbar" scope="col">
					<button class="submit" type="button" id="btn_saveSettings">Save Application</button>
			</td>
		</tr>
	</table>
	
</div>