<?php
/**
 * @name  	Connection.php
 * @author  Jonnie Spratley
 * @version 1.9
 */

class Connection
{
	private $link = null;
	
	/**
	 * I create a new connection to a database
	 * @return [link] a link to the connection
	 */
	public function __construct()
	{}
	
	public function getLink()
	{
		return $this->link;
	}
	
	public function connect($host, $user, $pass){
		
		$mysqli = new mysqli ( $host, $user, $pass );
		$this->setLink($mysqli);
		return $mysqli;
	}
	
	public function setLink( $link )
	{
		$this->link = $link;
	}
	
	/**
	 * I execute a query on the database
	 *
	 * @param [string] $query
	 * @return [result] the result
	 */
	public function execute( $query )
	{
		return $this->link->query ( $query );
	}
	
	/**
	 * I execute a query and return an array of the results.
	 *
	 * @param [string] $sql - the sql
	 * @return [array] the results
	 */
	public function executeAndReturn( $sql )
	{
		$query = $this->link->query ( $sql );
		$array = array ();
		while ( $row = mysqli_fetch_assoc ( $query ) )
		{
			$array [] = $row;
		}
		return $array;
	}
	
	static public function escape( $value )
	{
		$escaped = $value;
		
		if ( ! is_numeric ( $value ) )
		{
			$escaped = '"' . ( $value ) . '"';
		}
		
		return $escaped;
	}
	
	static public function trimSQL( $sql )
	{
		return substr ( $sql, 0, strlen ( $sql ) - 2 );
	}

}
?>