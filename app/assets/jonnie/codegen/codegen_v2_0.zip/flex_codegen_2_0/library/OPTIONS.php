<?php
$postsFields = array(
	array('name' => 'id', 'type' => 'int', 'alias' => 'postId'),
	array('name' => 'title', 'type' => 'string', 'alias' => 'postTitle'),
	array('name' => 'body', 'type' => 'string', 'alias' => 'postBody'),
	array('name' => 'users_id', 'type' => 'int', 'alias' => null),
	array('name' => 'categorys_id', 'type' => 'int', 'alias' => null),
	array('name' => 'tags_id', 'type' => 'int', 'alias' => null),
	array('name' => 'created', 'type' => 'datetime', 'alias' => 'postCreated')
);
$categorysFields = array(
	array('name' => 'id', 'type' => 'int', 'alias' => null),
	array('name' => 'category', 'type' => 'string', 'alias' => null),
	array('name' => 'users_id', 'type' => 'int', 'alias' => null)
);
$usersFields = array(
	array('name' => 'id', 'type' => 'int', 'alias' => null),
	array('name' => 'name', 'type' => 'string', 'alias' => null),
	array('name' => 'email', 'type' => 'string', 'alias' => null),
	array('name' => 'created', 'type' => 'datetime', 'alias' => null)
);
$tagsFields = array(
	array('name' => 'id', 'type' => 'int', 'alias' => null),
	array('name' => 'tag', 'type' => 'string', 'alias' => null),
	array('name' => 'user_id', 'type' => 'int', 'alias' => null)
	
);
 


$opts = array(
	'host' => 'localhost',
	'user' => 'root',
	'pass' => 'fred',
	'database' => 'demo',
	'application' => 'DemoApplication',
	'namespace' => 'com.demo.app',
	'path' => 'output/DemoApplication',
	'endpoint' => 'services/',
	'framework' => 'AS3',
	'tables' => array(
		array(
			'name' => 'posts',
			'fields' => $postsFields
		),
		array(
			'name' => 'users',
			'fields' => $usersFields
		),
		array(
			'name' => 'categorys',
			'fields' => $categorysFields
		),
		array(
			'name' => 'tags',
			'fields' => $tagsFields
		)
	),
	'copywrite' => 'This is a demo application copywrite, hopefully you will understand how this is all going to work. :)'
	
);
    #define('OPTIONS', $opts);
?>