<?php/**  * I am a object representing the Tags table. *  * @version 1.6 * @author Jonnie Spratley (http://jonniespratley.com/code) * * @package com.jonniespratley.test.VO * @name TagsVO.php */class TagsVO{	var $_explicitType = 'com.jonniespratley.test.VO.TagsVO';		
			public $id;
			public $tag_title;
			public $user_id;		public function __construct( $vo )	{		
			$this->id = $vo["id"];
			$this->tag_title = $vo["tag_title"];
			$this->user_id = $vo["user_id"];	}	}?>                                          