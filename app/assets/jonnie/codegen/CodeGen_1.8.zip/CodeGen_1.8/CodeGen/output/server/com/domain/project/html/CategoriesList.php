<?php 
require_once '../CategoriesService.php';
require_once '../vo/CategoriesVO.php';

$service = new CategoriesService();
$result = '';
$recordList = '';

if ( isset($_POST['save']) )
{
	unset( $_POST['save'] );
	$recordValues = $_POST;
	$result = $service->saveCategories( $recordValues );	
}

$recordsArray = $service->getAllCategories();
$recordVO = new CategoriesVO();

for ( $i = 0; $i < count( $recordsArray ); $i++ ) 
{
	$recordVO = $recordsArray[ $i ];
	
	$recordList .= '<tr id="'.$recordVO->category_id.'">';

	
			$recordList .= "<td>$recordVO->category_id</td>";
			$recordList .= "<td>$recordVO->category_name</td>";

	$recordList .= '<td class="actions">';
	$recordList .= '<button class="edit" onclick="window.location=\'CategoriesForm.php?id='.$recordVO->category_id.'\'">Edit</button>';
	$recordList .= '<button class="delete" onclick=" remove('.$recordVO->category_id.')">Delete</button></td>';
	$recordList .= '</tr>';
}

?>
<?php include '_header.php'; ?> 

<script type="text/javascript">
var service = '../CategoriesService.php';

function remove( id ){
	$.get( service, { m: 'remove', id: id }, function(data){
		if ( data ) {
			$('#'+id).fadeOut('slow');
		} else {
			alert( 'There was a problem!' );
		}
	});
}
</script>

<h3>Categories</h3>

    <table width="100%" border="0">
	<tr>
		
			<th scope="col">category_id</th>
			<th scope="col">category_name</th><th scope="col">Actions</th>   
    </tr>
       <?php echo $recordList; ?>
    </table>
    
    <a href="CategoriesForm.php">New Categories</a>
  
 <?php include '_footer.php'; ?>