<?php
require 'MySQLUtilities.php';

class MySQLSystemService
{
	private $link;
	
	public function __construct( $dblink )
	{
		$this->setLink( $dblink );
	}
		
	
/* ********************************************************************
 * ********************************************************************
 * 
 * 						6. SERVER VARIABLES
 * 
 * Below is all the methods that build up information about the server
 * and system.
 * 
 * 
 * ********************************************************************
 * ********************************************************************/
	
	/**
	 * I kill a thread that is connected or running
	 *
	 * @param [int] $whatThread the id of the thread
	 * @return [boolean] true or false
	 */
	public function killProcess( $whatThread )
	{
		$sql = "KILL $whatThread";
		$message = '';
		
		if ( mysqli_query ( $this->mysqli, $sql ) )
		{
			$message = array( 'message' => true, 'thread' => $whatThread );
		}
		else
		{
			$message = array( 'message' => false, 'thread' => $whatThread );
		}
		return $message;
	}
	
	/**
	 * I show all mysql system variables
	 *
	 * @return [json]
	 */
	public function sys_getSystemVariables()
	{
		return $this->_queryStatusToArray( "SHOW GLOBAL VARIABLES" );
	}
	
	/**
	 * I show all system privileges
	 *
	 * @return [json]
	 */
	public function sys_getSystemPrivileges()
	{
		return $this->_queryToArray ( "SHOW PRIVILEGES" );
	}
	
	/**
	 * I show the system status
	 *
	 * @return [json]
	 */
	public function sys_getSystemStatus()
	{
		return $this->_queryStatusToArray( "SHOW GLOBAL STATUS" );
	}
	
	/**
	 * I show system processes
	 *
	 * @return [json]
	 */
	public function sys_getSystemProcess()
	{
		return $this->_queryStatusToArray ( "SHOW FULL PROCESSLIST" );
	}
	
	/**
	 * I show all of the systems users
	 *
	 * @return [json]
	 */
	public function sys_getSystemUsers()
	{
		return $this->_queryToArray ( "SELECT * FROM mysql.user" );
	}
	
	/**
	 * I get server info
	 *
	 * @return [json]
	 */
	public function sys_getServerInfo()
	{
		$serverArray = array ();
		$aPath = $_SERVER [ 'DOCUMENT_ROOT' ];
		
		$serverArray [] = array ( 
			'aDiskFreeSpace' => disk_free_space ( $aPath ), 
			'aDiskTotalSize' => disk_total_space ( $aPath ), 
			'aServerSoftware' => $_SERVER [ 'SERVER_SOFTWARE' ], 
			'aServerName' => $_SERVER [ 'SERVER_NAME' ], 
			'aPHPVersion' => PHP_VERSION, 'aPHPOs' => PHP_OS, 
			'aPHPExtensionDir' => PHP_EXTENSION_DIR, 
			'aMySQLClientV' => mysqli_get_client_info ( $this->mysqli ), 
			'aMySQLServerV' => mysqli_get_server_version ( $this->mysqli ), 
			'aMySQLHost' => mysqli_get_host_info ( $this->mysqli ), 
			'aMySQLProtocol' => mysqli_get_proto_info ( $this->mysqli ),
			'aUptime' => $this->_getUptime() );
		
		return $serverArray;
	}
	
	/**
	 * I get all of the threads
	 *
	 * @return [json]
	 */
	public function sys_getThreads()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%Threads%'" );
	}
	
	/**
	 * I get the temp size
	 *
	 * @return [json]
	 */
	public function sys_getTemp()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%tmp%'" );
	}
	
	/**
	 * I get open tables
	 *
	 * @return [json]
	 */
	public function sys_getOpen()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%Open%'" );
	}
	
	/**
	 * I get the handlers variables
	 *
	 * @return [json]
	 */
	public function sys_getHandlers()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%Handler%'" );
	}
	
	/**
	 * I get the server uptime
	 *
	 * @return [array]
	 */
	public function sys_getUptime()
	{
		$result = mysqli_query ( $this->mysqli, "SHOW STATUS LIKE '%uptime%'" );
		$row = mysqli_fetch_row ( $result );
		$array =  $this->_formatUptime( $row [ 1 ] );
		
		return $array;
	}
	
	/**
	 * I get the recent queries
	 *
	 * @return [json]
	 */
	public function sys_getQuestions()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE 'Questions%'" );
	}
	
	/**
	 * I get the query cache
	 *
	 * @return [json]
	 */
	public function sys_getQcache()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%Qcache%'" );
	}
	
	/**
	 * I get InnoDB
	 *
	 * @return [json]
	 */
	public function sys_getInnoDb()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%Innodb%'" );
	}
	
	/**
	 * I get the key cache
	 *
	 * @return [json]
	 */
	public function sys_getKeys()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%Key%'" );
	}
	
	/**
	 * I get the performance of mysql.
	 *
	 * @return [json]
	 */
	public function sys_getPerformance()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%Slow%'" );
	}
	
	/**
	 * I get all the sort
	 *
	 * @return [json]
	 */
	public function sys_getSort()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%Sort%'" );
	}
	
	/**
	 * I get the connections
	 *
	 * @return [json]
	 */
	public function sys_getConnections()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%Connections%'" );
	}
	
	/**
	 * I get the aborted clients and connections
	 *
	 * @return unknown
	 */
	public function sys_getClients()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%Aborted%'" );
	}
	
	/**
	 * I get mysql bytes
	 *
	 * @return [json]
	 */
	public function sys_getBytes()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%Bytes%'" );
	}
	
	/**
	 * I get all the slave hosts
	 *
	 * @return [json]
	 */
	public function sys_getReplication()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%Slave%'" );
	}
	
	/**
	 * I get the commands
	 *
	 * @return [json]
	 */
	public function sys_getCommands()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%Com%'" );
	}
	
	/**
	 * I show all of the SHOW commands
	 *
	 * @return [json]
	 */
	public function sys_getShowCommands()
	{
		return $this->_queryStatusToArray ( "SHOW STATUS LIKE '%Com_show%'" );
	}
	
	/**
	 * I get the stats of the mysql connection
	 *
	 * @return [array]
	 */
	public function sys_getStat()
	{
		$stats = $this->mysqli->stat ();
		$newStats = explode ( ' ', $stats );
		
		return $newStats;
	}
	

/* ********************************************************************
 * ********************************************************************
 * 
 * 						POLLING METHODS
 * 
 * Below is all the methods for executing a query on the database, 
 * and getting all records from the database.
 * 
 * ********************************************************************
 * ********************************************************************/
	
	
	/**
	 * I am a polling method for checking the current select statements.
	 * @example Results
	 * <code>
	 * [
	 *	   {
	 *	      "Threads_cached":"0",
	 *	      "aTimestamp":"2009-02-20T21:52:34-08:00"
	 *	   },
	 *	   {
	 *	      "Threads_connected":"1",
	 *	      "aTimestamp":"2009-02-20T21:52:34-08:00"
	 *	   },
	 *	   {
	 *	      "Threads_created":"2070",
	 *	      "aTimestamp":"2009-02-20T21:52:34-08:00"
	 *	   },
	 *	   {
	 *	      "Threads_running":"1",
	 *	      "aTimestamp":"2009-02-20T21:52:34-08:00"
	 *	   }
	 *	]
	 *</code> 
	 * @return [json] encoded results
	 */
	public function pollQueries()
	{
		$result = mysqli_query ($this->getLink(), "SHOW GLOBAL STATUS LIKE '%Com_select%'" );
		$timestamp = date ( DATE_W3C );
		
		while ( $row = mysqli_fetch_row ( $result ) )
		{
			$array [] = array ( $row [ 0 ] => $row [ 1 ], 'aTimestamp' => $timestamp );
		}
		return $array;
	}
	
	/**
	 * I am a polling method for checking the current bytes sent.
	 * @example Results
	 * <code>
	 * [
	 * 	  {
	 * 		"Bytes_sent":"48438",
	 * 		"aTimestamp":"2009-02-20T21:52:34-08:00"
   	 *	  }
	 * ]
	 *</code> 
	 * @return [json] encoded results
	 */
	public function pollTraffic()
	{
		$result = mysqli_query ( $this->getLink(), "SHOW GLOBAL STATUS LIKE '%Bytes_sent%'" );
		$timestamp = date ( DATE_W3C );
		
		while ( $row = mysqli_fetch_row ( $result ) )
		{
			$array [] = array ( $row [ 0 ] => $row [ 1 ], 'aTimestamp' => $timestamp );
		}
		return $array;
	}
	
	/**
	 * I am a polling method for checking the current connections.
	 * @example Results
	 * <code>
	 * [
	 * 	  {
	 * 		"Com_select":"97",
	 * 		"aTimestamp":"2009-02-20T21:52:34-08:00"
   	 *	  }
	 * ]
	 *</code> 
	 * 
	 * @return [json] encoded results
	 */
	public function pollConnections()
	{
		$result = mysqli_query ( $this->getLink(), "SHOW GLOBAL STATUS LIKE '%Threads_%'" );
		$timestamp[] = array( 'aTimestamp' => date ( DATE_W3C ) );
		
		while ( $row = mysqli_fetch_row ( $result ) )
		{
			$array [] = array ( $row [ 0 ] => $row [ 1 ] );
		}
		
		return $array;
	}

	
	
/* ********************************************************************
 * ********************************************************************
 * 
 * 						GETTERS/SETTERS
 * 
 * Below is all the methods for executing a query on the database, 
 * and getting all records from the database.
 * 
 * ********************************************************************
 * ********************************************************************/
	
	/**
	 * @return [mysqli] link
	 */
	public function getLink()
	{
		return $this->link;
	}
	
	/**
	 * @param [mysqli] $link
	 */
	public function setLink( $link )
	{
		$this->link = $link;
	}

	
	/**
	 * I execute a query and return the result as an array.
	 *
	 * @param [string] $sql the query to be executed
	 * @return [array] the result array
	 */
	private function _queryToArray( $sql )
	{
		$query = mysqli_query ( $this->getLink(), $sql );
		$array = array ();
		
		while ( $row = mysqli_fetch_assoc ( $query ) )
		{
			$array [] = $row;
		}
		
		return $array;
	}
	
	/**
	 * I get the query status
	 *
	 * @param [string] $sql
	 * @return [array] mysql status with the ('_') striped out
	 */
	private function _queryStatusToArray( $sql )
	{
		$result = mysqli_query ( $this->getLink(), $sql );
		
		while ( $row = mysqli_fetch_assoc ( $result ) )
		{
			//replace some of the names
			$row = str_replace ( 'Com_', '', $row );
			//take out the _ of the rows
			$row = str_replace ( '_', ' ', $row );
			
			$array [] = $row;
		}
		sort ( $array );
		
		return $array;
	}
	
}

?>