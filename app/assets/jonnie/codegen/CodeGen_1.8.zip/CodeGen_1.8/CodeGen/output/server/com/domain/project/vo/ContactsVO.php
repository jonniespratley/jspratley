<?php/**                    My Test Application
                *//**  * I am a object representing the @TABLE table. *  * @version CodeGen - 1.8 * @author CodeGen - Jonnie Spratley (http://jonniespratley.com/code) * * @package com.domain.project.VO * @name ContactsVO.php */class ContactsVO{	/* Official boycott on amphp, because its trash */	//public $_explicitType = 'com.domain.project.vo.ContactsVO';		
			public $address;
			public $city;
			public $country;
			public $date;
			public $email;
			public $id;
			public $name;
			public $phone;
			public $state;
			public $zip;		public function __construct(){}		public function mapObject( $vo )	{		
			$this->address = $vo["address"];
			$this->city = $vo["city"];
			$this->country = $vo["country"];
			$this->date = $vo["date"];
			$this->email = $vo["email"];
			$this->id = $vo["id"];
			$this->name = $vo["name"];
			$this->phone = $vo["phone"];
			$this->state = $vo["state"];
			$this->zip = $vo["zip"];	}		public function setNamespace( $namespace )	{		$this->explicitType = $namespace;	}		public function __get( $name )	{		return $this->$name;	}		public function __set( $name, $value )	{		$this->$name = $value;	}	}?>                                          