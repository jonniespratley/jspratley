<?php 
require_once '../CommentsService.php';
require_once '../vo/CommentsVO.php';

$service = new CommentsService();
$result = '';
$recordList = '';

if ( isset($_POST['save']) )
{
	unset( $_POST['save'] );
	$recordValues = $_POST;
	$result = $service->saveComments( $recordValues );	
}

$recordsArray = $service->getAllComments();
$recordVO = new CommentsVO();

for ( $i = 0; $i < count( $recordsArray ); $i++ ) 
{
	$recordVO = $recordsArray[ $i ];
	
	$recordList .= '<tr id="'.$recordVO->id.'">';

	
			$recordList .= "<td>$recordVO->comment_body</td>";
			$recordList .= "<td>$recordVO->comment_created</td>";
			$recordList .= "<td>$recordVO->comment_name</td>";
			$recordList .= "<td>$recordVO->id</td>";

	$recordList .= '<td class="actions">';
	$recordList .= '<button class="edit" onclick="window.location=\'CommentsForm.php?id='.$recordVO->id.'\'">Edit</button>';
	$recordList .= '<button class="delete" onclick=" remove('.$recordVO->id.')">Delete</button></td>';
	$recordList .= '</tr>';
}

?>
<?php include '_header.php'; ?> 

<script type="text/javascript">
var service = '../CommentsService.php';

function remove( id ){
	$.get( service, { m: 'remove', id: id }, function(data){
		if ( data ) {
			$('#'+id).fadeOut('slow');
		} else {
			alert( 'There was a problem!' );
		}
	});
}
</script>

<h3>Comments</h3>

    <table width="100%" border="0">
	<tr>
		
			<th scope="col">comment_body</th>
			<th scope="col">comment_created</th>
			<th scope="col">comment_name</th>
			<th scope="col">id</th><th scope="col">Actions</th>   
    </tr>
       <?php echo $recordList; ?>
    </table>
    
    <a href="CommentsForm.php">New Comments</a>
  
 <?php include '_footer.php'; ?>