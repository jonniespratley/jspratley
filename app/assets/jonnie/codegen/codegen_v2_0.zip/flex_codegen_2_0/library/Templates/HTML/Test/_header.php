<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>@APPLICATION</title>
<link href="styles.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="jquery-1.2.1.pack.js"></script>
<script type="text/javascript">
$(function(){
	
	//Stripe every odd table
	$("table tr:nth-child(odd)").addClass("altrow");
	
	
});
</script>



</head>
<body>
<div id="container">
	<div id="header">
		<h1>@APPLICATION</h1>
	</div><!-- ends #header -->
	<div id="content">