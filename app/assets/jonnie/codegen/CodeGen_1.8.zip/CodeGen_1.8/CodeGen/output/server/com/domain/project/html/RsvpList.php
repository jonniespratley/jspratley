<?php 
require_once '../RsvpService.php';
require_once '../vo/RsvpVO.php';

$service = new RsvpService();
$result = '';
$recordList = '';

if ( isset($_POST['save']) )
{
	unset( $_POST['save'] );
	$recordValues = $_POST;
	$result = $service->saveRsvp( $recordValues );	
}

$recordsArray = $service->getAllRsvp();
$recordVO = new RsvpVO();

for ( $i = 0; $i < count( $recordsArray ); $i++ ) 
{
	$recordVO = $recordsArray[ $i ];
	
	$recordList .= '<tr id="'.$recordVO->id.'">';

	
			$recordList .= "<td>$recordVO->email</td>";
			$recordList .= "<td>$recordVO->first</td>";
			$recordList .= "<td>$recordVO->id</td>";
			$recordList .= "<td>$recordVO->last</td>";
			$recordList .= "<td>$recordVO->phone</td>";
			$recordList .= "<td>$recordVO->state</td>";

	$recordList .= '<td class="actions">';
	$recordList .= '<button class="edit" onclick="window.location=\'RsvpForm.php?id='.$recordVO->id.'\'">Edit</button>';
	$recordList .= '<button class="delete" onclick=" remove('.$recordVO->id.')">Delete</button></td>';
	$recordList .= '</tr>';
}

?>
<?php include '_header.php'; ?> 

<script type="text/javascript">
var service = '../RsvpService.php';

function remove( id ){
	$.get( service, { m: 'remove', id: id }, function(data){
		if ( data ) {
			$('#'+id).fadeOut('slow');
		} else {
			alert( 'There was a problem!' );
		}
	});
}
</script>

<h3>Rsvp</h3>

    <table width="100%" border="0">
	<tr>
		
			<th scope="col">email</th>
			<th scope="col">first</th>
			<th scope="col">id</th>
			<th scope="col">last</th>
			<th scope="col">phone</th>
			<th scope="col">state</th><th scope="col">Actions</th>   
    </tr>
       <?php echo $recordList; ?>
    </table>
    
    <a href="RsvpForm.php">New Rsvp</a>
  
 <?php include '_footer.php'; ?>