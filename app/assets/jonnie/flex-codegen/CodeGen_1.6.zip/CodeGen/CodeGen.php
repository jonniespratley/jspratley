<?php
require_once 'library/CGManager.php';
require_once 'library/SchemaReader.php';
require_once 'library/SchemaWriter.php';
require_once 'library/ConnectionWriter.php';
require_once 'library/ConfigReader.php';
require_once 'library/ConfigWriter.php';
require_once 'library/Connection.php';
require_once 'library/FileSystemService.php';
require_once 'library/CairngormValueObjectGen.php';
require_once 'library/PHPRESTServiceGen.php';
require_once 'library/PHPServiceGen.php';
require_once 'library/PHPValueObjectGen.php';
require_once 'library/FlexFormGen.php';
require_once 'library/FlexListGen.php';
require_once 'library/FlexMainGen.php';
require_once 'library/Log.php';
require_once 'library/XMLLog.php';

class CodeGen
{
	private $mysqli;
	private $log;
	private $config;
	
	/**
	 * I am the constructore for the CodeGen
	 *
	 * @example Here is what your config.xml file should look like. 
	 * <code>
	 * <?xml version="1.0" encoding="UTF-8"?>
	 * <config>
	 * 		<host>localhost</host>
	 * 		<user>root</user>
	 * 		<pass>fred</pass>
	 * </config>
	 * </code>
	 * 
	 * @param [string] $configFile The config.xml file
	 */
	public function __construct( $configFile )
	{
		$this->config = new ConfigReader ( );
		$this->config->readConfig ( $configFile );
		$this->mysqli = new mysqli ( $this->config->getHost (), $this->config->getUser (), $this->config->getPass () );
	}
	
	public function writeSchema()
	{
		return SchemaWriter::writeSchema ( $this->mysqli, $this->config->getDatabase () );
	}
	
	public function generateCode( $schema )
	{
		return SchemaReader::readSchema ( $schema, $this->config->getDatabase () );
	}
	
	public function browseDirectory( $path, $level )
	{
		return FileSystemService::browseDirectory ( $path, $level );
	}
	
	public function readFile( $file )
	{
		return FileSystemService::readFile ( $file );
	}
	
	public function writeFile( $file, $contents )
	{
		return FileSystemService::writeFile ( $file, $contents );
	}
	
	private function execute( $sql )
	{
		return $this->mysqli->query ( $sql );
	}

	static public function writeConfig( $host, $user, $pass, $app, $schema, $endpoint, $namespace )
	{
		return ConfigWriter::writeConfig( $host, $user, $pass, $app, $schema, $endpoint, $namespace );
	}
}
?>