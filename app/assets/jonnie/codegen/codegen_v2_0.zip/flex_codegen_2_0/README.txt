CodeGen

##################################
		TODO 9-19-10
##################################
1. PHPGen filename variables



##################################
		IMPORTANT FILES
##################################

assets/js/CodeGen.js
assets/js/CodeGenUtilities.js
assets/css/codegen.css
includes/
library/
Templates/

##################################
			NOTES
##################################


/**
 *
 * @TODO: Sept 29th 2009
 * 1. Fix all main generators to accept new parameters when generating code,
 * if an array is passed as the options read from the array keys
 * else read from the xml file.
 *
 * Files to Edit:
 * 	1. CairngormGen.php - DONE
 * 	2. ConnectionWriter.php
 * 	3. EclipseGen.php
 * 	4. FlexGen.php
 * 	5. HTMLGen.php
 * 	6. PHPGen.php - DONE
 *
 *
 *
 *
 * @TODO: Sept 28th 2009
 *
 *
 *
 * 1. When creating application make main folder name of the application. For flex import.
 * with services folder inside of folder.
 * 2. Add new options for generation, including
 * getters/setters
 * REST url style
 * API key use
 * Admin Logging
 * User monitoring
 * Field alias, as well as uploading edited config and schema files.
 * Field toggle display.
 *
 * @TODO: July 11th 2009
 *
 * 1. Edit php service template and add post switch statement on REST part.
 * 2. Add my jquery pages plugin to the main navigation of the site.
 * 3. Fix boxes to make all drag drop.
 * 4. Use 960.css style
 * 5. Create class to display recent updates to CodeGen repo
 * 6. Create automation script that downloads all the recent versions
 * 7. Create a update checker.
 * 8. Incorporate Flex service browser and api tester.
 * 9. Create sql schema export.
 * 10. Create class to find table relationships using rails method of
 * 		has_many:
 * 		has_one:
 * 		belongs_to:
 * 		has_and_belongs_to_many:
 *
 *
 
 * @TODO: Auguest 7th 2009
 * 1. Upon successful generation of flex application, save the information in the sqlite database cg_historys table
 *
 */


