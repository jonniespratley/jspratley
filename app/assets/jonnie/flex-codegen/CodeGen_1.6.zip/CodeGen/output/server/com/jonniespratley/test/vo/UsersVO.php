<?php/**  * I am a object representing the Users table. *  * @version 1.6 * @author Jonnie Spratley (http://jonniespratley.com/code) * * @package com.jonniespratley.test.VO * @name UsersVO.php */class UsersVO{	var $_explicitType = 'com.jonniespratley.test.VO.UsersVO';		
			public $user_id;
			public $comp_id;
			public $branch_id;
			public $user_fname;
			public $user_lname;
			public $user_password;
			public $user_idtype;
			public $user_docid;
			public $user_dob;
			public $user_empid;
			public $user_address;
			public $user_telh;
			public $user_telw;
			public $user_cell;
			public $user_email;
			public $user_securityrole;
			public $user_logindate;		public function __construct( $vo )	{		
			$this->user_id = $vo["user_id"];
			$this->comp_id = $vo["comp_id"];
			$this->branch_id = $vo["branch_id"];
			$this->user_fname = $vo["user_fname"];
			$this->user_lname = $vo["user_lname"];
			$this->user_password = $vo["user_password"];
			$this->user_idtype = $vo["user_idtype"];
			$this->user_docid = $vo["user_docid"];
			$this->user_dob = $vo["user_dob"];
			$this->user_empid = $vo["user_empid"];
			$this->user_address = $vo["user_address"];
			$this->user_telh = $vo["user_telh"];
			$this->user_telw = $vo["user_telw"];
			$this->user_cell = $vo["user_cell"];
			$this->user_email = $vo["user_email"];
			$this->user_securityrole = $vo["user_securityrole"];
			$this->user_logindate = $vo["user_logindate"];	}	}?>                                          