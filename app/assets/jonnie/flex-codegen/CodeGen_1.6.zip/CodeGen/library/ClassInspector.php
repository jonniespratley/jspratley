<?php

class ClassInspector
{
	
	public function __construct()
	{
	
	}
	
	static public function inspectClass( $className )
	{
		$class = new ReflectionClass ( $className );
		$classComment = $class->getDocComment ();
		$allMethodsArray = $class->getMethods ();
		$methodTable = array ();
		
		foreach ( $allMethodsArray as $method )
		{
			
			//Checks if the method is public, and/or doesnt have a '_' in front of the method
			if ( $method->isPublic () && $method->name [ 0 ] != '_' )
			{
				if ( $method->isConstructor () )
				{
					$classComment .= $method->getDocComment ();
				}
				else
				{
					$methodParameter = $method->getParameters ();
					
					$methodsArray = array ();
					$parametersArray = array ();
					
					//For each parameter on every method, get the arguments
					foreach ( $methodParameter as $parameter )
					{
						//Parameters array
						$parametersArray [] = $parameter->getName ();
					}
					
					//build the method array
					$methodsArray [] = array ( 
					'label' => $method->name, 
					'children' => array('label' => ClassInspector::cleanArguments( '(' . implode ( ',', $parametersArray ) ) ), 
					'comments' => ClassInspector::cleanComment ( $method->getDocComment () ) );
					
					$methodTable [] = $methodsArray;
				}
			}
		}
		return $methodsArray;
	
	}
	
	/**
	 * Cleans the comment string by removing all comment start and end characters.
	 *
	 * @static
	 * @private
	 * @param $comment(String) The method's comment.
	 */
	static public function cleanComment( $comment )
	{
		$comment = str_replace ( "/**", "", $comment );
		$comment = str_replace ( "*/", "", $comment );
		$comment = str_replace ( "*", "", $comment );
		$comment = str_replace ( "\r", "", trim ( $comment ) );
		$comment = eregi_replace ( "\n[ \t]+", "\n", trim ( $comment ) );
		$comment = str_replace ( "\n", "\\n", trim ( $comment ) );
		$comment = eregi_replace ( "[\t ]+", " ", trim ( $comment ) );
		$comment = str_replace ( "\"", "\\\"", $comment );
		return $comment;
	}
	
	/**
	 * Cleans the arguments array.
	 * This method removes all whitespaces and the leading "$" sign from each argument
	 * in the array.
	 *
	 * @static
	 * @access private
	 * @param $args(Array) The "dirty" array with arguments.
	 */
	static public function cleanArguments( $args, $commentParams )
	{
		$result = array ();
		
		foreach ( $args as $index => $arg )
		{
			$arg = strrstr ( str_replace ( '[', '', $arg ), '=' );
			if ( ! isset ( $commentParams [ $index ] ) )
			{
				$result [] = trim ( $arg );
			}
			else
			{
				$start = trim ( $arg );
				$end = trim ( str_replace ( '$', '', $commentParams [ $index ] ) );
				//echo($start);
				//echo($end);
				if ( $end != "" && $start != "" && strpos ( strtolower ( $end ), strtolower ( $start ) ) === 0 )
				{
					$end = substr ( $end, strlen ( $start ) );
				}
				$result [] = $start . ' - ' . trim ( $end );
			}
		}
		
		return $result;
	}
}

?>