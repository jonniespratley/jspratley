<?php
require_once 'CodeService.php';

error_reporting ( E_ERROR | E_USER_ERROR | E_PARSE );

if ( isset ( $_REQUEST[ 'h' ] ) )
{
	$host = $_REQUEST[ 'h' ]; //Host
}

if ( isset ( $_REQUEST[ 'u' ] ) )
{
	$user = $_REQUEST[ 'u' ]; //User
}

if ( isset ( $_REQUEST[ 'p' ] ) )
{
	$pass = $_REQUEST[ 'p' ]; //Password
}

if ( isset ( $_REQUEST[ 'm' ] ) )
{
	$mode = $_REQUEST[ 'm' ]; //Mode
}

if ( isset ( $_REQUEST[ 'd' ] ) )
{
	$database = $_REQUEST[ 'd' ]; //Database
}

if ( isset ( $_REQUEST[ 't' ] ) )
{
	$table = $_REQUEST[ 't' ]; //Table
}

if ( isset ( $_REQUEST[ 'q' ] ) )
{
	$query = $_REQUEST[ 'q' ]; //Query
}


/*******************************************
 * Recipe vars
 ****************************************** */
if ( isset ( $_REQUEST[ 'id' ] ) )
{
	$id = $_REQUEST[ 'id' ]; //Query
}

if ( isset ( $_REQUEST[ 'chapter' ] ) )
{
	$chapter = $_REQUEST[ 'chapter' ]; //Query
}

if ( isset ( $_REQUEST[ 'title' ] ) )
{
	$label = $_REQUEST[ 'title' ]; //Query
}

if ( isset ( $_REQUEST[ 'problem' ] ) )
{
	$problem = $_REQUEST[ 'problem' ]; //Query
}

if ( isset ( $_REQUEST[ 'solution' ] ) )
{
	$solution = $_REQUEST[ 'solution' ]; //Query
}

if ( isset ( $_REQUEST[ 'code' ] ) )
{
	$code = $_REQUEST[ 'code' ]; //Query
}

if ( isset ( $_REQUEST[ 'discussion' ] ) )
{
	$discussion = $_REQUEST[ 'discussion' ]; //Query
}

if ( isset ( $_REQUEST[ 'category' ] ) )
{
	$category = $_REQUEST[ 'category' ]; //Query
}

/*******************************************
 * Code vars
 ****************************************** */
if ( isset ( $_REQUEST[ 'description' ] ) )
{
	$description = $_REQUEST[ 'description' ]; //Query
}

if ( isset ( $_REQUEST[ 'lang' ] ) )
{
	$lang = $_REQUEST[ 'lang' ]; //Query
}


$database = 'jonniespratleys_code';
$host = 'localhost';
$user = 'spratley_guest';
$pass = 'guest';
$table1 = 'code_posts';
$table2 = 'cookbook_posts';

$service = new CodeService( $host, $user, $pass );

switch ( $mode )
{
	case 'getCodeTree' :
		$code = $service->getCodeTree( $database, $table1, $query, true );
		echo $code;
	break;
	
	case 'getCookbookTree' :
		$code = $service->getCookbookTree( $database, $table2, $query, true );
		echo $code;
	break;
	
	case 'saveRecipe':
		$code = $service->saveRecipe( $database, $table2, $id, $chapter, $label, $problem, $solution, $code, $discussion, $category );
		echo $code;
	break;
	
	case 'saveCode':
		$code = $service->saveCode( $database, $table1, $id, $label, $description, $lang, $code, $category );
		echo $code;
	break;
	
	
		
	default :
		trigger_error ( 'Please choose a mode.' );
	exit ();
}
?>