<?php

include 'Required.php';

class PHPServiceGen implements IGenerate
{
	
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		//TODO: Need to fix the uppercasing of the table name because on live server it doen't recongize it
		$uppercaseTable = ucfirst( $table );
		$lowercaseTable = $table;
		$filename = ucfirst ( $table ) . 'Service.php';
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		$namespace = Utilities::namespaceApplication ( $namespace );
		$tableService = FileSystemService::readFile ( TemplateManager::$PHP_TEMPLATE_LOCATION.'dao.txt' );
		$setFields = '';
		
		foreach ( $fields as $field )
		{
			$setFields .= '' . $field [ 'name' ] . ' = ".$this->_prepare( $' . $lowercaseTable . 'VO->' . $field [ 'name' ] . ').", ';
		}
	
		$setFields = Utilities::trimSQL ( $setFields );
		$template = preg_replace ( TemplateManager::$LOWERCASE_TABLE_PATTERN, $lowercaseTable, $tableService );
		$template = preg_replace ( TemplateManager::$UPPERCASE_TABLE_PATTERN, $uppercaseTable, $template );		
		$template = preg_replace ( TemplateManager::$DATABASE_PATTERN, $database, $template );
		$template = preg_replace ( TemplateManager::$SET_FIELDS_PATTERN, $setFields, $template );
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $template );
		$template = preg_replace ( TemplateManager::$CG_VERSION_PATTERN, CGManager::$CG_VERSION, $template );
		$template = preg_replace ( TemplateManager::$CG_AUTHOR_PATTERN, CGManager::$CG_AUTHOR, $template );
		
		Utilities::checkOrMakeFolders ( TemplateManager::$SERVER_OUTPUT, $folderNamespace, '' );
		FileSystemService::writeFile ( TemplateManager::$SERVER_OUTPUT . $folderNamespace . '/' . $filename, $template );
		
		return 'Generated PHP Service for '. $uppercaseTable;
	}

}

?>