<?php/**  * I am a object representing the Maps table. *  * @version 1.6 * @author Jonnie Spratley (http://jonniespratley.com/code) * * @package com.jonniespratley.test.VO * @name MapsVO.php */class MapsVO{	var $_explicitType = 'com.jonniespratley.test.VO.MapsVO';		
			public $id;
			public $map_lat;
			public $map_lon;
			public $map_type;
			public $location_id;
			public $user_id;		public function __construct( $vo )	{		
			$this->id = $vo["id"];
			$this->map_lat = $vo["map_lat"];
			$this->map_lon = $vo["map_lon"];
			$this->map_type = $vo["map_type"];
			$this->location_id = $vo["location_id"];
			$this->user_id = $vo["user_id"];	}	}?>                                          