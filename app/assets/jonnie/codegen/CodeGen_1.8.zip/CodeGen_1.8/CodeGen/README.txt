CodeGen 1.8

Make sure you put the CodeGen folder on your webroot


htdocs/
	CodeGen/
		assets/
		library/
		output/
		Templates/
		index.php
		README.txt
		
		
