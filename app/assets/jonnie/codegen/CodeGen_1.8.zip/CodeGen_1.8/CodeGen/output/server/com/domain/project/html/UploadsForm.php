<?php 
require_once '../UploadsService.php';
require_once '../vo/UploadsVO.php';


			$id = "";
			$upload_name = "";
			$upload_size = "";
			$upload_type = "";
			$user_id = "";
$id = '';

if ( $_GET['id'] )
{
	$id = $_GET['id'];
	$service = new UploadsService();
	$recordVO = new UploadsVO();
	$record = $service->getOneUploads( $id ); 
	$recordVO = $record[0];//First object in array
	
	
			$id = $recordVO->id;
			$upload_name = $recordVO->upload_name;
			$upload_size = $recordVO->upload_size;
			$upload_type = $recordVO->upload_type;
			$user_id = $recordVO->user_id;
	
	
}
?>
<?php include '_header.php'; ?>
<form id="formUploads" name="formUploads" method="post" action="UploadsList.php">
	 
	
	
			<div>
		 		<label for="id">Id</label>
		 		<input type="text" name="id" value="<?php echo $id; ?>"/>
		 	</div>
			<div>
		 		<label for="upload_name">Upload_name</label>
		 		<input type="text" name="upload_name" value="<?php echo $upload_name; ?>"/>
		 	</div>
			<div>
		 		<label for="upload_size">Upload_size</label>
		 		<input type="text" name="upload_size" value="<?php echo $upload_size; ?>"/>
		 	</div>
			<div>
		 		<label for="upload_type">Upload_type</label>
		 		<input type="text" name="upload_type" value="<?php echo $upload_type; ?>"/>
		 	</div>
			<div>
		 		<label for="user_id">User_id</label>
		 		<input type="text" name="user_id" value="<?php echo $user_id; ?>"/>
		 	</div>
    
    <div>
    	<input type="hidden" name="id" value="<?php echo $id; ?>"/>
	   <input name="save" type="submit" value="Save" />
		<button onclick="window.location='UploadsList.php'">Back</button>
    </div>
</form>
 <?php include '_footer.php'; ?>