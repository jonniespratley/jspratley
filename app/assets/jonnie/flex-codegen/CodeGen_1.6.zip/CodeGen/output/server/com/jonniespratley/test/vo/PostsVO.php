<?php/**  * I am a object representing the Posts table. *  * @version 1.6 * @author Jonnie Spratley (http://jonniespratley.com/code) * * @package com.jonniespratley.test.VO * @name PostsVO.php */class PostsVO{	var $_explicitType = 'com.jonniespratley.test.VO.PostsVO';		
			public $id;
			public $title;
			public $excerpt;
			public $body;		public function __construct( $vo )	{		
			$this->id = $vo["id"];
			$this->title = $vo["title"];
			$this->excerpt = $vo["excerpt"];
			$this->body = $vo["body"];	}	}?>                                          