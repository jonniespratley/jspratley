<div id="step2" class="box round">
<h3>Application Information</h3>
<form id="form_config">
<?php
$step2Options = array ( 
	array ( 
	'label' => 'Application Name', 
	'name' => 'txt_application', 
	'type' => 'text', 
	'value' => 'CodeGenTest', 
	'class' => 'medium' 
), array ( 
	'label' => 'Application Namespace', 
	'name' => 'txt_namespace', 
	'type' => 'text', 
	'value' => 'com.project.codegentest', 
	'class' => 'medium' 
), array ( 
	'label' => 'Location of Services', 
	'name' => 'txt_endpoint', 
	'type' => 'text', 
	'value' => 'http://localhost/project/services', 
	'class' => 'medium' 
), array ( 
	'label' => 'Code Framework', 
	'name' => 'txt_framework', 
	'type' => 'select', 
	'options' => array (
		'Cairngorm' => 'Cairngorm Framework', 
		'AS3' => 'General HTTPService/AS3' ), 
	'class' => 'medium' 
), array ( 
	'label' => 'Copywrite', 
	'name' => 'txt_copywrite', 
	'type' => 'textarea', 
	'value' => 'Copywrite Info', 
	'class' => 'medium' 
), array ( 
	'label' => '', 
	'name' => 'btn_generateConfig', 
	'type' => 'button', 
	'value' => 'Create', 
	'class' => 'submit' 
) 
);

$html->doOptions ( $step2Options );
?>
</form>
</div>