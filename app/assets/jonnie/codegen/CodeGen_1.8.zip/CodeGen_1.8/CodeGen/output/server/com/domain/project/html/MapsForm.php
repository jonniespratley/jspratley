<?php 
require_once '../MapsService.php';
require_once '../vo/MapsVO.php';


			$id = "";
			$location_id = "";
			$map_lat = "";
			$map_lon = "";
			$map_type = "";
			$user_id = "";
$id = '';

if ( $_GET['id'] )
{
	$id = $_GET['id'];
	$service = new MapsService();
	$recordVO = new MapsVO();
	$record = $service->getOneMaps( $id ); 
	$recordVO = $record[0];//First object in array
	
	
			$id = $recordVO->id;
			$location_id = $recordVO->location_id;
			$map_lat = $recordVO->map_lat;
			$map_lon = $recordVO->map_lon;
			$map_type = $recordVO->map_type;
			$user_id = $recordVO->user_id;
	
	
}
?>
<?php include '_header.php'; ?>
<form id="formMaps" name="formMaps" method="post" action="MapsList.php">
	 
	
	
			<div>
		 		<label for="id">Id</label>
		 		<input type="text" name="id" value="<?php echo $id; ?>"/>
		 	</div>
			<div>
		 		<label for="location_id">Location_id</label>
		 		<input type="text" name="location_id" value="<?php echo $location_id; ?>"/>
		 	</div>
			<div>
		 		<label for="map_lat">Map_lat</label>
		 		<input type="text" name="map_lat" value="<?php echo $map_lat; ?>"/>
		 	</div>
			<div>
		 		<label for="map_lon">Map_lon</label>
		 		<input type="text" name="map_lon" value="<?php echo $map_lon; ?>"/>
		 	</div>
			<div>
		 		<label for="map_type">Map_type</label>
		 		<input type="text" name="map_type" value="<?php echo $map_type; ?>"/>
		 	</div>
			<div>
		 		<label for="user_id">User_id</label>
		 		<input type="text" name="user_id" value="<?php echo $user_id; ?>"/>
		 	</div>
    
    <div>
    	<input type="hidden" name="id" value="<?php echo $id; ?>"/>
	   <input name="save" type="submit" value="Save" />
		<button onclick="window.location='MapsList.php'">Back</button>
    </div>
</form>
 <?php include '_footer.php'; ?>