<?php

class TemplateManager
{
	/**
	 * Regular Expression pattern for finding component namespace in the main template
	 *
	 * @var [regxpr]
	 */
	public static $COMPONENT_NAMESPACE_PATTERN = '(@COMPONENT_NAMESPACE)';

	/**
	 * Regular Expression pattern for finding init validators for the form template
	 *
	 * @var [regxpr]
	 */
	public static $INIT_VALIDATORS_PATTERN = '(@INITVALIDATORS)';
	
	/**
	 * Regular Expression pattern for finding validators inside the form template
	 *
	 * @var [regxpr]
	 */
	public static $VALIDATORS_PATTERN = '(@VALIDATORS)';
	
/**
	 * Regular Expression pattern for finding event const inside the event template
	 *
	 * @var [regxpr]
	 */	
	public static $EVENT_CONST = '(@EVENTCONST)';
	
	/**
	 * Regular Expression pattern for finding component namespace in all templates
	 *
	 * @var [regxpr]
	 */
	public static $NAMESPACE_PATTERN = '(@NAMESPACE)';
	
	/**
	 * Regular Expression pattern for finding the table name in all templates
	 *
	 * @var [regxpr]
	 */ 
	public static $TABLE_PATTERN = '(@TABLE)';
	public static $TABLE_REGULAR_PATTERN = '(@TABLE_REGULAR)';
	public static $TABLE_UFIRST_PATTERN = '(@TABLE_UFIRST)';
	public static $UPPERCASE_TABLE_PATTERN = '(@UC_TABLE)';
	public static $LOWERCASE_TABLE_PATTERN = '(@LC_TABLE)';
	
	public static $SELECTED_TABLE_PATTERN = '(@SELECTED_TABLE)';
	public static $COLLECTION_TABLE_PATTERN = '(@COLLECTION_TABLE)';
	
	/**
	 * Regular Expression pattern for finding field variables inside the form template
	 *
	 * @var [regxpr]
	 */
	public static $FIELD_VARS_PATTERN = '(@FIELDVARS)';
	
	/**
	 * Regular Expression pattern for finding fields inside the form template
	 *
	 * @var [regxpr]
	 */
	public static $FIELDS_PATTERN = '(@FIELDS)';
	
	/**
	 * Regular Expression pattern for finding endpoint for the services.mxml template
	 *
	 * @var [regxpr]
	 */
	public static $ENDPOINT_PATTERN = '(@ENDPOINT)';
	
	/**
	 * Regular Expression pattern for finding gateway for the services.mxml template
	 *
	 * @var [regxpr]
	 */
	public static $GATEWAY_PATTERN = '(@GATEWAY)';
	
	/**
	 * Regular Expression pattern for finding clear fields inside the form template
	 *
	 * @var [regxpr]
	 */
	public static $CLEAR_FIELDS_PATTERN = '(@CLEARFIELDS)';
	
	/**
	 * Regular Expression pattern for finding set the fields inside the form template
	 *
	 * @var [regxpr]
	 */
	public static $SET_FIELDS_PATTERN = '(@SETFIELDS)';
	
	/**
	 * Regular Expression pattern for finding form fields inside the form template
	 *
	 * @var [regxpr]
	 */
	public static $FORM_FIELDS_PATTERN = '(@FORMFIELDS)';
	
	/**
	 * Regular Expression pattern for finding list fields inside list template
	 *
	 * @var [regxpr]
	 */
	public static $LIST_FIELDS_PATTERN = '(@LISTFIELDS)';
	
	public static $FIELDS_QUERY_PATTERN = '(@FIELD_TO_QUERY)';
	
	/**
	 * Regular Expression pattern for finding host name for the connection script
	 *
	 * @var [regxpr]
	 */
	public static $HOST_PATTERN = '(@HOST)';
	
	/**
	 * Regular Expression pattern for finding the user for the connection script
	 *
	 * @var [regxpr]
	 */
	public static $USER_PATTERN = '(@USER)';
	
	/**
	 * Regular Expression pattern for finding the pass for the connection script
	 *
	 * @var [regxpr]
	 */
	public static $PASS_PATTERN = '(@PASS)';
	
	/**
	 * Regular Expression pattern for finding the database for the connection script
	 *
	 * @var [regxpr]
	 */
	public static $DATABASE_PATTERN = '(@DATABASE)';
	
	/**
	 * Regular Expression pattern for finding application name for all templates
	 *
	 * @var [regxpr]
	 */
	public static $APPLICATION_PATTERN = '(@APPLICATION)';
	
	/**
	 * Regular Expression pattern for finding component events to commands in the controller
	 *
	 * @var [regxpr]
	 */
	public static $EVENT_COMMAND_PATTERN = '(@EVENTSCOMMANDS)';
	
	public static $CG_AUTHOR_PATTERN = '(@CG_AUTHOR)';
	public static $CG_VERSION_PATTERN = '(@CG_VERSION)';
	public static $FILE_INCLUDES_PATTERN = '(@INCLUDES)';
	
	public static $REST_TABLE_GET_PATTERN = '(@REST_TABLE_GET)';
	public static $REST_TABLE_SAVE_PATTERN = '(@REST_TABLE_SAVE)';
	public static $REST_TABLE_REMOVE_PATTERN = '(@REST_TABLE_REMOVE)';
	
	public static $SERVICE_GET_CALL_PATTERN = '(@SERVICE_GET_CALL)';
	public static $SERVICE_SAVE_CALL_PATTERN = '(@SERVICE_SAVE_CALL)';
	public static $SERVICE_REMOVE_CALL_PATTERN = '(@SERVICE_REMOVE_CALL)';
	
	public static $SERVICE_GET_RESULT_PATTERN = '(@SERVICE_GET_RESULT)';
	public static $SERVICE_SAVE_RESULT_PATTERN = '(@SERVICE_SAVE_RESULT)';
	public static $SERVICE_REMOVE_RESULT_PATTERN = '(@SERVICE_REMOVE_RESULT)';
	public static $SERVICE_COMMENTS_PATTERN = '(@SERVICE_COMMENTS)';

	
	public static $TABLE_SELECTED_PATTERN = '(@TABLE_SELECTED)';
	public static $TABLE_COLLECTION_PATTERN = '(@TABLE_COLLECTION)';
	public static $TABLE_DATA_PATTERN = '(@FIELDS_QUERY)';
	
	public static $CAIRNGORM_TEMPLATE_LOCATION = 'templates/cairngorm/';
	public static $FLEX_TEMPLATE_LOCATION = 'templates/flex/';
	public static $PHP_TEMPLATE_LOCATION = 'templates/php/';
	public static $ECLIPSE_TEMPLATE_LOCATION = 'templates/eclipse/';
	public static $AS3_TEMPLATE_LOCATION = 'templates/as3/';

	public static $SERVER_OUTPUT = 'output/server/';
	public static $CLIENT_OUTPUT = 'output/client/';
	public static $CONFIG_OUTPUT = 'output/';	
	
}

?>