<?php/**  * I am a object representing the Locations_tags table. *  * @version 1.6 * @author Jonnie Spratley (http://jonniespratley.com/code) * * @package com.jonniespratley.test.VO * @name Locations_tagsVO.php */class Locations_tagsVO{	var $_explicitType = 'com.jonniespratley.test.VO.Locations_tagsVO';		
			public $id;
			public $location_id;
			public $tag_id;		public function __construct( $vo )	{		
			$this->id = $vo["id"];
			$this->location_id = $vo["location_id"];
			$this->tag_id = $vo["tag_id"];	}	}?>                                          