<?php/**  * I am a object representing the Test_entries_view table. *  * @version 1.6 * @author Jonnie Spratley (http://jonniespratley.com/code) * * @package com.jonniespratley.test.VO * @name Test_entries_viewVO.php */class Test_entries_viewVO{	var $_explicitType = 'com.jonniespratley.test.VO.Test_entries_viewVO';		
			public $id;
			public $entry_title;
			public $entry_body;
			public $location_id;
			public $user_id;
			public $upload_id;
			public $entry_created;		public function __construct( $vo )	{		
			$this->id = $vo["id"];
			$this->entry_title = $vo["entry_title"];
			$this->entry_body = $vo["entry_body"];
			$this->location_id = $vo["location_id"];
			$this->user_id = $vo["user_id"];
			$this->upload_id = $vo["upload_id"];
			$this->entry_created = $vo["entry_created"];	}	}?>                                          