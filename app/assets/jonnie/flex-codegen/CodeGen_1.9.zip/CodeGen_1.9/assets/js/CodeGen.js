$(function(){
	
	ChiliBook.recipeFolder = "assets/js/chili/";  
	ChiliBook.automatic = false; 
   ChiliBook.lineNumbers = true;
	
	$( "a.colorbox" ).colorbox( { width:"90%", height:"90%", iframe:true } );
   
	/* ======================================================================
    * init the tabs
    * ====================================================================== */
    $('#tabs').tabs();
	 $("#genAccordion").accordion();

	 $('.accordion .head').click(function() {
		$(this).next().toggle('slow');
		return false;
	}).next().hide();

	 /* ======================================================================
     * init the round corners
     * ====================================================================== */
    $('.round').corners('3px transparent');
 
	 /* ======================================================================
     * init all of the messages for hide/show
     * ====================================================================== */
    $("p.notice span").bind('click', function(){ // Whenever someone clicks the litte X on the notice message do the following
        $('p.notice').slideUp('slow'); // Fade out the whole paragraph
        $('p.notice span').hide('fast'); // And hide the X 
    });
    
    $("p.info span").bind('click', function(){
        $('p.info').slideUp('slow');
        $('p.info span').hide('fast');
    });
    
    $("p.success span").bind('click', function(){
        $('p.success').slideUp('slow');
        $('p.success span').hide('fast');
    });
    
    $("p.error span").bind('click', function(){
        $('p.error').slideUp('slow');
        $('p.error span').hide('fast');
    });
    
	
	 /* ======================================================================
     * init the progressbar
     * ====================================================================== */
    $("#progressbar").progressbar({
        value: 100
    });
    
	
	/* ======================================================================
     * init the carousel
     * ====================================================================== */
    $('#slider').jcarousel({
        start: 1,
        scroll: 1,
        wrap: 'both',
        buttonNextHTML: null,
        buttonPrevHTML: null,
        initCallback: slider_callback
    });
	 /* ======================================================================
     * carousel callback for controlling the views
     * ====================================================================== */
    function slider_callback(carousel){
        
        $('.1').bind('click', function(){
            carousel.scroll(1);
            return false;
        });
        $('.2').bind('click', function(){
            carousel.scroll(2);
            return false;
        });
        $('.3').bind('click', function(){
            carousel.scroll(3);
            return false;
        });
        $('.4').bind('click', function(){
            carousel.scroll(4);
            return false;
        });
        $('.5').bind('click', function(){
            carousel.scroll(5);
            return false;
        });
        $('.6').bind('click', function(){
            carousel.scroll(6);
            return false;
        });
    }
   
	$('#genSlider').jcarousel({
        start: 1,
        scroll: 1,
        wrap: 'both',
        buttonNextHTML: null,
        buttonPrevHTML: null,
        initCallback: genSlider_callback
    });
    function genSlider_callback(carousel)
	 {
	 	$('.next').bind('click', function(){
            carousel.next();
            return false;
        });
		  $('.prev').bind('click', function(){
            carousel.prev();
            return false;
        });
	 } 
	
});