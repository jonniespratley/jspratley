<?php 

//header('Content-type: application/x-json');

require_once 'library/MySQLService.php';
require_once 'library/Required.php';
require_once 'CodeGen.php';

//Service variables (internal)
$configMessage = '';
$schemaMessage = '';
$appMessage = '';
$configLocation = '';
$schemaLocation = '';
$appOutputLog = '';
$mode = '';

//REST Type of service sent from Flex
	if ( isset ( $_GET[ 'm' ] ) )
	{
		switch( $_GET[ 'm' ] )
		{
			case 'generateConfig':
				 $configLocation = CodeGen::writeConfig( 
				 $_GET[ 'h' ], //Host 
				 $_GET[ 'u' ], //User 
				 $_GET[ 'p' ], //Pass 
				 $_GET[ 'a' ], //Application 
				 $_GET[ 'd' ], //Database
				 $_GET[ 'e' ], //Endpoint
				 $_GET[ 'n' ] //Namespace
				 );
				
				 $xmlLocation = TemplateManager::$CONFIG_OUTPUT.ucfirst( $_GET['d'] ).'Config.xml';
				 $configLocation = TemplateManager::$CONFIG_OUTPUT.ucfirst( $_GET['d'] ).'Config.xml';
				 $dom = new DOMDocument();
				 $dom->load( $xmlLocation );
				 
				 foreach( $dom->getElementsByTagName('config') as $element )
				 {
				 	foreach( ( $element->childNodes ) as $e )
				 	{
				 		if ( is_a( $e, 'DOMElement' ) )
				 		{
				 			if ( $e->tagName == 'host' )
				 			{
				 				$host = $e->textContent;
				 			}
				 			if ( $e->tagName == 'user' )
				 			{
				 				$user = $e->textContent;
				 			}
				 			if ( $e->tagName == 'pass' )
				 			{
				 				$pass = $e->textContent;
				 			}
				 			if ( $e->tagName == 'database' )
				 			{
				 				$schema = $e->textContent;
				 			}
				 			if ( $e->tagName == 'application' )
				 			{
				 				$app = $e->textContent;
				 			}
				 			if ( $e->tagName == 'namespace' )
				 			{
				 				$namespace = $e->textContent;
				 			}
				 			if ( $e->tagName == 'endpoint' )
				 			{
				 				$endpoint = $e->textContent;
				 			}
				 		}
				 	}
				 }
				 $voArray[] = array( 
				 'host' => $host, 
				 'username' => $user, 
				 'password' => $pass, 
				 'database' => $schema, 
				 'application' => $app,
				 'namespace' => $namespace,
				 'endpoint' => $endpoint
				  );
				 echo json_encode( $voArray );
				
				//echo $configMessage;
				
			break;
			
			case 'generateSchema':
				$codegen = new CodeGen( $configLocation );
				$schemaLocation = $codegen->writeSchema();
				if ( $schemaLocation )
				{
					$schemaMessage = 'Schema file written.';
				}
				
			break;
			
			case 'generateApplication':
				$codegen = new CodeGen( $configLocation );
				$appOutputLog = $codegen->generateCode( $_GET['txt_schemaLocation'] );
				$appMessage = 'Application written. 
				<li>a. All php service files for all database tables</li>
			 	<li>b. All php value object files for all database tables</li>
			 	<li>c. All flex value object files for all database tables</li>
			 	<li>d. All flex table testers that have a datagrid and form, with all services calls.</li>
			 	<li>e. All config files, connection files, and namespace folders.</li>
				<li>Just drop inside the services folder of your amfphp installation, and your ready to roll.</li>
			 	<li>Server side gets generated into the output/server folder.</li>
			 	<li>Client side get generated into the output/client folder.</li>';	
			break;
			
			case 'getDatabases':
				$service = new MySQLService( $_GET[ 'h' ], $_GET[ 'u' ], $_GET[ 'p' ] );
				$databases = $service->getDatabases();
				
				print $databases;
			break;
			
			case 'getConfig':
				$config = file_get_contents( $configLocation ); 
			
				print $config;
			break;
			
			case 'getSchema':
				$schema = file_get_contents( TemplateManager::$CONFIG_OUTPUT. ucfirst( $_GET['d'] ).'Schema.xml' ); 
				print $schema;
			break;
			
			case 'getTemplates':
				$filesSvc = new FileSystemService();
				$templates = $filesSvc->browseDirectory( 'templates/', true );
				//echo '<pre>';
				//print_r( $templates );
				//echo '</pre>';
				echo json_encode( $templates );
			break;
			
			case 'getDirectory':
				$filesSvc = new FileSystemService();
				$templates = $filesSvc->browseDirectory( 'templates/', true );
	
				print $templates;
			break;
		
			case 'readFile':
				$filesSvc = new FileSystemService();
				$file = $filesSvc->readFile( $_GET['f'] );
			
				echo htmlentities( $file );
			break;
			
			case 'writeFile':
				$filesSvc = new FileSystemService();
				$file = $filesSvc->writeFile( $_GET['f'], base64_decode( $_GET['c'] ) );
			
				print $file;
			break;
			
			
			
			
			
		}
	}

?>       