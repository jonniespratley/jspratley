<?php

class SQLGenerator
{
	public $database;
	public $table;
	public $conditions = array();
	public $query;
	public $limit;
	public $offset;
	public $empty = '';
	public $fields;
	
	public function SQLGenerator( $database, $table, $conditions = '' )
	{
		$this->database = $database;
		$this->table = $table;
		
		if ( $conditions != '' && is_array( $conditions ) == false )
		{
			$conditions = explode(",", $conditions );
		}
		
		
		if ( is_array( $conditions ) )
		{
			foreach ( $conditions as $condition )
			{
				$this->setCondition( $condition );
			}
		}
	}
	

/* ******************************************************************** 
 *  Query Builder
 * INSERT INTO `test`.`types` ( `type_title`, `user_id` ) VALUES ( 'sit', '78' );
 * *********************************************************************/
	public function generateQuery( $type )
	{
		
		switch( $type )
		{
			case 'insert':
				$this->query = "INSERT INTO $this->database.$this->table SET ". $this->getKeys();
				//$this->query = "INSERT INTO `$this->database`.`$this->table`  SET ( $this->getKeys() )"; 
			break;
			case 'update':
				$this->query = "UPDATE `". $this->database. "`.`" .$this->table ."` WHERE ". $this->getKeys();	
			break;			
			case 'delete':
				$this->query = "DELETE FROM `". $this->database. "`.`" .$this->table ."` WHERE ". $this->getConditions();
			break;
			case 'select':
				$this->query = "SELECT ". $this->getFields() ." FROM `". $this->database. "`.`" .$this->table ."` WHERE ". $this->getConditions() ."LIMIT ". $this->limit;
			break;
			default:
				//Error
			exit();	
		}
		return $this->query;
	}
	
/* ******************************************************************** 
 *  GETTERS
 * *********************************************************************/
	
	public function getKeys()
	{
		$value = array();
		
		//For each field set up the fieldname and field value
		foreach ( $this->fields as $fname => $fvalue )
		{
			//push into the value array the field name equals(=) escaped field value, wrapped in ticks(`). 
			array_push( $value, " $fname = '". addslashes( $fvalue ) ."' " );
		}
		
		//Return the pushed array splitting it at the comma (,);
		return implode( ",", $value );
	}
	
	public function getValues()
	{
		$value = array();
		
		//For each field set up the fieldname and field value
		foreach ( $this->fields as $fname => $fvalue )
		{
			//push into the value array the field name equals(=) escaped field value, wrapped in ticks(`). 
			array_push( $value, " $fname = '". addslashes( $fvalue ) ."' " );
		}
		
		//Return the pushed array splitting it at the comma (,);
		return implode( ",", $value );
	}
	
	public function getConditions()
	{
		$newConditions = '';
		
		//Check to see if the variable conditions is an array, and is greater than zero(0) if it is
		//then return the build conditions
		if( is_array( $this->conditions ) && count( $this->conditions ) > 0 )
		{
			//build the conditions for sql, 
			$newConditions = "((". implode( ') AND (', $this->conditions ) ."))";
		} else {
			return false;
		}
		return $newConditions;
	}
	
	public function getFields()
	{
		return implode( ",", array_keys( $this->fields ) );
	}
	
/* ******************************************************************** 
 *  SETTERS
 * *********************************************************************/
	public function setFields( $theFields )
	{
		$this->fields = $theFields;
	}
	
	public function setCondition( $condition )
	{
		array_push( $this->conditions, $condition );
	}
	
	public function setTable( $tableName )
	{
		$this->table = $tableName;
	}
	
	public function setDatabase( $databaseName )
	{
		$this->database = $databaseName;
	}
	
	public function setLimit( $limitNum )
	{
		$this->limit = $limitNum;
	}
	
	public function setOffset( $offsetNum )
	{
		$this->offset = $offsetNum;
	}
	
	public function setValueKey( $key, $value = '' )
	{
		if ( is_array( $key ) )
		{
			$this->fields = array_merge( $this->fields, $key );
		} else {
			$this->fields[ $key ] = $value;
		}
	}



	
	
	
	
	
	
	
	
	
	
	
}

?>