<?php 
/**
 * @name  	CairngormGen.php
 * @author  Jonnie Spratley
 * @version 1.9
 * @method generateController - Creates Controller.as
 * @method generateDelegate - Creates Delegate.as
 * @method generateServiceLocator - Creates Services.mxml
 * @method generateModelLocator - Creates ModelLocator.as
 * @method generateValueObject - Creates TableVO.as
 * @method generateSaveEvent - Creates TableSaveEvent.as
 * @method generateSaveCommand - Creates TableSaveCommand.as
 * @method generateRemoveEvent - Creates TableRemoveEvent.as
 * @method generateRemoveCommand - Creates TableRemoveCommand.as
 * @method generateGetEvent - Creates TableGetEvent.as
 * @method generateGetCommand - Creates TableGetCommand.as
 *
 */
 
require_once 'TemplateManager.php';
require_once 'FileSystemService.php';

require_once 'Utilities.php';

class CairngormGen {
    private $options;
    
    public function __construct($options) {
        $this->options = $options;
    }
    
    public function generateController($tables) {
        $eventsToCommands = '';
        
        foreach ($tables as $table) {
            $eventsToCommands .= '
			this.addCommand( Get'.$table["name"].'Event.GET_'.strtoupper($table["name"]).'_EVENT, Get'.$table["name"].'Command );
			this.addCommand( Remove'.$table["name"].'Event.REMOVE_'.strtoupper($table["name"]).'_EVENT, Remove'.$table["name"].'Command );
			this.addCommand( Save'.$table["name"].'Event.SAVE_'.strtoupper($table["name"]).'_EVENT, Save'.$table["name"].'Command );
			';
        }
        
        $tableServiceTemplate = FileSystemService::readFile(TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'CairngormController.txt');
        
        $template = preg_replace(TemplateManager::$NAMESPACE_PATTERN, $this->options['namespace'], $tableServiceTemplate);
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        $template = preg_replace(TemplateManager::$APPLICATION_PATTERN, $this->options['application'], $template);
        $template = preg_replace(TemplateManager::$EVENT_COMMAND_PATTERN, $eventsToCommands, $template);
        
        $filename = ucfirst($this->options['application']).'Controller.as';

        
        //return 'Cairngorm Controller for ' . $application . ' Complete';
        return array(
            'filename'=>$filename, 'contents'=>$template, 'lang'=>'as-cairngorm', 'type'=>'controller'
            
        );
    }
    
    public function generateDelegate($table, $fields) {
        $tableUFirst = ucfirst($table);
        
        $filename = $tableUFirst.'ServiceDelegate.as';
        
        $tableServiceTemplate = FileSystemService::readFile(TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'CairngormDelegateREST.txt');

        
        $template = preg_replace(TemplateManager::$TABLE_UFIRST_PATTERN, $tableUFirst, $tableServiceTemplate);
        
        $template = preg_replace(TemplateManager::$NAMESPACE_PATTERN, $this->options['namespacee'], $template);
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        
        //return 'Cairngorm Service Delegate for ' . $tableUFirst . ' Complete';
        return array(
            'filename'=>$filename, 'contents'=>$template, 'lang'=>'as-cairngorm', 'type'=>'delegate'
        );
    }
    
    public function generateServiceLocator($tables) {
        $filename = 'Services.mxml';
        $serviceLocator = '';
        
        /**
         *  <mx:HTTPService
         id="CodeGenService"
         url="library/FlexService.php"
         useProxy="false"
         showBusyCursor="true"/>
         */
         
        foreach ($tables as $table) {
            $tableUFirst = ucfirst($table['name']);
            /*
             $serviceLocator .= '
             <mx:RemoteObject
             id="' . $tbl [ 'name' ] . 'Service"
             destination="amfphp"
             endpoint="' . $endpoint . '"
             source="' . $namespace . '.' . $tbl [ 'name' ] . 'Service"
             showBusyCursor="true"
             makeObjectsBindable="true">
             </mx:RemoteObject>';
             */
            $serviceLocator .= '
			<mx:HTTPService
    			id="'.$tableUFirst.'Service"
    			url="'.$this->options['endpoint'].'/'.$tableUFirst.'Service.php"
    			useProxy="false"
    			showBusyCursor="true"/>
			';
			
        }
        
        $tableServiceTemplate = FileSystemService::readFile(TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'CairngormServiceLocatorREST.txt');
        
        $template = preg_replace(TemplateManager::$NAMESPACE_PATTERN, $this->options['namespacee'], $tableServiceTemplate);
        $template = preg_replace(TemplateManager::$ENDPOINT_PATTERN, $this->options['endpoint'], $template);
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        $template = preg_replace(TemplateManager::$TABLE_UFIRST_PATTERN, $serviceLocator, $template);
        
        //return 'Cairngorm Service Locator for ' . $database . ' Complete';
        return array(
            'filename'=>$filename, 'contents'=>$template, 'lang'=>'as-cairngorm', 'type'=>'servicelocator'
        );
    }
    
    public function generateModelLocator($tables) {
        $filename = 'ModelLocator.as';
        $collectionsStr = '';
        
        foreach ($tables as $table) {
        
            $collections .= '
			public var '.ucfirst($table['name']).'Collection:ArrayCollection = new ArrayCollection();
			public var selected'.ucfirst($table['name']).':'.ucfirst($table['name']).'VO;
			';
        }
        
        $tableModelTemplate = FileSystemService::readFile(TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'CairngormModel.txt');
        
        $template = preg_replace(TemplateManager::$TABLE_UFIRST_PATTERN, $collectionsStr, $tableModelTemplate);
        $template = preg_replace(TemplateManager::$NAMESPACE_PATTERN, $this->options['namespacee'], $template);
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        
        //return 'Cairngorm Model Locator for ' . $database . ' Complete';
        return array(
            'filename'=>$filename, 'contents'=>$template, 'lang'=>'as-cairngorm', 'type'=>'model'
        );
    }
    
    public function generateValueObject($table, $fields) {
        $tableUFirst = ucfirst($table);
        
        $fieldVars = '';
        $fieldsCon = '';
        $fieldsQuery = '';
        
        foreach ($fields as $field) {
            $fieldVars .= '
			public var '.$field['name'].':String;';
			
            $fieldsCon .= '
			this.'.$field['name'].' = obj["'.$field['name'].'"];';
			
            $fieldsQuery .= '"&'.$field['name'].'=" + '.$field['name'].' + ';
            
        }
        $fieldsQuery = Utilities::trim($fieldsQuery, 2);
        
        $tableVoTemplate = FileSystemService::readFile(TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'CairngormValueObject.txt');
        $template = preg_replace(TemplateManager::$TABLE_UFIRST_PATTERN, $tableUFirst, $tableVoTemplate);
        
        $template = preg_replace(TemplateManager::$FIELD_VARS_PATTERN, $fieldVars, $template);
        $template = preg_replace(TemplateManager::$FIELDS_PATTERN, $fieldsCon, $template);
        $template = preg_replace(TemplateManager::$FIELDS_QUERY_PATTERN, $fieldsQuery, $template);
        
        $template = preg_replace(TemplateManager::$NAMESPACE_PATTERN, $this->options['namespacee'], $template);
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        
        $filename = $tableUFirst.'VO.as';
        
        //return 'Value Object for' . $tableUFirst . ' Complete';
        return array(
            'filename'=>$filename, 'contents'=>$template, 'lang'=>'as-cairngorm', 'type'=>'vo'
        );
    }
    
    public function generateSaveEvent($table) {
    
        $tableUFirst = ucfirst($table);
        
        //Create the fileame
        $filename = 'Save'.$tableUFirst.'Event.as';

        
        $tableSaveTemplate = FileSystemService::readFile(TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'CairngormSaveEvent.txt');
        $template = preg_replace(TemplateManager::$TABLE_UFIRST_PATTERN, $tableUFirst, $tableSaveTemplate);
        
        $template = preg_replace(TemplateManager::$NAMESPACE_PATTERN, $this->options['namespacee'], $template);
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        $template = preg_replace(TemplateManager::$EVENT_CONST, strtoupper($table), $template);
        
        //return 'Cairngorm Event for ' . $tableUFirst . ' Complete';
        return array(
            'filename'=>$filename, 'contents'=>$template, 'lang'=>'as-cairngorm', 'type'=>'event'
        );
    }
    
    public function generateSaveCommand($table) {
        $tableUFirst = ucfirst($table);
        
        $filename = 'Save'.$tableUFirst.'Command.as';
        
        $tableService = FileSystemService::readFile(TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'CairngormSaveCommand.txt');
        
        $template = preg_replace(TemplateManager::$TABLE_UFIRST_PATTERN, $tableUFirst, $tableService);
        $template = preg_replace(TemplateManager::$NAMESPACE_PATTERN, $this->options['namespacee'], $template);
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        
        return array(
            'filename'=>$filename, 'contents'=>$template, 'lang'=>'as-cairngorm', 'type'=>'command'
        );
    }
    
    public function generateRemoveEvent($table) {
        $tableUFirst = ucfirst($table);
        
        $filename = 'Remove'.$tableUFirst.'Event.as';
        
        $tableRemoveTemplate = FileSystemService::readFile(TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'CairngormRemoveEvent.txt');
        
        $template = preg_replace(TemplateManager::$TABLE_UFIRST_PATTERN, $tableUFirst, $tableRemoveTemplate);
        $template = preg_replace(TemplateManager::$EVENT_CONST, strtoupper($table), $template);
        
        $template = preg_replace(TemplateManager::$NAMESPACE_PATTERN, $this->options['namespacee'], $template);
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        
        return array(
            'label'=>$filename, 'contents'=>$template, 'lang'=>'as-cairngorm', 'type'=>'event'
        );
    }
    
    public function generateRemoveCommand($table) {
        $tableUFirst = ucfirst($table);
        
        $filename = 'Remove'.$tableUFirst.'Command.as';
        
        $tableRemoveTemplate = FileSystemService::readFile(TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'CairngormRemoveCommand.txt');
        
        $template = preg_replace(TemplateManager::$TABLE_UFIRST_PATTERN, $tableUFirst, $tableRemoveTemplate);
        $template = preg_replace(TemplateManager::$NAMESPACE_PATTERN, $this->options['namespacee'], $template);
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        
        return array(
            'filename'=>$filename, 'contents'=>$template, 'lang'=>'as-cairngorm', 'type'=>'command'
        );
    }
    
    public function generateGetEvent($table) {
        $tableUFirst = ucfirst($table);
        
        $filename = 'Get'.$tableUFirst.'Event.as';
        
        $tableGetTemplate = FileSystemService::readFile(TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'CairngormGetEvent.txt');
        
        $template = preg_replace(TemplateManager::$TABLE_UFIRST_PATTERN, $tableUFirst, $tableGetTemplate);
        $template = preg_replace(TemplateManager::$EVENT_CONST, strtoupper($table), $template);
        
        $template = preg_replace(TemplateManager::$NAMESPACE_PATTERN, $this->options['namespacee'], $template);
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        
        return array(
            'filename'=>$filename, 'contents'=>$template, 'lang'=>'as-cairngorm', 'type'=>'event'
        );
    }
    
    public function generateGetCommand($table) {
        $tableUFirst = ucfirst($table);
        
        $filename = 'Get'.$tableUFirst.'Command.as';
        
        $tableGetTemplate = FileSystemService::readFile(TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'CairngormGetCommand.txt');
        
        $template = preg_replace(TemplateManager::$TABLE_UFIRST_PATTERN, $tableUFirst, $tableGetTemplate);
        $template = preg_replace(TemplateManager::$EVENT_CONST, strtoupper($table), $template);
        
        $template = preg_replace(TemplateManager::$NAMESPACE_PATTERN, $this->options['namespacee'], $template);
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        
        return array(
            'filename'=>$filename, 'contents'=>$template, 'lang'=>'as-cairngorm', 'type'=>'command'
        );
    }
    
}

?>
