<div class="title">
	<h2>Manage</h2>
</div>
<div class="box round">
	<h3>Template Manager</h3>
	<table>
		<tr>
			<td  align="left" valign="top" id="editorSidebar" scope="col" width="20%">
				<ul id="fileTree"></ul>
			</td>
			<td  align="left" valign="top" id="editorSource" scope="col" width="80%">
				<pre id="code"></pre>
			</td>
		</tr>
		<tr>
			<td scope="col">&nbsp;</td>
			<td id="editorToolbar" scope="col"></td>
		</tr>
	</table>
</div>
