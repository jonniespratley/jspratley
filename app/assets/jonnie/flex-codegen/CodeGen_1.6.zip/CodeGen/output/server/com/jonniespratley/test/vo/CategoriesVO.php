<?php/**  * I am a object representing the Categories table. *  * @version 1.6 * @author Jonnie Spratley (http://jonniespratley.com/code) * * @package com.jonniespratley.test.VO * @name CategoriesVO.php */class CategoriesVO{	var $_explicitType = 'com.jonniespratley.test.VO.CategoriesVO';		
			public $category_id;
			public $category_name;		public function __construct( $vo )	{		
			$this->category_id = $vo["category_id"];
			$this->category_name = $vo["category_name"];	}	}?>                                          