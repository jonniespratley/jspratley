</div><!-- ends #content -->
<div id="footer">
	<p>Copywrite 2009 | CodeGenTest</p>
</div><!-- ends #footer -->
</div><!-- ends #container -->
</body>
</html>