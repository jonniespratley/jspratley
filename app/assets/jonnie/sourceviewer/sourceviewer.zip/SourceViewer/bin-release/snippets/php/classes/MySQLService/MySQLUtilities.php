<?php

class MySQLUtilities
{
	
	public function __construct()
	{
	
	}
	
	/**
	 * I format debug dumps
	 *
	 * @param [var] the variable you with to dump
	 */
	public function dumpIt( $var )
	{
		print "<pre>\n";
		print_r ( $var );
		print "</pre>\n";
	}
	
	/**
	 * I make a formatted timestamp.
	 * <code> 
	 * 2008-12-30 22:40:00
	 * </code>
	 *
	 * @return [string] a timestamp
	 */
	private function makeTimestamp()
	{
		$time = time ();
		
		return date ( 'm-d-Y-H-i', $time );
	}
	
	/**
	 * I format uptime from MySQL
	 *
	 * @param [int] $time the old time
	 * @return [string] the new time
	 */
	private function _formatUptime( $time = 0 )
	{
		$days = ( int ) floor ( $time / 86400 );
		$hours = ( int ) floor ( $time / 3600 ) % 24;
		$minutes = ( int ) floor ( $time / 60 ) % 60;
		
		if ( $days == 1 )
		{
			$uptime = "$days day, ";
		}
		else if ( $days > 1 )
		{
			$uptime = "$days days, ";
		}
		if ( $hours == 1 )
		{
			$uptime .= "$hours hour";
		}
		else if ( $hours > 1 )
		{
			$uptime .= "$hours hours";
		}
		if ( $uptime && $minutes > 0 && $seconds > 0 )
		{
			$uptime .= ", ";
		}
		else if ( $uptime && $minutes > 0 & $seconds == 0 )
		{
			$uptime .= " and ";
		}
		( $minutes > 0 ) ? $uptime .= "$minutes minute" . ( ( $minutes > 1 ) ? "s" : NULL ) : NULL;
		
		return $uptime;
	}
	
	/**
	 * I try and throw an error.
	 *
	 * @param [string] $msg the message of the mess
	 * @param [string] $type the type of error
	 * @return error
	 */
	private function _throwError( $msg, $type )
	{
		switch ( $type )
		{
			case 'user' :
				throw ErrorException ();
				break;
			
			case 'error' :
				return trigger_error ( $msg, E_ERROR );
				break;
			
			case 'other' :
				return trigger_error ( $msg, E_USER_ERROR );
				break;
		}
		return trigger_error ( $msg, E_USER_ERROR );
	}
	
}

?>