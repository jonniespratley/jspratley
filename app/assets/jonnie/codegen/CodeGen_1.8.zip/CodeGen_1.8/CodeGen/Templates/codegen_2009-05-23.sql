# Sequel Pro dump
# Version 663
# http://code.google.com/p/sequel-pro
#
# Host: localhost (MySQL 5.0.41)
# Database: codegen
# Generation Time: 2009-05-23 15:54:03 -0700
# ************************************************************

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table posts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `posts`;

CREATE TABLE `posts` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(225) default 'None',
  `body` text,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `user_id` int(11) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=123 DEFAULT CHARSET=latin1;

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` (`id`,`title`,`body`,`date`,`user_id`)
VALUES
	(90,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:14:12',0),
	(91,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:14:14',0),
	(92,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:14:49',0),
	(93,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:14:49',0),
	(94,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:18:53',0),
	(95,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:19:09',0),
	(96,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:19:13',0),
	(97,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:19:15',0),
	(98,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:19:15',0),
	(99,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:19:16',0),
	(100,'This record just got updated','Dont you just love oo programming?','2009-05-17 19:20:33',0),
	(101,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:19:16',0),
	(102,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:19:17',0),
	(103,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:19:17',0),
	(104,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:19:35',0),
	(105,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:28:47',0),
	(106,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:28:49',0),
	(107,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:28:50',0),
	(108,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:28:54',0),
	(109,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:33:02',0),
	(110,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:34:33',0),
	(111,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:35:24',0),
	(112,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:35:38',0),
	(113,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:35:47',0),
	(114,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:36:13',0),
	(115,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:36:28',0),
	(116,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:40:20',0),
	(117,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:40:53',0),
	(118,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:42:09',0),
	(119,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:43:22',0),
	(120,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:43:26',0),
	(121,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:43:31',0),
	(122,'This is a new post','I really dont know what to say here but I like angels and airwaves','2009-05-17 19:44:10',0);

/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(255) default 'none',
  `name` varchar(255) default 'Joe',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`,`email`,`name`)
VALUES
	(1,'ruby@gmail.com','Ruby'),
	(2,'rio@gmail.com','Rio'),
	(3,'jonnie@gmail.com','Jonnie'),
	(4,'jonniedollas@gmail.com','Jonnie'),
	(5,'jonniedollas@gmail.com','Jonnie');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;





/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
