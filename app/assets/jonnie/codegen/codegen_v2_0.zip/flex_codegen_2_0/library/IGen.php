<?php
interface IGen
{
	function generate();
}
?>