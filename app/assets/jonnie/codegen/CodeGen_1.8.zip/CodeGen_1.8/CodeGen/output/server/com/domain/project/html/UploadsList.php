<?php 
require_once '../UploadsService.php';
require_once '../vo/UploadsVO.php';

$service = new UploadsService();
$result = '';
$recordList = '';

if ( isset($_POST['save']) )
{
	unset( $_POST['save'] );
	$recordValues = $_POST;
	$result = $service->saveUploads( $recordValues );	
}

$recordsArray = $service->getAllUploads();
$recordVO = new UploadsVO();

for ( $i = 0; $i < count( $recordsArray ); $i++ ) 
{
	$recordVO = $recordsArray[ $i ];
	
	$recordList .= '<tr id="'.$recordVO->id.'">';

	
			$recordList .= "<td>$recordVO->id</td>";
			$recordList .= "<td>$recordVO->upload_name</td>";
			$recordList .= "<td>$recordVO->upload_size</td>";
			$recordList .= "<td>$recordVO->upload_type</td>";
			$recordList .= "<td>$recordVO->user_id</td>";

	$recordList .= '<td class="actions">';
	$recordList .= '<button class="edit" onclick="window.location=\'UploadsForm.php?id='.$recordVO->id.'\'">Edit</button>';
	$recordList .= '<button class="delete" onclick=" remove('.$recordVO->id.')">Delete</button></td>';
	$recordList .= '</tr>';
}

?>
<?php include '_header.php'; ?> 

<script type="text/javascript">
var service = '../UploadsService.php';

function remove( id ){
	$.get( service, { m: 'remove', id: id }, function(data){
		if ( data ) {
			$('#'+id).fadeOut('slow');
		} else {
			alert( 'There was a problem!' );
		}
	});
}
</script>

<h3>Uploads</h3>

    <table width="100%" border="0">
	<tr>
		
			<th scope="col">id</th>
			<th scope="col">upload_name</th>
			<th scope="col">upload_size</th>
			<th scope="col">upload_type</th>
			<th scope="col">user_id</th><th scope="col">Actions</th>   
    </tr>
       <?php echo $recordList; ?>
    </table>
    
    <a href="UploadsForm.php">New Uploads</a>
  
 <?php include '_footer.php'; ?>