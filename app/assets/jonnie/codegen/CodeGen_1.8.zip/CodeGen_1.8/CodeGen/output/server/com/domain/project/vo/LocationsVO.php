<?php/**                    My Test Application
                *//**  * I am a object representing the @TABLE table. *  * @version CodeGen - 1.8 * @author CodeGen - Jonnie Spratley (http://jonniespratley.com/code) * * @package com.domain.project.VO * @name LocationsVO.php */class LocationsVO{	/* Official boycott on amphp, because its trash */	//public $_explicitType = 'com.domain.project.vo.LocationsVO';		
			public $id;
			public $loc_address;
			public $loc_city;
			public $loc_country;
			public $loc_created;
			public $loc_date;
			public $loc_guests;
			public $loc_state;
			public $loc_title;
			public $loc_zip;
			public $map_id;
			public $type_id;
			public $user_id;		public function __construct(){}		public function mapObject( $vo )	{		
			$this->id = $vo["id"];
			$this->loc_address = $vo["loc_address"];
			$this->loc_city = $vo["loc_city"];
			$this->loc_country = $vo["loc_country"];
			$this->loc_created = $vo["loc_created"];
			$this->loc_date = $vo["loc_date"];
			$this->loc_guests = $vo["loc_guests"];
			$this->loc_state = $vo["loc_state"];
			$this->loc_title = $vo["loc_title"];
			$this->loc_zip = $vo["loc_zip"];
			$this->map_id = $vo["map_id"];
			$this->type_id = $vo["type_id"];
			$this->user_id = $vo["user_id"];	}		public function setNamespace( $namespace )	{		$this->explicitType = $namespace;	}		public function __get( $name )	{		return $this->$name;	}		public function __set( $name, $value )	{		$this->$name = $value;	}	}?>                                          