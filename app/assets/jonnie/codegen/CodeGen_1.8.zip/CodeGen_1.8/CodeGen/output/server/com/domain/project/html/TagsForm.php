<?php 
require_once '../TagsService.php';
require_once '../vo/TagsVO.php';


			$id = "";
			$tag_title = "";
			$user_id = "";
$id = '';

if ( $_GET['user_id'] )
{
	$id = $_GET['user_id'];
	$service = new TagsService();
	$recordVO = new TagsVO();
	$record = $service->getOneTags( $id ); 
	$recordVO = $record[0];//First object in array
	
	
			$id = $recordVO->id;
			$tag_title = $recordVO->tag_title;
			$user_id = $recordVO->user_id;
	
	
}
?>
<?php include '_header.php'; ?>
<form id="formTags" name="formTags" method="post" action="TagsList.php">
	 
	
	
			<div>
		 		<label for="id">Id</label>
		 		<input type="text" name="id" value="<?php echo $id; ?>"/>
		 	</div>
			<div>
		 		<label for="tag_title">Tag_title</label>
		 		<input type="text" name="tag_title" value="<?php echo $tag_title; ?>"/>
		 	</div>
			<div>
		 		<label for="user_id">User_id</label>
		 		<input type="text" name="user_id" value="<?php echo $user_id; ?>"/>
		 	</div>
    
    <div>
    	<input type="hidden" name="user_id" value="<?php echo $id; ?>"/>
	   <input name="save" type="submit" value="Save" />
		<button onclick="window.location='TagsList.php'">Back</button>
    </div>
</form>
 <?php include '_footer.php'; ?>