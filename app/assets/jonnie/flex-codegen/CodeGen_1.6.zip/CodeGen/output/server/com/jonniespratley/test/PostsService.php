<?php

require_once ( 'Connection.php' );
require_once ( 'vo/PostsVO.php' );

/**
 * I am the Database Access Layer, I can manipulate the database.
 * 
 * @version 1.6
 * @author Jonnie Spratley (http://jonniespratley.com/code)
 *
 * @package com.jonniespratley.test
 * @name PostsService.php
 */
class PostsService
{
	private $conn;
	
	/**
	 * I am the instance of a Database Access Object
	 *
	 * @return [link]
	 */
	public function __construct()
	{
		//TODO: need to enter in the proper credentials
		$conn = new Connection ();
		$this->conn = $conn;
	}
	 
	/**
	 * I get all records from the specified database and table
	 * @return [array]
	 */
	public function getAllPosts()
	{
		return $this->_executeReturn ( "SELECT * FROM test.posts" );
	}
	
	/**
	 * I get one record from the specified database and table.
	 *
	 * @param [string] $keyvalue the value of your request
	 * @return [array] the matching record
	 */
	public function getOnePosts( $keyvalue )
	{
		return $this->_executeReturn ( "SELECT * 
										FROM test.posts 
										WHERE ".$this->_getKey()." = $keyvalue" );
	}
	
	/**
	 * I save a record to the specified database and table
	 * @param [string] $vo the name/value object
	 * @return [array] the inserted record
	 */
	public function savePosts( $vo )
	{
		$choice = '';
		
		$primarykey = $this->_getKey();
		$primarykeyValue = $vo[ $primarykey ];
	
		if ( $primarykeyValue == 0 || $primarykeyValue == '' )
		{
			$choice = $this->createPosts( $vo );
		}
		else
		{
			$choice = $this->updatePosts( $vo );
		}
		return $choice;
	}
	
	/**
	 * I update a record in the database/table
	 *
	 * @param [string] $vo the name/value object
	 * @return [array] the inserted object
	 */
	private function updatePosts( $vo )
	{
		$postsVO = new PostsVO ( $vo );
		
		//get the primary key
		$key = $this->_getKey();
		
		//value of the key
		$keyvalue = '';
		
		//check if the object has a key with the same value as the primary key
		if ( array_key_exists( $key, $vo ) )
		{
			//set the keyvalue variable to the array key inside the object, 
			//the key should be the same name as the key in the table
			$keyvalue = $vo[ $key ];
		}
	
		//build the query
		$sql = "UPDATE test.posts 
				SET 
				id = ".$this->_prepare( $postsVO->id).", title = ".$this->_prepare( $postsVO->title).", excerpt = ".$this->_prepare( $postsVO->excerpt).", body = ".$this->_prepare( $postsVO->body)."
				WHERE $key = '$keyvalue'";
				
		return $this->_execute( $sql );
	}
	
	/**
	 * I create a new record in the database/table
	 *
	 * @param [string] $vo the name/value object
	 * @return [boolean] the inserted object
	 */
	private function createPosts( $vo )
	{
		$columns = '';
		$values = '';
		
		foreach( $vo as $column => $value )
		{
			if ( $column != '_explicitType' )
			{
				$columns .= $column.', ';
				$values .= $this->_prepare( $value ).', ';
			}
		}
		
		//trim off the last command and space
		$columns = substr( $columns, 0, strlen( $columns ) - 2 );
		$values = substr( $values, 0, strlen( $values ) - 2 );
		
		//build the query
		$sql = "INSERT test.posts 
				( $columns ) 
				VALUES 
				( $values )";
				
		return $this->_execute( $sql );
	}
	
	/**
	 * I remove a record from the specified database/table
	 *
	 * @param [string] $keyvalue the value of the key
	 * @return [boolean] the result
	 */
	public function removePosts( $vo )
	{
		$keyvalue = $vo[ $this->_getKey() ];
		
		return $this->conn->execute( "DELETE 
									  FROM test.posts 
									  WHERE ".$this->_getKey()." = '$keyvalue'" );
	}
	
	/**
	 * I get the primary key for table.
	 *
	 * @return [string] the name of the primary key
	 */
	private function _getKey()
	{
		$keys = $this->conn->executeAndReturn( "SHOW INDEX FROM test.posts" );
		$primaryKey = '';
		
		foreach( $keys as $key )
		{
			if ( $key['Key_name'] == 'PRIMARY' )
			{
				$primaryKey = $key['Column_name'];
			}
		}
		return $primaryKey;
	}
	
	/**
	 * I map the resulting recordset to a @TABLE object.
	 *
	 * @param [result] a result from a database query
	 * @return [array] an array of Posts objects
	 */
	private function _mapObjectToPosts( $obj )
	{
		$array = array ();
		while ( $row = mysqli_fetch_assoc ( $obj ) )
		{
			$vo = new PostsVO ( $row );
			$array [] = $vo;
		}
		return $array;
	}
	
	/**
	 * I execute a statment on the database, and return a array of
	 * @TABLE objects.
	 *
	 * @param [string] the query string to execute
	 * @return [array] array of Posts objects
	 */
	private function _executeReturn( $sql )
	{
		$query = $this->conn->execute ( $sql );
		
		if ( $query )
		{
			return $this->_mapObjectToPosts( $query );
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * I execute a raw query and return the result.
	 * @param [string] $sql the query
	 */
	private function _execute( $sql )
	{
		return $this->conn->execute ( $sql );
	}
	
	/**
	 * I prepare a insertion string.
	 * @param [string] $value the value to be sqlified
	 */
	private function _prepare( $value )
	{
		return "'$value'";
	}
	
	
}
?>