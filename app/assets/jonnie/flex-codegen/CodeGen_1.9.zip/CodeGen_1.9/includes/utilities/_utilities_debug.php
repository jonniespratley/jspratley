<div class="box round">
	<h3>Debug</h3>
	<button class="getCookie">Get Cookie</button>
	<button class="setCookie">Set Cookie</button>
	<button class="deleteCookie">Delete Cookie</button>
	<form>
		<p>
			<button class="getHistoryCookie">Get History Cookie</button>
		</p>
		<p>
			<button class="deleteHistoryCookie">Delete History Cookie</button>
		</p>
		<p>
			<label>App Name:</label>
			<input id="appName" type="text"/></p><p>
			<label>App URL</label>
			<input id="appURL" type="text"/></p><p>
			<button class="setHistoryCookie">Set History Cookie</button>
		</p>
	</form>
	<div id="debug">
		
		
		
	</div>
</div>
