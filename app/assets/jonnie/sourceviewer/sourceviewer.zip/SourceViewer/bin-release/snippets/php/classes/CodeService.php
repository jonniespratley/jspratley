<?php

class CodeService
{
	
	public $mysqli;
	
	/**
	 * I hold methods to alter a mysql database
	 *
	 * @param [string] $host
	 * @param [string] $username
	 * @param [string] $password
	 */
	public function __construct( $host, $username, $password )
	{
		$link = new mysqli ( $host, $username, $password );
		
		/* check connection */
		if ( mysqli_connect_errno () )
		{
			trigger_error ( 'Database connection failure: Username/Password was incorrect.', E_USER_ERROR );
			exit ();
		}
		else
		{
			$this->setMysqli ( $link );
		}
	}
	
	public function getCodeTree( $database, $table, $treeTitle, $encoded = false )
	{
		
		$children = array ( 
			$this->_getPHP ( $database, $table ), $this->_getAS ( $database, $table ), $this->_getMXML ( $database, $table ), $this->_getCairngorm ( $database, $table ), $this->_getRegExpr ( $database, $table ), $this->_getXML ( $database, $table ) 
		);
		sort ( $children );
		
		$tree = array ( 
			'label' => $treeTitle, 'children' => $children 
		);
		
		if ( $encoded )
		{
			return $this->encodeTree ( $tree );
		}
		return $tree;
	}
	
	public function getCookbookTree( $database, $table, $treeTitle, $encoded = false )
	{
		
		$children = array ( 
			$this->_getRecipes( $database, $table ) 
		);
		
		sort ( $children );
		
		$tree = array ( 
			'label' => $treeTitle, 'children' => $children 
		);
		
		if ( $encoded )
		{
			return $this->encodeTree ( $tree );
		}
		return $tree;
	}
	
	private function _makeNode( $title, $children )
	{
		$node = array ( 
			'label' => $title, 'children' => $children 
		);
		
		return $node;
	}
	
	public function getPosts( $database, $table )
	{
		$query = $this->realQuery ( "SELECT * FROM $database.$table" );
		$array = array ();
		
		while ( $row = mysqli_fetch_assoc ( $query ) )
		{
			$array [] = $row;
		}
		
		return $array;
	}
	
	private function _getPHP( $database, $table )
	{
		$php = $this->execute ( "SELECT * FROM $database.$table WHERE lang LIKE '%php%'" );
		
		return $this->_makeNode ( 'PHP', $php );
	}
	
	private function _getAS( $database, $table )
	{
		$as = $this->execute ( "SELECT * FROM $database.$table WHERE lang LIKE '%as%'" );
		
		return $this->_makeNode ( 'ActionScript', $as );
	}
	
	private function _getMXML( $database, $table )
	{
		$mxml = $this->execute ( "SELECT * FROM $database.$table WHERE lang LIKE '%mxml%'" );
		
		return $this->_makeNode ( 'MXML', $mxml );
	}
	
	private function _getXML( $database, $table )
	{
		$xml = $this->execute ( "SELECT * FROM $database.$table WHERE lang LIKE '%xml%'" );
		
		return $this->_makeNode ( 'XML', $xml );
	}
	
	private function _getCairngorm( $database, $table )
	{
		$cairngorm = $this->execute ( "SELECT * FROM $database.$table WHERE lang LIKE '%cairngorm%'" );
		
		return $this->_makeNode ( 'Cairngorm', $cairngorm );
	}
	
	private function _getRegExpr( $database, $table )
	{
		$regexp = $this->execute ( "SELECT * FROM $database.$table WHERE lang LIKE '%reg%'" );
		
		return $this->_makeNode ( 'Regular Expressions', $regexp );
	}
	
	public function _getCategory( $database, $table, $title, $category )
	{
		$cat = $this->execute ( "SELECT * FROM $database.$table WHERE lang LIKE '%$category%'" );
		
		return $this->_makeNode ( $title, $cat );
	}
		
	public function _getRecipes( $database, $table )
	{
		$php = $this->execute ( "SELECT * FROM $database.$table" );
		
		return $this->_makeNode ( 'Chapters', $php );
	}
		
	private function encodeTree( $tree )
	{
		$tree = array ( 
			$tree 
		);
		
		return json_encode ( $tree );
	}
	
	/**
	 * I execute a query
	 *
	 * @param [string] $sql
	 * @return [array]
	 */
	public function execute( $sql )
	{
		return $this->queryToARRAY ( $sql );
	}
	
	/**
	 * I execute a raw query
	 *
	 * @param [string] $query
	 * @return [link]
	 */
	public function realQuery( $query )
	{
		return $this->mysqli->query ( $query );
	}
	
	/**
	 * I execute a query and return the results as json.
	 *
	 * @param [string] $sql the query to be executed
	 * @return [json] the result in json
	 */
	public function queryToJSON( $sql )
	{
		$result = $this->realQuery ( $sql );
		
		while ( $row = mysqli_fetch_assoc ( $result ) )
		{
			$array [] = $row;
		}
		return json_encode ( $array );
	}
	
	/**
	 * I execute a query and return the result as an array.
	 *
	 * @param [string] $sql the query to be executed
	 * @return [array] the result array
	 */
	public function queryToARRAY( $sql )
	{
		$query = $this->realQuery ( $sql );
		$array = array ();
		
		while ( $row = mysqli_fetch_assoc ( $query ) )
		{
			$array [] = $row;
		}
		
		return $array;
	}
	
	/**
	 * I dump vars
	 *
	 * @param [string] $title the title of the dump
	 * @param [var] $var the var
	 */
	public function dump( $title, $var )
	{
		print "<h4>$title</h4>";
		print "<pre>";
		print_r ( $var );
		print "</pre>";
	}
	
	/**
	 * @return [link]
	 */
	public function getMysqli()
	{
		return $this->mysqli;
	}
	
	/**
	 * @param [link] $mysqli
	 */
	public function setMysqli( $mysqli )
	{
		$this->mysqli = $mysqli;
	}

	
	
	public function saveRecipe( $database, $table, $id, $chapter, $label, $problem, $solution, $code, $discussion, $category )
	{
		$result = '';
		
		if ( $id == 0 )
		{
			$result = $this->_createRecipe( $database, $table, $chapter, $label, $problem, $solution, $code, $discussion, $category );	
		} else {
			$result = $this->_updateRecipe( $database, $table, $id, $chapter, $label, $problem, $solution, $code, $discussion, $category );
		}
		
		return $result;
	}
	
	/*INSERT INTO jonniespratleys_code.cookbook_posts
		(id, chapter, label, problem, solution, code, discussion, category)
	VALUES
		(0, 1.0, 'Connection to Database', 'You want to connection', 'Build a script', 'Here is code', 'You know howto do it', 'AMFPHP')
	*/
	
	private function _createRecipe( $database, $table, $chapter, $label, $problem, $solution, $code, $discussion, $category )
	{
		$sql = "INSERT INTO $database.$table
					( id, chapter, label, problem, solution, code, discussion, category )
				VALUES
					(0, $chapter, '$label', '$problem', '$solution', '$code', '$discussion', '$category')";
		$result = $this->realQuery( $sql );
		
		if ( $result )
		{
			return mysqli_insert_id( $this->mysqli );
		}
		return $result;
	
	}
	
	private function _updateRecipe( $database, $table, $id, $chapter, $label, $problem, $solution, $code, $discussion, $category )
	{
		$sql = "UPDATE
					$database.$table
				SET
					chapter = $chapter,
					label = '$label',
					problem = '$problem',
					solution = '$solution',
					code = '$code',
					discussion = '$discussion',
					category = $category
				WHERE
					id = $id";
		$result = $this->realQuery( $sql );
		
		if ( $result )
		{
			return mysql_affected_rows(  $this->mysqli );
		}
		return $result;
	
	}
	
	/**
	INSERT INTO jonniespratleys_code.code_posts
	(id, label, description, lang, code, category)
VALUES
	(null, 'label', 'desc', 'lang', 'code', 'cateory')
*/
	public function saveCode( $database, $table, $id, $label, $description, $lang, $code, $category )
	{
		$result = '';
		if ( $id == 0 )
		{
			$result = $this->_createCode( $database, $table, $label, $description, $lang, $code, $category );
		} else {
			$result = $this->_updateCode( $database, $table, $id, $label, $description, $lang, $code, $category );
		}
		return $result;
	}
	
	
	private function _createCode( $database, $table, $label, $description, $lang, $code, $category )
	{
		$sql = "INSERT INTO $database.$table
					(id, label, description, lang, code, category )
				VALUES
					(null, '$label', '$description', '$lang', '$code', '$category')";
		
		$result = $this->realQuery( $sql );
		
		if ( $result )
		{
			return mysqli_insert_id( $this->mysqli );
		}
		return $result;
	}
	
	private function _updateCode( $database, $table, $id, $label, $description, $lang, $code, $category )
	{
		$sql = "UPDATE
					$database.$table
				SET
					label = '$label',
					description = '$description',
					lang = '$lang',
					code = '$code',
					category = $category
				WHERE
					id = $id";
		$result = $this->realQuery( $sql );
		
		if ( $result )
		{
			return mysql_affected_rows(  $this->mysqli );
		}
		return $result;
	}
	
	
	public function _getCategoriesAndPosts( $database, $table )
	{
		$categories = $this->_getCategories( $database, $table );
		$categoryArray = array();
		while( $category = mysqli_fetch_assoc( $categories ) )
		{
			foreach( $category as $key => $value )
			{
				$categoryArray[] = $this->_getPostsByCategory( $database, $table, $key, $value );
			}
		}
		$folder = array( 'label' => 'Categories', 'children' => $categoryArray );
		
		return $folder;
	}
	
	public function _getPostsByCategory( $database, $table, $col, $value )
	{
		return $this->queryToARRAY( "SELECT * FROM $database.$table WHERE $col = $value" );
	}
	
	public function _getCategories( $database, $table )
	{
		return $this->realQuery( "SELECT * FROM $database.$table" );
	}
	
}

?>