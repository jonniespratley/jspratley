<?php 
require_once '../ContactsService.php';
require_once '../vo/ContactsVO.php';


			$address = "";
			$city = "";
			$country = "";
			$date = "";
			$email = "";
			$id = "";
			$name = "";
			$phone = "";
			$state = "";
			$zip = "";
$id = '';

if ( $_GET['id'] )
{
	$id = $_GET['id'];
	$service = new ContactsService();
	$recordVO = new ContactsVO();
	$record = $service->getOneContacts( $id ); 
	$recordVO = $record[0];//First object in array
	
	
			$address = $recordVO->address;
			$city = $recordVO->city;
			$country = $recordVO->country;
			$date = $recordVO->date;
			$email = $recordVO->email;
			$id = $recordVO->id;
			$name = $recordVO->name;
			$phone = $recordVO->phone;
			$state = $recordVO->state;
			$zip = $recordVO->zip;
	
	
}
?>
<?php include '_header.php'; ?>
<form id="formContacts" name="formContacts" method="post" action="ContactsList.php">
	 
	
	
			<div>
		 		<label for="address">Address</label>
		 		<input type="text" name="address" value="<?php echo $address; ?>"/>
		 	</div>
			<div>
		 		<label for="city">City</label>
		 		<input type="text" name="city" value="<?php echo $city; ?>"/>
		 	</div>
			<div>
		 		<label for="country">Country</label>
		 		<input type="text" name="country" value="<?php echo $country; ?>"/>
		 	</div>
			<div>
		 		<label for="date">Date</label>
		 		<input type="text" name="date" value="<?php echo $date; ?>"/>
		 	</div>
			<div>
		 		<label for="email">Email</label>
		 		<input type="text" name="email" value="<?php echo $email; ?>"/>
		 	</div>
			<div>
		 		<label for="id">Id</label>
		 		<input type="text" name="id" value="<?php echo $id; ?>"/>
		 	</div>
			<div>
		 		<label for="name">Name</label>
		 		<input type="text" name="name" value="<?php echo $name; ?>"/>
		 	</div>
			<div>
		 		<label for="phone">Phone</label>
		 		<input type="text" name="phone" value="<?php echo $phone; ?>"/>
		 	</div>
			<div>
		 		<label for="state">State</label>
		 		<input type="text" name="state" value="<?php echo $state; ?>"/>
		 	</div>
			<div>
		 		<label for="zip">Zip</label>
		 		<input type="text" name="zip" value="<?php echo $zip; ?>"/>
		 	</div>
    
    <div>
    	<input type="hidden" name="id" value="<?php echo $id; ?>"/>
	   <input name="save" type="submit" value="Save" />
		<button onclick="window.location='ContactsList.php'">Back</button>
    </div>
</form>
 <?php include '_footer.php'; ?>