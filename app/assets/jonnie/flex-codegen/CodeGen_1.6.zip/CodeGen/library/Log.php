<?php
require_once 'XMLLog.php';
class Log
{
	private $xmlLog;
	private $textLog;
	
	public function __construct()
	{
	}
	
	public function start( $fileName )
	{
		$this->xmlLog = new XMLLog ( $fileName . ".xml" );
	}
	
	public function add( $message )
	{
		$this->xmlLog->add ( $message );
	}
	
	public function end()
	{
		$this->xmlLog->close ();
	}
	
	public static function instance()
	{
		static $inst = null;
		if ( ! isset ( $inst ) ) $inst = new Log ( );
		return $inst;
	}
}

?>