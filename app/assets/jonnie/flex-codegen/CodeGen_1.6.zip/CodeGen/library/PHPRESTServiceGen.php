<?php

include 'Required.php';

class PHPRESTServiceGen implements IGenerate
{
	
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		$filename = ucfirst( $database ).'RESTService.php';
	
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		$namespace = Utilities::namespaceApplication ( $namespace );
	
		$restServiceIncludes = '';
		$restGetSwitch = '';
		$restSaveSwitch = '';
		$restRemoveSwitch = '';
		
		foreach ( $table as $tbl )
		{
			$restServiceIncludes .= '
			require_once ( "'.ucfirst ( $tbl [ 'table' ] ).'Service.php" );
			require_once ( "vo/'.ucfirst ( $tbl [ 'table' ] ).'VO.php" );
			';

			/* -------- GET ---------- */
			$restGetSwitch .= '
				case "'.$tbl['table'].'":
					$service = new '.ucfirst ( $tbl [ 'table' ] ).'Service();
					$results = $service->getAll'.ucfirst ( $tbl [ 'table' ] ).'();
					print_r( json_encode( $results ) );
				break;
				';
			
			/* -------- SAVE ---------- */
			$restSaveSwitch .= '
				case "'.$tbl['table'].'":
					$service = new '.ucfirst ( $tbl [ 'table' ] ).'Service();
					$results = $service->save'.ucfirst ( $tbl [ 'table' ] ).'( $query );
					print_r( json_encode( $results ) );
				break;
				';
			
			/* -------- REMOVE ---------- */		
			$restRemoveSwitch .= '
				case "'.$tbl['table'].'":
					$service = new '.ucfirst ( $tbl [ 'table' ] ).'Service();
					$results = $service->remove'.ucfirst ( $tbl [ 'table' ] ).'( $query );
					print_r( json_encode( $results ) );
				break;
				';
		}
		
		$databaseService = FileSystemService::readFile ( TemplateManager::$PHP_TEMPLATE_LOCATION.'rest.txt' );
		
		$template = preg_replace ( TemplateManager::$FILE_INCLUDES_PATTERN, $restServiceIncludes, $databaseService );
		$template = preg_replace ( TemplateManager::$REST_TABLE_GET_PATTERN, $restGetSwitch, $template );
		$template = preg_replace ( TemplateManager::$REST_TABLE_SAVE_PATTERN, $restSaveSwitch, $template );
		$template = preg_replace ( TemplateManager::$REST_TABLE_REMOVE_PATTERN, $restRemoveSwitch, $template );	
		$template = preg_replace ( TemplateManager::$CG_VERSION_PATTERN, CGManager::$CG_VERSION, $template );
		$template = preg_replace ( TemplateManager::$CG_AUTHOR_PATTERN, CGManager::$CG_AUTHOR, $template );
		
		Utilities::checkOrMakeFolders ( TemplateManager::$SERVER_OUTPUT, $folderNamespace, '' );
		FileSystemService::writeFile ( TemplateManager::$SERVER_OUTPUT . $folderNamespace . '/' . $filename, $template );
		
		return 'Generated REST Service for ' . $database;
	}
}

?>