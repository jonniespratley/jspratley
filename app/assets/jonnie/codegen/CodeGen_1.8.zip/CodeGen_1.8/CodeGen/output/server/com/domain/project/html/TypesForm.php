<?php 
require_once '../TypesService.php';
require_once '../vo/TypesVO.php';


			$id = "";
			$type_title = "";
			$user_id = "";
$id = '';

if ( $_GET['id'] )
{
	$id = $_GET['id'];
	$service = new TypesService();
	$recordVO = new TypesVO();
	$record = $service->getOneTypes( $id ); 
	$recordVO = $record[0];//First object in array
	
	
			$id = $recordVO->id;
			$type_title = $recordVO->type_title;
			$user_id = $recordVO->user_id;
	
	
}
?>
<?php include '_header.php'; ?>
<form id="formTypes" name="formTypes" method="post" action="TypesList.php">
	 
	
	
			<div>
		 		<label for="id">Id</label>
		 		<input type="text" name="id" value="<?php echo $id; ?>"/>
		 	</div>
			<div>
		 		<label for="type_title">Type_title</label>
		 		<input type="text" name="type_title" value="<?php echo $type_title; ?>"/>
		 	</div>
			<div>
		 		<label for="user_id">User_id</label>
		 		<input type="text" name="user_id" value="<?php echo $user_id; ?>"/>
		 	</div>
    
    <div>
    	<input type="hidden" name="id" value="<?php echo $id; ?>"/>
	   <input name="save" type="submit" value="Save" />
		<button onclick="window.location='TypesList.php'">Back</button>
    </div>
</form>
 <?php include '_footer.php'; ?>