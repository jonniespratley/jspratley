<?php 
require_once '../TagsService.php';
require_once '../vo/TagsVO.php';

$service = new TagsService();
$result = '';
$recordList = '';

if ( isset($_POST['save']) )
{
	unset( $_POST['save'] );
	$recordValues = $_POST;
	$result = $service->saveTags( $recordValues );	
}

$recordsArray = $service->getAllTags();
$recordVO = new TagsVO();

for ( $i = 0; $i < count( $recordsArray ); $i++ ) 
{
	$recordVO = $recordsArray[ $i ];
	
	$recordList .= '<tr id="'.$recordVO->user_id.'">';

	
			$recordList .= "<td>$recordVO->id</td>";
			$recordList .= "<td>$recordVO->tag_title</td>";
			$recordList .= "<td>$recordVO->user_id</td>";

	$recordList .= '<td class="actions">';
	$recordList .= '<button class="edit" onclick="window.location=\'TagsForm.php?id='.$recordVO->user_id.'\'">Edit</button>';
	$recordList .= '<button class="delete" onclick=" remove('.$recordVO->user_id.')">Delete</button></td>';
	$recordList .= '</tr>';
}

?>
<?php include '_header.php'; ?> 

<script type="text/javascript">
var service = '../TagsService.php';

function remove( id ){
	$.get( service, { m: 'remove', id: id }, function(data){
		if ( data ) {
			$('#'+id).fadeOut('slow');
		} else {
			alert( 'There was a problem!' );
		}
	});
}
</script>

<h3>Tags</h3>

    <table width="100%" border="0">
	<tr>
		
			<th scope="col">id</th>
			<th scope="col">tag_title</th>
			<th scope="col">user_id</th><th scope="col">Actions</th>   
    </tr>
       <?php echo $recordList; ?>
    </table>
    
    <a href="TagsForm.php">New Tags</a>
  
 <?php include '_footer.php'; ?>