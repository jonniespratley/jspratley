<?php/**                    My Test Application
                *//**  * I am a object representing the @TABLE table. *  * @version CodeGen - 1.8 * @author CodeGen - Jonnie Spratley (http://jonniespratley.com/code) * * @package com.domain.project.VO * @name MapsVO.php */class MapsVO{	/* Official boycott on amphp, because its trash */	//public $_explicitType = 'com.domain.project.vo.MapsVO';		
			public $id;
			public $location_id;
			public $map_lat;
			public $map_lon;
			public $map_type;
			public $user_id;		public function __construct(){}		public function mapObject( $vo )	{		
			$this->id = $vo["id"];
			$this->location_id = $vo["location_id"];
			$this->map_lat = $vo["map_lat"];
			$this->map_lon = $vo["map_lon"];
			$this->map_type = $vo["map_type"];
			$this->user_id = $vo["user_id"];	}		public function setNamespace( $namespace )	{		$this->explicitType = $namespace;	}		public function __get( $name )	{		return $this->$name;	}		public function __set( $name, $value )	{		$this->$name = $value;	}	}?>                                          