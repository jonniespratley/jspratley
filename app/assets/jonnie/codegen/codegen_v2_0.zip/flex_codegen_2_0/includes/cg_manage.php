<div class="grid_12">
	<div id="cg_data_manager"></div>
</div>
<div class="clear"></div>