<div title="Panel 4" class="panel">
    <div class="wrapper">
    	<h2>4. Application Files</h2>
         <p>You can view a html preview of the application by clicking next.</p>
		<div class="paging">
            <a class="cross-link" href="#3">Prev</a>
            <a class="cross-link" href="#5">Next</a>
        </div>
    </div>
</div>