<?php 
/**
 * @name  	PHPGen.php
 * @author  Jonnie Spratley
 * @version 2.0
 *
 */

//@TODO:  Using $this when not in object context in <b>/Applications/MAMP/htdocs/CodeGen/library/PHPGen.php</b> on line <b>85</b><br />
 
require_once 'TemplateManager.php';
require_once 'FileSystemService.php';
require_once 'CGManager.php';
require_once 'Utilities.php';

class PHPGen {

private $options;
	
	public function __construct($options){
		if ($options){
			$this->options = $options;
			
		} else {
			trigger_error('Must use options');
		}
	}
    
	public function generateValueObject( $table, $fields ) {
        $tableUFirst = ucfirst($table);
        $filename = $tableUFirst.'VO.php';
        
        $fieldVars = '';
        $fieldsCon = '';
        
		for( $i=0; $i < count($fields); $i++){
			
		}
		
		
        foreach ($fields as $field) {
        	if ($field['alias']){
        		$fieldAlias = $field['alias'];
        	} else {
        		$fieldAlias = $field['name'];
        	}
            $fieldVars .= '
			public $'.$fieldAlias.';';
			
            $fieldsCon .= '
			$this->'.$fieldAlias.' = $vo["'.$field['name'].'"];';
			
        }
        
        $tableService = FileSystemService::readFile(TemplateManager::$PHP_TEMPLATE_LOCATION.'phpvo.txt');
        
        $template = preg_replace(TemplateManager::$TABLE_UFIRST_PATTERN, $tableUFirst, $tableService);
        $template = preg_replace(TemplateManager::$FIELD_VARS_PATTERN, $fieldVars, $template);
        $template = preg_replace(TemplateManager::$FIELDS_PATTERN, $fieldsCon, $template);
        $template = preg_replace(TemplateManager::$NAMESPACE_PATTERN, $this->options['namespacee'], $template);
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        $template = preg_replace(TemplateManager::$CG_VERSION_PATTERN, CGManager::$CG_VERSION, $template);
        $template = preg_replace(TemplateManager::$CG_AUTHOR_PATTERN, CGManager::$CG_AUTHOR, $template);

        
        //	return 'Generated PHP Value Object for ' . $tableUFirst;
        return array('filename'=>$filename, 'label'=>$filename,'contents'=>$template, 'lang'=>'php', 'type'=>'vo');
    }

    
    public function generateBaseService( $table, $fields) {
        $orgTable = $table;
        $tableUFirst = ucfirst($table);
        $tableLC = strtolower($table);
        $filename = ucfirst($table).'Service.php';
        
        $tableServiceTemplate = FileSystemService::readFile(TemplateManager::$PHP_TEMPLATE_LOCATION.'phpdao.txt');
        $setFields = '';
        
        foreach ($fields as $field) {
            $setFields .= ''.$field['name'].' = ".$this->_prepare( $'.$tableUFirst.'VO->'.$field['name'].').", ';
        }
        
        $setFields = Utilities::trimSQL($setFields);
        
        $template = preg_replace(TemplateManager::$TABLE_LOWERCASE_PATTERN, $tableLC, $tableServiceTemplate);
        $template = preg_replace(TemplateManager::$TABLE_UFIRST_PATTERN, $tableUFirst, $template);
        $template = preg_replace(TemplateManager::$TABLE_UFIRST_PATTERN, $tableUFirst, $template);
        $template = preg_replace(TemplateManager::$TABLE_PATTERN, $orgTable, $template);
        $template = preg_replace(TemplateManager::$SET_FIELDS_PATTERN, $setFields, $template);
        
        $template = preg_replace(TemplateManager::$DATABASE_PATTERN, ucfirst($this->options['database']), $template);
        $template = preg_replace(TemplateManager::$NAMESPACE_PATTERN, $this->options['namespacee'], $template);
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        $template = preg_replace(TemplateManager::$CG_VERSION_PATTERN, CGManager::$CG_VERSION, $template);
        $template = preg_replace(TemplateManager::$CG_AUTHOR_PATTERN, CGManager::$CG_AUTHOR, $template);
        
        //return 'Generated PHP Service for ' . $tableUFirst;
        return array('filename'=>$filename, 'label'=>$filename,'contents'=>$template, 'lang'=>'php', 'type'=>'base');
    }
    
    /**
     * I generate a REST service class for the application, one per application.
     * I have methods that call upon the proper class based on the URL query string.
     
     */
    public function generateRESTService($tables) {
    
        $filename = ucfirst($this->options['application']).'Service.php';
        
        $restServiceIncludes = '';
        $restGetSwitch = '';
        $restSaveSwitch = '';
        $restRemoveSwitch = '';
        
        foreach ($tables as $tbl) {
            $restServiceIncludes .= '
			require_once ( "'.ucfirst($tbl['name']).'Service.php" );
			require_once ( "vo/'.ucfirst($tbl['name']).'VO.php" );
			';
			
            /* -------- GET ---------- */
            $restGetSwitch .= '
				case "'.$tbl['name'].'":
					$service = new '.ucfirst($tbl['name']).'Service();
					$results = $service->getAll'.ucfirst($tbl['name']).'();
					print_r( json_encode( $results ) );
				break;
				';
				
            /* -------- SAVE ---------- */
            $restSaveSwitch .= '
				case "'.$tbl['name'].'":
					$service = new '.ucfirst($tbl['name']).'Service();
					$results = $service->save'.ucfirst($tbl['name']).'( $query );
					print_r( json_encode( $results ) );
				break;
				';
				
            /* -------- REMOVE ---------- */
            $restRemoveSwitch .= '
				case "'.$tbl['name'].'":
					$service = new '.ucfirst($tbl['name']).'Service();
					$results = $service->remove'.ucfirst($tbl['name']).'( $query );
					print_r( json_encode( $results ) );
				break;
				';
        }
        
        $databaseServiceTemplate = FileSystemService::readFile(TemplateManager::$PHP_TEMPLATE_LOCATION.'phprest.txt');
        
        $template = preg_replace(TemplateManager::$FILE_INCLUDES_PATTERN, $restServiceIncludes, $databaseServiceTemplate);
        $template = preg_replace(TemplateManager::$REST_TABLE_GET_PATTERN, $restGetSwitch, $template);
        $template = preg_replace(TemplateManager::$REST_TABLE_SAVE_PATTERN, $restSaveSwitch, $template);
        $template = preg_replace(TemplateManager::$REST_TABLE_REMOVE_PATTERN, $restRemoveSwitch, $template);
        
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        
        $template = preg_replace(TemplateManager::$CG_VERSION_PATTERN, CGManager::$CG_VERSION, $template);
        $template = preg_replace(TemplateManager::$CG_AUTHOR_PATTERN, CGManager::$CG_AUTHOR, $template);

        
        return array('filename'=>$filename,'label'=>$filename, 'contents'=>$template, 'lang'=>'php', 'type'=>'rest');
    }
    
    /**
     * I create the connection file for database access.
     *
     * @param [string] $output - The location where the file is to be placed once generated
     * @param [string] $database - The applications database name.
     * @return [array] - An array containing the filename and the real file path.
     */
    public function writeConnection() {
        $filename = ucfirst($this->options['database']).'Connection.php';
        
        $connectionTemplate = FileSystemService::readFile(TemplateManager::$PHP_TEMPLATE_LOCATION.'conn.txt');
        
        $template = preg_replace(TemplateManager::$HOST_PATTERN, $this->options['host'], $connectionTemplate);
        $template = preg_replace(TemplateManager::$USER_PATTERN, $this->options['user'], $template);
        $template = preg_replace(TemplateManager::$PASS_PATTERN, $this->options['pass'], $template);
        $template = preg_replace(TemplateManager::$DATABASE_PATTERN, $this->options['database'], $template);
        $template = preg_replace(TemplateManager::$COPYWRITE_PATTERN, $this->options['copywrite'], $template);
        
        $template = preg_replace(TemplateManager::$CG_VERSION_PATTERN, CGManager::$CG_VERSION, $template);
        $template = preg_replace(TemplateManager::$CG_AUTHOR_PATTERN, CGManager::$CG_AUTHOR, $template);
        
        return array('filename'=>$filename, 'label'=>$filename,'contents'=>$template, 'lang'=>'php', 'type'=>'connection');
    }
}


?>
