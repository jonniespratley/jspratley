<?php/**  * I am a object representing the States_state table. *  * @version 1.6 * @author Jonnie Spratley (http://jonniespratley.com/code) * * @package com.jonniespratley.test.VO * @name States_stateVO.php */class States_stateVO{	var $_explicitType = 'com.jonniespratley.test.VO.States_stateVO';		
			public $id_state;
			public $name_state;		public function __construct( $vo )	{		
			$this->id_state = $vo["id_state"];
			$this->name_state = $vo["name_state"];	}	}?>                                          