<?php 
require_once '../CategoriesService.php';
require_once '../vo/CategoriesVO.php';


			$category_id = "";
			$category_name = "";
$id = '';

if ( $_GET['category_id'] )
{
	$id = $_GET['category_id'];
	$service = new CategoriesService();
	$recordVO = new CategoriesVO();
	$record = $service->getOneCategories( $id ); 
	$recordVO = $record[0];//First object in array
	
	
			$category_id = $recordVO->category_id;
			$category_name = $recordVO->category_name;
	
	
}
?>
<?php include '_header.php'; ?>
<form id="formCategories" name="formCategories" method="post" action="CategoriesList.php">
	 
	
	
			<div>
		 		<label for="category_id">Category_id</label>
		 		<input type="text" name="category_id" value="<?php echo $category_id; ?>"/>
		 	</div>
			<div>
		 		<label for="category_name">Category_name</label>
		 		<input type="text" name="category_name" value="<?php echo $category_name; ?>"/>
		 	</div>
    
    <div>
    	<input type="hidden" name="category_id" value="<?php echo $id; ?>"/>
	   <input name="save" type="submit" value="Save" />
		<button onclick="window.location='CategoriesList.php'">Back</button>
    </div>
</form>
 <?php include '_footer.php'; ?>