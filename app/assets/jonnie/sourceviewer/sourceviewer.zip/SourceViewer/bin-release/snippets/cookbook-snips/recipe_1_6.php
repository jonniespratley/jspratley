public function getSomeData():void
{
	service.call ( "Path.ServiceName.MethodName", new Responder( someResultHandler, someFaultHandler ), Arguments ) );
}