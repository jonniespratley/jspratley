<?php

include 'Required.php';

class FlexMainGen implements IGenerate
{

	/**
	 * I generate the MainView.mxml Flex component that holds, 
	 * one list and one form.
	 * 
	 * The list and form it holds is represeting a table in the database,
	 * for how ever many tables there is in the database, I will be created
	 * for each table.
	 *
	 * @param unknown_type $namespace
	 * @param unknown_type $database
	 * @param unknown_type $table
	 * @param unknown_type $fields
	 * @return unknown
	 */
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		$table = ucfirst ( $table );
	
		//make the folder namespace com/jonnie/test/
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		
		//make the actual namespace com.jonnie.test
		$namespace = Utilities::namespaceApplication ( $namespace );
	
		/* Read the template, and prepare to search and replace the template */
		$flexForm = FileSystemService::readFile ( TemplateManager::$FLEX_TEMPLATE_LOCATION.'FlexMain.txt' );
		
		/* Set and replace the table name*/
		$template = preg_replace ( TemplateManager::$TABLE_PATTERN, $table, $flexForm );
		
		/* Set and replace the namespaces */
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $template );
		
		Utilities::checkOrMakeFolders ( TemplateManager::$CLIENT_OUTPUT, $folderNamespace, 'view/'.$table.'/' );
		FileSystemService::writeFile ( TemplateManager::$CLIENT_OUTPUT . $folderNamespace . '/view/'.$table.'/' . $table . 'Main.mxml', $template );
	
		return 'Generated Flex Main for ' . $table;
	}

}
 
?>