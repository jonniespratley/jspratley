<?php 
require_once '../CommentsService.php';
require_once '../vo/CommentsVO.php';


			$comment_body = "";
			$comment_created = "";
			$comment_name = "";
			$id = "";
$id = '';

if ( $_GET['id'] )
{
	$id = $_GET['id'];
	$service = new CommentsService();
	$recordVO = new CommentsVO();
	$record = $service->getOneComments( $id ); 
	$recordVO = $record[0];//First object in array
	
	
			$comment_body = $recordVO->comment_body;
			$comment_created = $recordVO->comment_created;
			$comment_name = $recordVO->comment_name;
			$id = $recordVO->id;
	
	
}
?>
<?php include '_header.php'; ?>
<form id="formComments" name="formComments" method="post" action="CommentsList.php">
	 
	
	
			<div>
		 		<label for="comment_body">Comment_body</label>
		 		<input type="text" name="comment_body" value="<?php echo $comment_body; ?>"/>
		 	</div>
			<div>
		 		<label for="comment_created">Comment_created</label>
		 		<input type="text" name="comment_created" value="<?php echo $comment_created; ?>"/>
		 	</div>
			<div>
		 		<label for="comment_name">Comment_name</label>
		 		<input type="text" name="comment_name" value="<?php echo $comment_name; ?>"/>
		 	</div>
			<div>
		 		<label for="id">Id</label>
		 		<input type="text" name="id" value="<?php echo $id; ?>"/>
		 	</div>
    
    <div>
    	<input type="hidden" name="id" value="<?php echo $id; ?>"/>
	   <input name="save" type="submit" value="Save" />
		<button onclick="window.location='CommentsList.php'">Back</button>
    </div>
</form>
 <?php include '_footer.php'; ?>