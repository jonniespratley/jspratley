<?php
/**
 * 
<?xml version="1.0" encoding="UTF-8"?>
<schema name="database">
	<table name="users">
		<field name="id" type="int" length="11" key="true" options="auto_increment"/>
		<field name="username" type="varchar" length="225"/>
		<field name="password" type="varchar" length="225"/>
		<field name="email" type="varchar" length="225"/>
		<field name="created" type="timestamp"/>
	</table>
</schema>
 *
 */
class CodeGen
{
	private $mysqli;
	
	/**
	 * I am the constructore for the CodeGen
	 *
	 * @example Here is what your config.xml file should look like. 
	 * <code>
	 * <?xml version="1.0" encoding="UTF-8"?>
	 * <config>
	 * 		<host>localhost</host>
	 * 		<user>root</user>
	 * 		<pass>fred</pass>
	 * </config>
	 * </code>
	 * 
	 * @param [string] $configFile The config.xml file
	 */
	public function __construct( $configFile )
	{
		$host = '';
		$user = '';
		$pass = '';
		
		$dom = new DOMDocument();
		$dom->load( $configFile );
		  
		$configs = $dom->getElementsByTagName( "config" );
		
		foreach( $configs as $config )
		{
			$hosts = $config->getElementsByTagName( "host" );
			$host = $hosts->item( 0 )->nodeValue;
		  
			$users = $config->getElementsByTagName( "user" );
			$user = $users->item( 0 )->nodeValue;
			
			$passes = $config->getElementsByTagName( "pass" );
			$pass = $passes->item( 0 )->nodeValue; 
		}
		
		$this->mysqli = new mysqli ( $host, $user, $pass );
	
	}
	
	/**
	 * I save the entire database schema to a local xml file.
	 *
	 * @param [string] $database the name of your database
	 * @return [result] true or false
	 */
	public function saveSchemaXML( $database )
	{
		$dom = new DOMDocument ( '1.0' );
		
		/************************************
		 * Builds the root 
		 ************************************/
		//create a element
		$schema = $dom->createElement ( 'schema' );
		//set the element on itself
		$schema = $dom->appendChild ( $schema );
		//set a attribute for the schema node 
		$schema->setAttribute ( 'name', $database );
		
		/***********************************
		 * Builds the table inside the root
		 **********************************/
		$tableQuery = $this->execute ( "SHOW TABLES FROM $database" );
		
		while ( $tableRow = mysqli_fetch_row ( $tableQuery ) )
		{
			//create a element
			$table = $dom->createElement ( 'table' );
			//set the element on itself
			$table = $dom->appendChild ( $table );
			//set a attribute
			$table->setAttribute ( 'name', $tableRow [ 0 ] );
			
			$fieldQuery = $this->execute ( "DESCRIBE $database.$tableRow[0]" );
			
			while ( $fieldRow = mysqli_fetch_assoc ( $fieldQuery ) )
			{
				/***********************************
				 * Builds the attributes inside the table
				 **********************************/
				//create a element
				$field = $dom->createElement ( 'field' );
				//set the element on itself
				$field = $dom->appendChild ( $field );
				//set the name attribute
				$field->setAttribute ( 'name', $fieldRow [ 'Field' ] );
				//set the type attribute
				$field->setAttribute ( 'type', $fieldRow [ 'Type' ] );
				//set the null attribute
				$field->setAttribute ( 'null', $fieldRow [ 'Null' ] );
				
				if ( $fieldRow [ 'Default' ] != '' )
				{
					//set the default
					$field->setAttribute ( 'default', $fieldRow [ 'Default' ] );
				}
				if ( $fieldRow [ 'Key' ] != '' )
				{
					//set the key
					$field->setAttribute ( 'key', $fieldRow [ 'Key' ] );
				}
				if ( $fieldRow [ 'Extra' ] != '' )
				{
					//set the value/length attribute
					$field->setAttribute ( 'extra', $fieldRow [ 'Extra' ] );
				}
				
				//put the field inside of the table
				$table->appendChild ( $field );
			}
			
			//put the table inside of the schema
			$schema->appendChild ( $table );
		}
		
		$dom->formatOutput = true;
		$dom->saveXML ();
		$xml = $dom->save ( 'output/' . $database . 'Schema.xml' );
		
		return $xml;
	}
	
	public function readXML()
	{
		
	}
	
	public function execute( $sql )
	{
		return $this->mysqli->query ( $sql );
	}

}


/**
 * Class testing
 */
$gen = new CodeGen ( 'config.xml' );
echo $gen->saveSchemaXML ( 'test' );


?>