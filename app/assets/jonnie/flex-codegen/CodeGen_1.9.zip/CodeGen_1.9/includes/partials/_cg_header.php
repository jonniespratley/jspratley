<?php
require_once 'library/CGManager.php';
require_once 'library/ConfigManager.php';
require_once 'library/FlexService.php';
require_once 'library/HTMLHelper.php'; 
require_once 'library/MySQLService.php';
require_once 'library/CodeGen.php';

$html = new HTMLHelper();
$mysql = new MySQLService( 'localhost', 'root', 'fred' );
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>CodeGen V. <?php echo CGManager::$CG_VERSION ?></title>

<!--CSS-->
<link rel="stylesheet" href="assets/css/styles.css" type="text/css" media="screen" />

<!--JS-->
<script src="assets/js/jquery.js" type="text/javascript"></script>
<script src="assets/js/jqueryFileTree.js" type="text/javascript"></script>
<script src="assets/js/jquery-ui.js" type="text/javascript"></script>
<script src="assets/js/chili/jquery.chili.js" type="text/javascript"></script>
<script src="assets/js/jquery.json.js" type="text/javascript"></script>
<script src="assets/js/jquery.pager.js" type="text/javascript"></script>
<script src="assets/js/jquery.jcarousel.js" type="text/javascript"></script>
<script src="assets/js/jquery.corners.js" type="text/javascript"></script>
<script src="assets/js/jquery.highlight.js" type="text/javascript"></script>
<script src="assets/js/jquery.cookie.js" type="text/javascript"></script>
<script src="assets/js/jquery.colorbox.js" type="text/javascript"></script>
<script src="assets/js/JsonFormatter.js" type="text/javascript"></script>
<script src="assets/js/CodeGen.js" type="text/javascript"></script>
<script src="assets/js/CodeGenUtilities.js" type="text/javascript"></script>
<script src="assets/js/CodeGenService.js" type="text/javascript"></script>

</head>
<body>
 
<div id="header">
  <div id="logo">
    <h1><img src="assets/images/codegen_logo.png" alt="CodeGen" /></h1>
  </div>
  <div id="svcLoader" style="display:none;"><img src="assets/images/loader.gif"/></div>
	<div id="menu"> 
		<a class="colorbox" href="http://code.google.com/p/flex-codegen/">Help</a> | 
		<a href="?page=settings">Settings</a>| 
		<a href="#">Logout</a>
	</div>
<br class="clear"/>
</div>	
<div id="wrapper">
  	 
	 
 
	




 
