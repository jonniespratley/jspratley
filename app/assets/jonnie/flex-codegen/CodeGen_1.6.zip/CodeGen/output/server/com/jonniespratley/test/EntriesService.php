<?php

require_once ( 'Connection.php' );
require_once ( 'vo/EntriesVO.php' );

/**
 * I am the Database Access Layer, I can manipulate the database.
 * 
 * @version 1.6
 * @author Jonnie Spratley (http://jonniespratley.com/code)
 *
 * @package com.jonniespratley.test
 * @name EntriesService.php
 */
class EntriesService
{
	private $conn;
	
	/**
	 * I am the instance of a Database Access Object
	 *
	 * @return [link]
	 */
	public function __construct()
	{
		//TODO: need to enter in the proper credentials
		$conn = new Connection ();
		$this->conn = $conn;
	}
	 
	/**
	 * I get all records from the specified database and table
	 * @return [array]
	 */
	public function getAllEntries()
	{
		return $this->_executeReturn ( "SELECT * FROM test.entries" );
	}
	
	/**
	 * I get one record from the specified database and table.
	 *
	 * @param [string] $keyvalue the value of your request
	 * @return [array] the matching record
	 */
	public function getOneEntries( $keyvalue )
	{
		return $this->_executeReturn ( "SELECT * 
										FROM test.entries 
										WHERE ".$this->_getKey()." = $keyvalue" );
	}
	
	/**
	 * I save a record to the specified database and table
	 * @param [string] $vo the name/value object
	 * @return [array] the inserted record
	 */
	public function saveEntries( $vo )
	{
		$choice = '';
		
		$primarykey = $this->_getKey();
		$primarykeyValue = $vo[ $primarykey ];
	
		if ( $primarykeyValue == 0 || $primarykeyValue == '' )
		{
			$choice = $this->createEntries( $vo );
		}
		else
		{
			$choice = $this->updateEntries( $vo );
		}
		return $choice;
	}
	
	/**
	 * I update a record in the database/table
	 *
	 * @param [string] $vo the name/value object
	 * @return [array] the inserted object
	 */
	private function updateEntries( $vo )
	{
		$entriesVO = new EntriesVO ( $vo );
		
		//get the primary key
		$key = $this->_getKey();
		
		//value of the key
		$keyvalue = '';
		
		//check if the object has a key with the same value as the primary key
		if ( array_key_exists( $key, $vo ) )
		{
			//set the keyvalue variable to the array key inside the object, 
			//the key should be the same name as the key in the table
			$keyvalue = $vo[ $key ];
		}
	
		//build the query
		$sql = "UPDATE test.entries 
				SET 
				id = ".$this->_prepare( $entriesVO->id).", entry_title = ".$this->_prepare( $entriesVO->entry_title).", entry_body = ".$this->_prepare( $entriesVO->entry_body).", location_id = ".$this->_prepare( $entriesVO->location_id).", user_id = ".$this->_prepare( $entriesVO->user_id).", upload_id = ".$this->_prepare( $entriesVO->upload_id).", entry_created = ".$this->_prepare( $entriesVO->entry_created)."
				WHERE $key = '$keyvalue'";
				
		return $this->_execute( $sql );
	}
	
	/**
	 * I create a new record in the database/table
	 *
	 * @param [string] $vo the name/value object
	 * @return [boolean] the inserted object
	 */
	private function createEntries( $vo )
	{
		$columns = '';
		$values = '';
		
		foreach( $vo as $column => $value )
		{
			if ( $column != '_explicitType' )
			{
				$columns .= $column.', ';
				$values .= $this->_prepare( $value ).', ';
			}
		}
		
		//trim off the last command and space
		$columns = substr( $columns, 0, strlen( $columns ) - 2 );
		$values = substr( $values, 0, strlen( $values ) - 2 );
		
		//build the query
		$sql = "INSERT test.entries 
				( $columns ) 
				VALUES 
				( $values )";
				
		return $this->_execute( $sql );
	}
	
	/**
	 * I remove a record from the specified database/table
	 *
	 * @param [string] $keyvalue the value of the key
	 * @return [boolean] the result
	 */
	public function removeEntries( $vo )
	{
		$keyvalue = $vo[ $this->_getKey() ];
		
		return $this->conn->execute( "DELETE 
									  FROM test.entries 
									  WHERE ".$this->_getKey()." = '$keyvalue'" );
	}
	
	/**
	 * I get the primary key for table.
	 *
	 * @return [string] the name of the primary key
	 */
	private function _getKey()
	{
		$keys = $this->conn->executeAndReturn( "SHOW INDEX FROM test.entries" );
		$primaryKey = '';
		
		foreach( $keys as $key )
		{
			if ( $key['Key_name'] == 'PRIMARY' )
			{
				$primaryKey = $key['Column_name'];
			}
		}
		return $primaryKey;
	}
	
	/**
	 * I map the resulting recordset to a @TABLE object.
	 *
	 * @param [result] a result from a database query
	 * @return [array] an array of Entries objects
	 */
	private function _mapObjectToEntries( $obj )
	{
		$array = array ();
		while ( $row = mysqli_fetch_assoc ( $obj ) )
		{
			$vo = new EntriesVO ( $row );
			$array [] = $vo;
		}
		return $array;
	}
	
	/**
	 * I execute a statment on the database, and return a array of
	 * @TABLE objects.
	 *
	 * @param [string] the query string to execute
	 * @return [array] array of Entries objects
	 */
	private function _executeReturn( $sql )
	{
		$query = $this->conn->execute ( $sql );
		
		if ( $query )
		{
			return $this->_mapObjectToEntries( $query );
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * I execute a raw query and return the result.
	 * @param [string] $sql the query
	 */
	private function _execute( $sql )
	{
		return $this->conn->execute ( $sql );
	}
	
	/**
	 * I prepare a insertion string.
	 * @param [string] $value the value to be sqlified
	 */
	private function _prepare( $value )
	{
		return "'$value'";
	}
	
	
}
?>