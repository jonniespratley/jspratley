<?php
/**
 * @name  	PHPGen.php
 * @author  Jonnie Spratley
 * @version 1.7
 * @description 
 * 
 * This is a REST Service file for the CodeGen front-end,
 * both html and Flex versions.
 * 
 */

require_once 'CodeGen.php';
require_once 'FileSystemService.php';
require_once 'TemplateManager.php';
require_once 'MySQLService.php';
require_once 'ClassInspector.php';
require_once 'ConfigManager.php';

$configMessage = '';
$schemaMessage = '';
$appMessage = '';
$configLocation = '';
$schemaLocation = '';
$appOutputLog = '';
$mode = '';

$host = '';
$user = '';
$pass = '';
$database = '';
$app = '';
$namespace = '';
$endpoint = '';
$copywrite = '';
$framework = '';

$outputPath = $_SERVER [ "DOCUMENT_ROOT" ] . '/CodeGen/' . TemplateManager::$CONFIG_OUTPUT;

if ( isset ( $_REQUEST [ 'm' ] ) )
{
	switch ( $_REQUEST [ 'm' ] )
	{
		/* ===========================================================================================
		 * generateConfig
		 * =========================================================================================== */
		case 'generateConfig':
			$configLocation = CodeGen::writeConfig ( $outputPath, $_REQUEST [ 'h' ], //Host 
$_REQUEST [ 'u' ], //User 
$_REQUEST [ 'p' ], //Pass 
$_REQUEST [ 'd' ], //Database
$_REQUEST [ 'a' ], //Application 
$_REQUEST [ 'e' ], //Endpoint
$_REQUEST [ 'n' ], //Namespace
$_REQUEST [ 'f' ], //Framework
$_REQUEST [ 'c' ] ); //Copywrite
			

			echo json_encode ( $configLocation );
			break;
		
		/* ===========================================================================================
		 * generateSchema - @param $outputPath - The location where you want to output the schema
		 * =========================================================================================== */
		case 'generateSchema':
			$codegen = new CodeGen ( );
			$codegen->start ( $outputPath, $_REQUEST [ 'd' ] );
			$schema = $codegen->writeSchema ( $outputPath );
			
			echo json_encode ( $schema );
			break;
		
		/* ===========================================================================================
		 * generateApplication - @param $outputPath, $database - The database and output path
		 * =========================================================================================== */
		case 'generateApplication':
			$codegen = new CodeGen ( );
			$codegen->start ( $outputPath, $_REQUEST [ 'd' ] );
			$appOutputLog = $codegen->generateCode ( $outputPath, $_REQUEST [ 'd' ] );
			
			//echo htmlentities( json_encode ( $appOutputLog ) );
			print_r( $appOutputLog );
			break;
			
		case 'getHTMLDemo':
			return ConfigManager::getHtmlDemoURL();
			break;
		
		/* ===========================================================================================
		 * getDatabases - @param $host, $user, $pass - Your MySQL credentials
		 * =========================================================================================== */
		case 'getDatabases':
			$service = new MySQLService ( $_REQUEST [ 'h' ], $_REQUEST [ 'u' ], $_REQUEST [ 'p' ] );
			$databases = $service->getDatabases ();
			
			echo $databases;
			break;
		
		/* ===========================================================================================
		 * getConfig - @param $database - The database the config file is for.
		 * =========================================================================================== */
		case 'getConfig':
			$config = file_get_contents ( $outputPath . ucfirst ( $_REQUEST [ 'd' ] ) );
			
			echo htmlentities ( $config );
			break;
		
		/* ===========================================================================================
		 * getSchema - 
		 * =========================================================================================== */
		case 'getSchema':
			$schema = file_get_contents ( $outputPath . ucfirst ( $_REQUEST [ 'd' ] ) );
			
			echo htmlentities ( $schema );
			break;
		
		/* ===========================================================================================
		 * getTemplates -
		 * =========================================================================================== */
		case 'getTemplates':
			$filesSvc = new FileSystemService ( );
			$templates = $filesSvc->browseDirectory ( '../Templates', true );
			
			echo json_encode ( $templates );
			break;
		
		/* ===========================================================================================
		 * getOutput - 
		 * =========================================================================================== */
		case 'getOutput':
			$filesSvc = new FileSystemService ( );
			$output = $filesSvc->browseDirectory ( '../output', true );
			
			echo json_encode ( $output );
			break;
		
		case 'getDirectory':
			$filesSvc = new FileSystemService ( );
			$output = $filesSvc->browseDirectory ( $_REQUEST['p'], true );
			
			echo json_encode ( $output );
			break;
		
		/* ===========================================================================================
       * getOutput - 
       * =========================================================================================== */
		case 'getServices':
			$filesSvc = new FileSystemService ( );
			$output = $filesSvc->browseDirectory ( $_REQUEST[ 'p' ], true );
			
			echo json_encode ( $output );
			break;
		
		/* ===========================================================================================
		 * readFile - 
		 * =========================================================================================== */
		case 'readFile':
			$file = FileSystemService::readFile ( $_REQUEST [ 'f' ] );
			
			echo htmlentities ( $file );
			break;
		
		/* ===========================================================================================
		 * writeFile - 
		 * =========================================================================================== */
		case 'writeFile':
			$file = FileSystemService::writeFile ( $_REQUEST [ 'f' ], base64_decode ( $_REQUEST [ 'c' ] ) );
			echo json_encode ( $file );
			break;
		
		/* ===========================================================================================
		 * inspectClass - 
		 * =========================================================================================== */
		case 'inspectClass':
			$file = ClassInspector::inspectClass ( $_REQUEST [ 'f' ] );
			echo json_encode ( $file );
			break;
		
		/* ===========================================================================================
		 * callClassFunction - 
		 * =========================================================================================== */
		case 'callClassFunction':
			$request = ClassInspector::call ( $_REQUEST [ '_class' ], $_REQUEST [ '_func' ], $_REQUEST [ '_args' ] );
			$file[] = array( 
				'methodCalled' =>  $_REQUEST['_func'],
				'methodResults' => $request
			 );
			
			echo json_encode ( array( $request ) );
			break;
	}
}

?>       