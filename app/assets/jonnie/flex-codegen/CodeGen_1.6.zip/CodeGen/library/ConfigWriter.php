<?php
class ConfigWriter
{
	
	public static function writeConfig( $host, $user, $pass, $app, $database, $endpoint, $namespace )
	{	
		$dom = new DOMDocument ( '1.0' );
		
		//create a element
		$config = $dom->createElement ( 'config' );
		
		//set the element on itself
		$config = $dom->appendChild ( $config );
		
		//Host
		$hostNode = $dom->createElement( 'host' );
		$hostValue = $dom->createTextNode( $host );
		$hostNode->appendChild( $hostValue );
		
		//User
		$userNode = $dom->createElement( 'user' );
		$userValue = $dom->createTextNode( $user );
		$userNode->appendChild( $userValue );
		
		//Pass
		$passNode = $dom->createElement( 'pass' );
		$passValue = $dom->createTextNode( $pass );
		$passNode->appendChild( $passValue );
		
		//Database
		$databaseNode = $dom->createElement( 'database' );
		$databaseValue = $dom->createTextNode( $database );
		$databaseNode->appendChild( $databaseValue );
		
		//Application
		$appNode = $dom->createElement( 'application' );
		$appValue = $dom->createTextNode( $app );
		$appNode->appendChild( $appValue );
		
		//Namespace
		$namespaceNode = $dom->createElement( 'namespace' );
		$namespaceValue = $dom->createTextNode( $namespace );
		$namespaceNode->appendChild( $namespaceValue );
		
		//Endoint
		$endpointNode = $dom->createElement( 'endpoint' );
		$endpointValue = $dom->createTextNode( $endpoint );
		$endpointNode->appendChild( $endpointValue );
		
		
		$config->appendChild( $hostNode );
		$config->appendChild( $userNode );
		$config->appendChild( $passNode );
		$config->appendChild( $databaseNode );
		$config->appendChild( $appNode );
		$config->appendChild( $namespaceNode );
		$config->appendChild( $endpointNode );
		
		$filename = TemplateManager::$CONFIG_OUTPUT.ucfirst( $database ).'Config.xml';
		
		$dom->formatOutput = true;
		$dom->save( $filename );
		
		//change the permissions
		chmod ( $filename, 0777 );
		
		$filepath = $filename; 
		
		return $filepath;
	}
	
}
?>