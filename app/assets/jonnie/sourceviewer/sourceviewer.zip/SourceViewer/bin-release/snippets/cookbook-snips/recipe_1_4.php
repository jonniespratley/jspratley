<?php

class SnippetVO
{
	
	public $_explicitType = "com.jonniespratley.snippr.vo.SnippetVO";
	public $snippet_id;
	public $snippet_title;
	public $snippet_code;
	public $snippet_type;
	public $snippet_created;
	public $snippet_user;
	
	public function SnippetVO( $snip )
	{
		$this->snippet_id = $snip [ snippet_id ];
		$this->snippet_title = $snip [ snippet_title ];
		$this->snippet_code = $snip [ snippet_code ];
		$this->snippet_type = $snip [ snippet_type ];
		$this->snippet_created = $snip [ snippet_created ];
		$this->snippet_user = $snip [ snippet_user ];
	}

}
?>

package com.jonniespratley.snippr.vo
{   
	  /**
       * VOs are used to create a layer of business objects that can be 
       * transferred between tiers, instead of using records, results sets, and datasets.
       */
     [Bindable]
	[RemoteClass(alias="vo.SnippetVO")]
     public class SnippetVO
     {
        public var snippet_idint;
        public var snippet_titleString;
        public var snippet_codeString;
        public var snippet_typeString;
        public var snippet_createdString;
        public var snippet_userString;     
        
        public function SnippetVO()
        {      

        }
     }
  }