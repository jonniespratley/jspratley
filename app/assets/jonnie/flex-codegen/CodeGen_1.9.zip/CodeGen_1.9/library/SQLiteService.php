<?php

class SQLiteService
{
	private $sqlite;
	private $sqlite_error;
	private $sqlite_results;
	
	public function __construct()
	{
		#$this->sqlite = new SQLiteDatabase();
		
		#$sqlite = sqlite_open ( 'assets/CodeGen.sqlite', 0666, $error );
	}
	
	public function open( $dbfile )
	{
		$this->sqlite = sqlite_open( $dbfile, 0666, $this->sqlite_error );
	}
	
	public function execute( $sql )
	{
		$results = sqlite_query ( $this->sqlite, $sql );
		
		return $results;
	}
	
	/**
	 * I format debug dumps
	 *
	 * @param [var] the variable you with to dump
	 */
	public function dumpIt( $var )
	{
		print "<pre>\n";
		print_r ( $var );
		print "</pre>\n";
	}
	
	/**
	 * I execute a query and return the results as json.
	 *
	 * @param [string] $sql the query to be executed
	 * @return [json] the result in json
	 */
	public function queryToJSON( $sql )
	{
		$result = sqlite_query ( $this->sqlite, $sql );
		
		while ( $row = sqlite_fetch_array( $result ) )
		{
			$array [] = $row;
		}
		
		return json_encode ( $array );
	}
	
	/**
	 * I execute a query and return the result as an array.
	 *
	 * @param [string] $sql the query to be executed
	 * @return [array] the result array
	 */
	public function queryToArray( $sql )
	{
		$result = sqlite_query ( $this->sqlite, $sql );
		$array = array();
		while ( $row = sqlite_fetch_array( $result ) )
		{
			array_push( $array, $row );
		}
		
		return ( $array );
	}
	
	public function getSqliteError()
	{
		return $this->sqlite_error;
	}

}
?>