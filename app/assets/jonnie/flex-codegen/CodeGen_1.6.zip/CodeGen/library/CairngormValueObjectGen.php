<?php

include 'Required.php';

class CairngormValueObjectGen implements IGenerate
{
	
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		$table = ucfirst ( $table );
		
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		$namespace = Utilities::namespaceApplication ( $namespace );
		
		$fieldVars = '';
		$fieldsCon = '';
		$fieldsQuery = '';
		
		foreach ( $fields as $field )
		{
			$fieldVars .= '
			public var ' . $field [ 'name' ] . ':String;';

			$fieldsCon .= '
			this.' . $field [ 'name' ] . ' = obj["' . $field [ 'name' ] . '"];';
			
			
			$fieldsQuery .= '"&' . $field [ 'name' ] . '=" + ' . $field [ 'name' ] . ' + ';
			
		}	
		$fieldsQuery = Utilities::trim( $fieldsQuery, 2 );
		//$fieldsQuery += ';';	
		
		$tableService = FileSystemService::readFile ( TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'ValueObject.txt' );
		
		//replace the table name inside of the template
		$template = preg_replace ( TemplateManager::$TABLE_PATTERN, $table, $tableService );
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $template );
		$template = preg_replace ( TemplateManager::$FIELD_VARS_PATTERN, $fieldVars, $template );
		$template = preg_replace ( TemplateManager::$FIELDS_PATTERN, $fieldsCon, $template );
		$template = preg_replace ( TemplateManager::$FIELDS_QUERY_PATTERN, $fieldsQuery, $template );
		
		Utilities::checkOrMakeFolders ( TemplateManager::$CLIENT_OUTPUT, $folderNamespace, 'vo' );
		FileSystemService::writeFile ( TemplateManager::$CLIENT_OUTPUT . $folderNamespace . '/vo/' . ucfirst ( $table ) . 'VO.as', $template );
		
		return 'Generated  for Value Object '. $table;
	}
}

?>