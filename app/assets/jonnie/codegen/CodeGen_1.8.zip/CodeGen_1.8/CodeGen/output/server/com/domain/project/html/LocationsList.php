<?php 
require_once '../LocationsService.php';
require_once '../vo/LocationsVO.php';

$service = new LocationsService();
$result = '';
$recordList = '';

if ( isset($_POST['save']) )
{
	unset( $_POST['save'] );
	$recordValues = $_POST;
	$result = $service->saveLocations( $recordValues );	
}

$recordsArray = $service->getAllLocations();
$recordVO = new LocationsVO();

for ( $i = 0; $i < count( $recordsArray ); $i++ ) 
{
	$recordVO = $recordsArray[ $i ];
	
	$recordList .= '<tr id="'.$recordVO->id.'">';

	
			$recordList .= "<td>$recordVO->id</td>";
			$recordList .= "<td>$recordVO->loc_address</td>";
			$recordList .= "<td>$recordVO->loc_city</td>";
			$recordList .= "<td>$recordVO->loc_country</td>";
			$recordList .= "<td>$recordVO->loc_created</td>";
			$recordList .= "<td>$recordVO->loc_date</td>";
			$recordList .= "<td>$recordVO->loc_guests</td>";
			$recordList .= "<td>$recordVO->loc_state</td>";
			$recordList .= "<td>$recordVO->loc_title</td>";
			$recordList .= "<td>$recordVO->loc_zip</td>";
			$recordList .= "<td>$recordVO->map_id</td>";
			$recordList .= "<td>$recordVO->type_id</td>";
			$recordList .= "<td>$recordVO->user_id</td>";

	$recordList .= '<td class="actions">';
	$recordList .= '<button class="edit" onclick="window.location=\'LocationsForm.php?id='.$recordVO->id.'\'">Edit</button>';
	$recordList .= '<button class="delete" onclick=" remove('.$recordVO->id.')">Delete</button></td>';
	$recordList .= '</tr>';
}

?>
<?php include '_header.php'; ?> 

<script type="text/javascript">
var service = '../LocationsService.php';

function remove( id ){
	$.get( service, { m: 'remove', id: id }, function(data){
		if ( data ) {
			$('#'+id).fadeOut('slow');
		} else {
			alert( 'There was a problem!' );
		}
	});
}
</script>

<h3>Locations</h3>

    <table width="100%" border="0">
	<tr>
		
			<th scope="col">id</th>
			<th scope="col">loc_address</th>
			<th scope="col">loc_city</th>
			<th scope="col">loc_country</th>
			<th scope="col">loc_created</th>
			<th scope="col">loc_date</th>
			<th scope="col">loc_guests</th>
			<th scope="col">loc_state</th>
			<th scope="col">loc_title</th>
			<th scope="col">loc_zip</th>
			<th scope="col">map_id</th>
			<th scope="col">type_id</th>
			<th scope="col">user_id</th><th scope="col">Actions</th>   
    </tr>
       <?php echo $recordList; ?>
    </table>
    
    <a href="LocationsForm.php">New Locations</a>
  
 <?php include '_footer.php'; ?>