<?php

class DataAccessObjectGenerator
{
	
	public $mysqli;
	
	/**
	 * I hold methods to alter a mysql database
	 *
	 * @param [string] $host
	 * @param [string] $username
	 * @param [string] $password
	 */
	public function __construct( $host, $username, $password )
	{
		$link = new mysqli ( $host, $username, $password );
		
		/* check connection */
		if ( mysqli_connect_errno () )
		{
			trigger_error ( 'Database connection failure: Username/Password was incorrect.', E_USER_ERROR );
			exit ();
		}
		else
		{
			$this->mysqli = $link;
		}
	}
	
}

?>