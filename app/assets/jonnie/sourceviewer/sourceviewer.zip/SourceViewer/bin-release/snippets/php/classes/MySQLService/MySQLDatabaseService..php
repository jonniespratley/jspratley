<?php

class MySQLDatabaseService
{
	private $link;
	
	public function __construct()
	{
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * @return [mysqli] link
	 */
	public function getLink()
	{
		return $this->link;
	}
	
	/**
	 * @param [mysqli] $link
	 */
	public function setLink( $link )
	{
		$this->link = $link;
	}
}

?>