<div class="grid_12">
	<div id="cg_utilities"></div>
</div>
<div class="clear"></div>