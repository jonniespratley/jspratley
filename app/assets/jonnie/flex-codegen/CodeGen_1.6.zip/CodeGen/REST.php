<?php

//Require all of the table services and value objects
require_once 'output/server/com/jonniespratley/testpattern/TextpatternService.php';
require_once 'output/server/com/jonniespratley/testpattern/vo/TextpatternVO.php';

//Set up the variables for the calls
$mode = '';
$table = '';
$queryVO = '';
$format = '';

//The Mode
if ( isset ( $_REQUEST [ 'm' ] ) )
{
	$mode = $_REQUEST [ 'm' ]; //Mode
}

//The Table
if ( isset ( $_REQUEST [ 't' ] ) )
{
	$table = $_REQUEST [ 't' ]; //Table
}

//The Query ( arguments )
if ( isset ( $_REQUEST [ 'q' ] ) )
{
	$queryVO = $_REQUEST [ 'q' ]; //Query
}

//TODO: Add xml format
//The format, JSON for right now
if ( isset ( $_REQUEST [ 'f' ] ) )
{
	$format = $_REQUEST [ 'f' ]; //Format
}

/* ********************************************
 * Switch based on the mode
 * ********************************************/
switch ( $mode )
{
	case 'get':
	
	/* ********************************************
	 * Switch based on the table
	 * ********************************************/
	switch ( $table )
		{
			case 'categories':
				$service = new TextpatternService ( );
				$categories = $service->getAllTextpattern();
				
				print_r( json_encode( $categories ) ); 
				break;
		
		} //ends table switch
		

		break; //ends getAll switch
	

	case 'save':
	
	/* ********************************************
	 * Switch based on the table
	 * ********************************************/
	switch ( $table )
		{
			case 'categories':
				$service = new TextpatternService ( );
				$categories = $service->saveTextpattern( $queryVO );
				
				print json_encode ( $categories );
				break;
		
		} //ends table switch
		

		break; //ends save switch
	

	case 'remove':
	
	/* ********************************************
	 * Switch based on the table
	 * ********************************************/
	switch ( $table )
		{
			case 'categories':
				$service = new TextpatternService ( );
				$vo = new TextpatternServiceVO ( $queryVO );
				
				foreach ( $vo as $var => $value )
				{
					echo "\n" . $var . ' is ' . $value;
				}
				//$categories = $service->removeCategories( $vo );
				break;
		
		} //ends table switch
		

		break; //ends remove switch


}

?>