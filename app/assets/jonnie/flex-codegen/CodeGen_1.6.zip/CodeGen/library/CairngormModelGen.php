<?php

include 'Required.php';

class CairngormModelGen implements IGenerate
{
	
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		$outputLocation = TemplateManager::$CLIENT_OUTPUT;
		$config = new ConfigReader ( );
		$config->readConfig ( TemplateManager::$CONFIG_OUTPUT.'/'.ucfirst($database ).'Config.xml' );
		
		//Create the fileame
		$filename = 'ModelLocator.as';
		
		//make the folder namespace
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		$namespace = Utilities::namespaceApplication ( $namespace );
	
		$collections = '';

		foreach ( $table as $tbl )
		{
			
			$collections .= '
			public var ' . $tbl [ 'table' ] . 'Collection:ArrayCollection;
			public var selected' . ucfirst ( $tbl [ 'table' ] ) . ':' . ucfirst ( $tbl [ 'table' ] ) . 'VO;
			';
		}
		
		$tableService = FileSystemService::readFile ( TemplateManager::$CAIRNGORM_TEMPLATE_LOCATION.'Model.txt' );
		
		//replace the table name inside of the template
		$template = preg_replace ( TemplateManager::$TABLE_PATTERN, $collections, $tableService );
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $template );
		
		Utilities::checkOrMakeFolders ( $outputLocation, $folderNamespace, 'model' );
		FileSystemService::writeFile ( $outputLocation . $folderNamespace . '/model/' . $filename, $template );
		
		return 'Generated Cairngorm  Model Locator for ' . $database;
	}
}

?>