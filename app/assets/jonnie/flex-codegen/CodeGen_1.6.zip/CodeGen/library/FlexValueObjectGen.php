<?php

include 'Required.php';

class FlexValueObjectGen implements IGenerate
{
	
	public static function generate( $namespace, $database, $table, $fields = null )
	{
		$table = ucfirst ( $table );
		
		$folderNamespace = Utilities::namespaceFolders ( $namespace );
		$namespace = Utilities::namespaceApplication ( $namespace );
		
		$fieldVars = '';
		$fieldsCon = '';
		$fieldsQuery = '';
		
		foreach ( $fields as $field )
		{
			$fieldVars .= '
			public var ' . $field [ 'name' ] . ':String;';

			$fieldsCon .= '
			this.' . $field [ 'name' ] . ' = obj["' . $field [ 'name' ] . '"];';
			
			$fieldsQuery .= '"&' . $field [ 'name' ] . '=" + ' . $field [ 'name' ] . '+';
			
		}		
		
		$tableService = FileSystemService::readFile ( 'templates/cairngorm/ValueObject.txt' );
		
		//replace the table name inside of the template
		$template = preg_replace ( TemplateManager::$TABLE_PATTERN, $table, $tableService );
		$template = preg_replace ( TemplateManager::$FIELD_VARS_PATTERN, $fieldVars, $template );
		$template = preg_replace ( TemplateManager::$FIELDS_PATTERN, $fieldsCon, $template );
		$template = preg_replace ( TemplateManager::$FIELDS_QUERY_PATTERN, $fieldsQuery, $template );
		$template = preg_replace ( TemplateManager::$NAMESPACE_PATTERN, $namespace, $template );
		
		Utilities::checkOrMakeFolders ( TemplateManager::$CLIENT_OUTPUT, $folderNamespace, 'vo' );
		FileSystemService::writeFile ( TemplateManager::$CLIENT_OUTPUT . $folderNamespace . '/vo/' . ucfirst ( $table ) . 'VO.as', $template );
		
		echo '<li>Generated  for Value Object <b>' . $table . '</b></li>';
	}
}

?>