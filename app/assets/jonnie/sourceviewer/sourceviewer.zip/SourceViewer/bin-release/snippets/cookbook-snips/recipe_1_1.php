<?php 
class Connection
{
	private $link;
	
	public function __construct( $host, $user, $pass, $database )
	{
		$this->link = new mysqli( $host, $user, $pass, $database );

		return $this->link;
	}  
}

?>


<?php 
   class SnipprService

 {

  

//Specify our table name

private $table = "snippr";

   



public function SnipprService()

{

  mysql_connect( "localhost", "username", "password" );

  mysql_select_db( "snippr" );

   }

 }
 ?>
 
 
 
 
 A PHP class uses the following syntax: