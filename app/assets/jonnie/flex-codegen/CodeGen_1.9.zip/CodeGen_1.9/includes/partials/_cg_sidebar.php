<div id="sidebar">
	
	<div class="title">
		<h2>Navigation</h2>
	</div><!--/title-->
	
	<div class="box round navigation">
		<ul id="nav">
			<li><a href="?page=dashboard">Dashboard</a></li>
			<li><a href="?page=inspect">Inspector</a></li>
			<li><a href="?page=manage">Manage</a></li>
			<li><a href="?page=generate">Generate</a></li>
			<li><a href="?page=utilities">Utilities</a></li>
		</ul>
	</div><!--/box-->

	<div class="title">
		<h2>Recent Projects</h2>
	</div><!--/title-->
	
	<div class="box round">
		<ul id="history">
		<?php echo CodeGen::getRecentApplications(); ?>
		</ul>
	</div><!--/box-->
	
</div><!--/sidebar-->
