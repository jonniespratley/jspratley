<div class="box round">
	<h3>SDK Information </h3>
	<form id="form_sdk" name="form_sdk" method="" action="">
<?php

$sdkOptions = array ( 
	array ( 'label' => 'Flex SDK Location', 'name' => 'txt_sdk', 'type' => 'text', 'value' => '', 'class' => 'medium' ),
	array ( 'label' => '', 'name' => 'btn_sdk', 'type' => 'button', 'value' => 'Save', 'class' => 'submit') 
	);

$html->doOptions ( $sdkOptions );

?>
</form>
</div>