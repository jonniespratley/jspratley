<?php
require_once 'FileSystemService.php';
$fileSvc = new FileSystemService();

if ( isset ( $_GET[ 'm' ] ) )
{
	$mode = $_GET['m'];
}

if ( isset ( $_GET[ 'f' ] ) )
{
	$file = $_GET['f'];
}

if ( isset ( $_GET[ 'l' ] ) )
{
	$list = $_GET['l'];
}

switch ( $mode )
{
	
	case 'getDirectory' :
		$directory = $fileSvc->browseDirectory( '../snippets', $list, true );
		echo  $directory;
	break;
	
	case 'readFile' :
		$file = $fileSvc->readFile( $file );
		print_r( $file );
	break;	
	
	default:
		trigger_error ( 'Please choose a mode.' );
	exit ();
}
?>