
/* blogger.getUsersInfo gives your client some info about you, so you don't have to */

function blogger_getUserInfo( $args )
{
	$this->escape ( $args );
	$user_login = $args [];
	$user_pass = $args [];
	
	if ( ! $this->login_pass_ok ( $user_login, $user_pass ) )
	{
		return $this->error;
	}
	set_current_user( , $user_login )
	
	if ( ! current_user_can ( 'edit_posts' ) )
		return new IXR_Error( , __( 'Sorry, you do not have access to user data on this blog.' ) );
	do_action ( 'xmlrpc_call', 'blogger.getUserInfo' );
	$user_data = get_userdatabylogin ( $user_login );
	
	$struct = array ( 
		'nickname' => $user_data->nickname, 'userid' => $user_data->ID, 'url' => $user_data->user_url, 'lastname' => $user_data->last_name, 'firstname' => $user_data->first_name 
	);
	return $struct;
}

/**
 * blogger.getUserInfo
 * 
 * @args username password
 */
private function getUserInfo():void
{
	service.call( "blogger.getUserInfo", txt_username.text, txt_password.text );
}


 

/**
 * blogger.getUserInfo
 * 
 * @args username password
 */
private function getUserInfo()void
{
	service.call( "blogger.getUserInfo", "", txt_username.text, txt_password.text );
}