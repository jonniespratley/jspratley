<?php



$dom = new DomDocument ( );
$dom->load ( '../output/testSchema.xml' );

$root = $dom->documentElement;
$type = $root->nodeType;

echo "<li>" . $type . "</li>";
echo "<li>Node Name: " . $dom->nodeName . "</li>";
echo "<li>Root Node Name: " . $root->nodeName . "</li>";

echo "<li>Dom Node Value: " . $dom->nodeValue . "</li>";
echo "<li>Root Node Value: " . $root->nodeValue . "</li>";

if ( $root->hasChildNodes () )
{
	$children = $root->childNodes;
	foreach ( $children as $node )
	{
		if ( $node->nodeType != XML_TEXT_NODE )
		{
			print "<li>".$node->nodeName . "</li>";
			if ( $root->hasAttributes () )
			{
				$attributes = $root->attributes;
				foreach ( $attributes as $attr )
				{
					print "<li>Attribute Name: " . $attr->nodeName . "</li>";
					print "<li>Attribute Value: " . $attr->nodeValue . "</li>";
				}
			}
		}
	}
}







//$attr = $attributes->getNamedItem("name");
//print "<li>Attribute Name: ".$attr->nodeName."</li>";
//print "<li>Attribute Value: ".$attr->nodeValue."</li>";




?>