<div class="title">
	<h2>Inspector</h2>
</div>

<div class="box round">
	<h3>Class Inspector</h3>
</div>

<div class="box round">
	<h3>Inspector Results</h3>
</div>