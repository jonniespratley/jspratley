<?php include '_header.php'; ?>
<h2>Select a Table</h2>    
<ul>
	<li><a href="List.php">Posts</a></li>
</ul>
<?php include '_footer.php'; ?>